plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.remo.almal"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.remo.almal"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // Native Android configuration for Supabase (NO service_role, public client settings only)
        buildConfigField("String", "SUPABASE_URL", "\"https://fyggwnhxgsvbelulyfsr.supabase.co\"")
        buildConfigField("String", "SUPABASE_PROJECT_ID", "\"fyggwnhxgsvbelulyfsr\"")
        buildConfigField("String", "SUPABASE_ANON_KEY", "\"\"") // Injected via local.properties or strings.xml
        buildConfigField("String", "APP_URL", "\"https://remoalmal.com\"")
    }

    buildFeatures {
        buildConfig = true
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("debug")
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.webkit)
    implementation(libs.androidx.swiperefreshlayout)
}
