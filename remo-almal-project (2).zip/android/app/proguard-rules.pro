# Proguard rules for Remo Al-Mal Android App
# Package: com.remo.almal

-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Application
-keep public class * extends android.app.Service

# Keep Kotlin reflect / stdlib
-keep class kotlin.** { *; }

# Keep WebView JavaScript Interfaces
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep RemoConfig and data classes
-keep class com.remo.almal.** { *; }
