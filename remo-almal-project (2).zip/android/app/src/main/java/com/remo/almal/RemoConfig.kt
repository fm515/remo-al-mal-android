package com.remo.almal

import android.content.Context

/**
 * Remo Al-Mal Native Android Configuration
 * Replaces web-specific Vite environment variables with native Android BuildConfig and Resource Strings.
 * Strictly adheres to security rules: NO service_role and NO sb_secret keys.
 */
object RemoConfig {
    const val DEFAULT_PROJECT_ID = "fyggwnhxgsvbelulyfsr"
    const val DEFAULT_SUPABASE_URL = "https://fyggwnhxgsvbelulyfsr.supabase.co"
    const val STORAGE_BUCKET = "digital-product-files"
    const val DEFAULT_APP_URL = "https://remoalmal.com"

    fun getAppUrl(context: Context): String {
        val prefs = context.getSharedPreferences("remo_almal_prefs", Context.MODE_PRIVATE)
        val customUrl = prefs.getString("custom_app_url", "") ?: ""
        if (customUrl.isNotBlank()) return customUrl

        val resId = context.resources.getIdentifier("app_url", "string", context.packageName)
        return if (resId != 0) context.getString(resId) else DEFAULT_APP_URL
    }

    fun saveAppUrl(context: Context, url: String) {
        val prefs = context.getSharedPreferences("remo_almal_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("custom_app_url", url.trim()).apply()
    }

    fun getSupabaseUrl(context: Context): String {
        val resId = context.resources.getIdentifier("supabase_url", "string", context.packageName)
        return if (resId != 0) context.getString(resId) else DEFAULT_SUPABASE_URL
    }

    fun getSupabaseAnonKey(context: Context): String {
        val resId = context.resources.getIdentifier("supabase_anon_key", "string", context.packageName)
        val keyFromRes = if (resId != 0) context.getString(resId) else ""
        if (keyFromRes.isNotBlank()) return keyFromRes

        // Check shared preferences (saved dynamically via Android settings or setup screen)
        val prefs = context.getSharedPreferences("remo_almal_prefs", Context.MODE_PRIVATE)
        return prefs.getString("supabase_anon_key", "") ?: ""
    }

    fun saveSupabaseAnonKey(context: Context, anonKey: String) {
        val prefs = context.getSharedPreferences("remo_almal_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("supabase_anon_key", anonKey.trim()).apply()
    }

    /**
     * Build required HTTP headers for Supabase API requests in Android
     * Ensures "apikey" header is ALWAYS included to prevent "No API key found in request" errors.
     */
    fun getSupabaseHeaders(context: Context): Map<String, String> {
        val anonKey = getSupabaseAnonKey(context)
        val headers = mutableMapOf(
            "Content-Type" to "application/json",
            "Accept" to "application/json"
        )
        if (anonKey.isNotBlank()) {
            headers["apikey"] = anonKey
            // For sb_publishable_ keys, omit Bearer header to prevent gateway JWT decode rejection
            if (!anonKey.startsWith("sb_publishable_") && anonKey.contains(".")) {
                headers["Authorization"] = "Bearer $anonKey"
            }
        }
        return headers
    }
}
