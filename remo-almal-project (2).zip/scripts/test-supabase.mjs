// scripts/test-supabase.mjs
// Live Diagnostic tool for Remo Al-Mal Supabase integration
import dotenv from 'dotenv';
dotenv.config();

const SUPABASE_PROJECT_ID = 'fyggwnhxgsvbelulyfsr';
const SUPABASE_URL = (
  process.env.VITE_SUPABASE_URL ||
  process.env.SUPABASE_URL ||
  `https://${SUPABASE_PROJECT_ID}.supabase.co`
).trim();

const KEY = (
  process.env.VITE_SUPABASE_ANON_KEY ||
  process.env.SUPABASE_ANON_KEY ||
  ''
).trim();

console.log('====================================================');
console.log('🧪 Remo Al-Mal - Supabase Live Connection Inspector');
console.log('====================================================');
console.log(`📡 Project ID:   ${SUPABASE_PROJECT_ID}`);
console.log(`🌐 Project URL:  ${SUPABASE_URL}`);
console.log(`🔑 Key Loaded:   ${KEY ? `Present (Type: ${KEY.startsWith('sb_publishable_') ? 'sb_publishable_' : 'JWT / anon'}, length: ${KEY.length})` : 'Missing / Empty'}`);
console.log('----------------------------------------------------');

async function runDiagnostic() {
  const endpoint = `${SUPABASE_URL}/rest/v1/digital_products?select=*`;

  // Test 1: Check what headers would be sent
  console.log('\n[Phase 1] Evaluating REST headers...');
  const isPublishable = KEY.startsWith('sb_publishable_');
  const headers = {
    'apikey': KEY,
    'Accept': 'application/json',
    'Content-Type': 'application/json',
  };

  // Only include Authorization: Bearer if key is a 3-part JWT
  if (!isPublishable && KEY.split('.').length === 3) {
    headers['Authorization'] = `Bearer ${KEY}`;
  }

  console.log(`  -> apikey header:         ${KEY ? 'Attached' : 'EMPTY / NOT FOUND'}`);
  console.log(`  -> Authorization header:  ${headers['Authorization'] ? 'Bearer JWT attached' : 'Omitted (Preventing JWT decode error on sb_publishable_)'}`);

  // Test 2: Live REST Request to digital_products
  console.log('\n[Phase 2] Executing live GET request to digital_products table...');
  try {
    const res = await fetch(endpoint, {
      method: 'GET',
      headers: KEY ? headers : { 'Accept': 'application/json' },
    });

    const status = res.status;
    const sbErrorCode = res.headers.get('sb-error-code') || 'None';
    console.log(`  -> HTTP Status Code: ${status} ${res.statusText}`);
    console.log(`  -> sb-error-code:    ${sbErrorCode}`);

    if (res.ok) {
      const data = await res.json();
      console.log(`\n✅ [SUCCESS] Connection established! Successfully retrieved ${data.length} published products from Supabase:`);
      if (data.length === 0) {
        console.log('   (Table is accessible and verified, but currently has 0 rows)');
      } else {
        data.forEach((p, idx) => {
          console.log(`   [#${idx + 1}] ID: ${p.id} | Title: "${p.title || p.title_en || 'Untitled'}" | Price: ${p.price} ${p.currency || 'USD'} | Status: ${p.status}`);
        });
      }
    } else {
      const errBody = await res.json().catch(() => ({}));
      console.log(`\n❌ [FAILED] Request returned HTTP ${status}:`);
      console.log(`   Error message: ${errBody.message || 'Unknown error'}`);
      if (errBody.hint) console.log(`   Gateway hint:  ${errBody.hint}`);
      if (!KEY) {
        console.log('\n   💡 Cause: VITE_SUPABASE_ANON_KEY is currently empty.');
        console.log('      Supabase Kong Gateway strictly requires the apikey header.');
      }
    }
  } catch (err) {
    console.log(`\n❌ [EXCEPTION] Network or fetch error: ${err.message}`);
  }
}

runDiagnostic();
