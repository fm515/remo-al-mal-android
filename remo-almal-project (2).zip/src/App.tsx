/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  DigitalProduct,
  Language,
  Order,
  PaymentMethod,
  Screen,
  Theme,
  UserProfile,
  UserRole,
  Wallet,
  WalletTransaction
} from './types';
import { INITIAL_PRODUCTS, testSupabaseConnection } from './lib/supabase';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { SupabaseModal } from './components/SupabaseModal';

// Views
import { SplashScreen } from './views/SplashScreen';
import { HomeScreen } from './views/HomeScreen';
import { AllProductsScreen } from './views/AllProductsScreen';
import { SearchScreen } from './views/SearchScreen';
import { ProductDetailsScreen } from './views/ProductDetailsScreen';
import { AuthScreen } from './views/AuthScreen';
import { ProfileScreen } from './views/ProfileScreen';
import { SellerDashboardScreen } from './views/SellerDashboardScreen';
import { AddEditProductScreen } from './views/AddEditProductScreen';
import { OrdersScreen } from './views/OrdersScreen';
import { OrderDetailsScreen } from './views/OrderDetailsScreen';
import { PaymentMethodScreen } from './views/PaymentMethodScreen';
import { PaymentStatusScreen } from './views/PaymentStatusScreen';
import { PurchasedProductsScreen } from './views/PurchasedProductsScreen';
import { SettingsScreen } from './views/SettingsScreen';
import { HelpSupportScreen } from './views/HelpSupportScreen';
import { PrivacyPolicyScreen } from './views/PrivacyPolicyScreen';
import { TermsOfServiceScreen } from './views/TermsOfServiceScreen';
import { ConnectionErrorScreen } from './views/ConnectionErrorScreen';
import { ApkExportScreen } from './views/ApkExportScreen';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export default function App() {
  // 1. Language State
  const [language, setLanguage] = useState<Language>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('remo_lang');
      if (saved === 'ar' || saved === 'en') return saved;
    }
    return 'ar';
  });

  // 2. Theme State
  const [theme, setTheme] = useState<Theme>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('remo_theme');
      if (saved === 'dark' || saved === 'light') return saved;
    }
    return 'dark';
  });

  // 3. Current Active Screen
  const [currentScreen, setCurrentScreen] = useState<Screen>('splash');

  // 4. Products Data and Source Status
  const [products, setProducts] = useState<DigitalProduct[]>(INITIAL_PRODUCTS);
  const [productsSource, setProductsSource] = useState<'supabase_live' | 'local_sandbox'>('local_sandbox');
  const [supabaseFetchError, setSupabaseFetchError] = useState<string | null>(null);

  // 5. Active User Profile
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    return {
      id: 'usr-remo-buyer-01',
      email: 'user@remoalmal.com',
      full_name: 'محمد نور',
      role: 'buyer',
      created_at: new Date().toISOString(),
    };
  });

  // 6. User Wallet & Transactions
  const [wallet, setWallet] = useState<Wallet>({
    id: 'wlt-001',
    user_id: 'usr-remo-buyer-01',
    balance: 150.0,
    pending_balance: 0.0,
    currency: 'USD',
    updated_at: new Date().toISOString(),
  });

  const [transactions, setTransactions] = useState<WalletTransaction[]>([
    {
      id: 'tx-001',
      wallet_id: 'wlt-001',
      type: 'deposit',
      amount: 150.0,
      description: 'Initial balance deposit (USDT TRC-20)',
      status: 'completed',
      created_at: new Date(Date.now() - 86400000 * 2).toISOString(),
    },
  ]);

  // 7. Orders State
  const [orders, setOrders] = useState<Order[]>([
    {
      id: 'ord-8f92a10c',
      buyer_id: 'usr-remo-buyer-01',
      seller_id: 'seller-remo-01',
      product_id: 'prod-001',
      product_title: 'حزمة قوالب تطبيقات Android و Flutter المتكاملة Pro',
      product_image: 'https://images.unsplash.com/photo-1607252650355-f7fd0460ccdb?w=800&auto=format&fit=crop&q=80',
      total_amount: 49.0,
      commission_fee: 4.9, // 10%
      seller_net_amount: 44.1, // 90%
      status: 'paid',
      payment_method: 'crypto_usdt_trc20',
      tx_hash: '7a9c08d1f2e4b6c8a0d9e8f7a6b5c4d3e2f1a0b9',
      created_at: new Date(Date.now() - 86400000).toISOString(),
    },
  ]);

  // 8. Navigation Selections
  const [selectedProduct, setSelectedProduct] = useState<DigitalProduct | null>(INITIAL_PRODUCTS[0]);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(orders[0]);
  const [editingProduct, setEditingProduct] = useState<DigitalProduct | null>(null);

  // 9. Supabase Connection Modal & Live Status
  const [showSupabaseModal, setShowSupabaseModal] = useState(false);
  const [isSupabaseConnected, setIsSupabaseConnected] = useState(false);

  // 10. PWA Install State
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isPwaInstalled, setIsPwaInstalled] = useState(false);

  // Load real products from Supabase
  const loadProducts = async () => {
    const res = await testSupabaseConnection();
    setIsSupabaseConnected(res.success);

    if (res.success) {
      const { fetchRealProducts } = await import('./lib/supabase');
      const prodRes = await fetchRealProducts();
      if (prodRes.data && prodRes.data.length > 0) {
        setProducts(prodRes.data);
        setProductsSource('supabase_live');
        setSupabaseFetchError(null);
        setSelectedProduct(prodRes.data[0]);
      } else if (prodRes.data && prodRes.data.length === 0) {
        setProducts([]);
        setProductsSource('supabase_live');
        setSupabaseFetchError('قاعدة البيانات متصلة ولكن جدول digital_products فارغ حالياً (0 منتجات). يمكنك إضافة منتج جديد من لوحة البائع.');
      } else {
        setSupabaseFetchError(prodRes.error);
      }
    } else {
      setProductsSource('local_sandbox');
      setSupabaseFetchError(res.message);
    }
  };

  useEffect(() => {
    loadProducts();
  }, []);


  // PWA beforeinstallprompt handler
  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const handleAppInstalled = () => {
      setIsPwaInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    if (
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true
    ) {
      setIsPwaInstalled(true);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const handleInstallPwa = async () => {
    if (deferredPrompt) {
      await deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setIsPwaInstalled(true);
        setDeferredPrompt(null);
      }
    } else {
      alert(
        language === 'ar'
          ? 'لتثبيت التطبيق على هاتفك Android: اضغط على القائمة (⋮) في متصفح Chrome ثم اختر "الإضافة إلى الشاشة الرئيسية / تثبيت التطبيق".'
          : 'To install on Android: Tap the menu (⋮) in Chrome and select "Install app / Add to Home screen".'
      );
    }
  };

  // Language & Theme Toggles
  const toggleLanguage = () => {
    setLanguage((prev) => (prev === 'ar' ? 'en' : 'ar'));
  };

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  // Purchase Actions
  const handleSelectProduct = (product: DigitalProduct) => {
    setSelectedProduct(product);
    setCurrentScreen('product_details');
  };

  const handleInstantBuy = (product: DigitalProduct) => {
    setSelectedProduct(product);
    setCurrentScreen('payment_method');
  };

  const handleProceedToVerification = (
    method: PaymentMethod,
    paymentData: Record<string, any>
  ) => {
    if (!selectedProduct) return;

    // Strict 10% platform commission calculation
    const total = selectedProduct.price;
    const commission = total * 0.10;
    const netSeller = total * 0.90;

    const newOrder: Order = {
      id: `ord-${Date.now().toString(16)}`,
      buyer_id: currentUser?.id || 'guest-buyer',
      seller_id: selectedProduct.seller_id,
      product_id: selectedProduct.id,
      product_title: selectedProduct.title,
      product_image: selectedProduct.preview_image,
      total_amount: total,
      commission_fee: commission,
      seller_net_amount: netSeller,
      status: 'paid', // verified by server
      payment_method: method,
      tx_hash: paymentData.tx_hash || `TX-${Date.now()}`,
      created_at: new Date().toISOString(),
    };

    // If paid by wallet, deduct from balance
    if (method === 'wallet') {
      setWallet((prev) => ({
        ...prev,
        balance: Math.max(0, prev.balance - total),
      }));
      setTransactions((prev) => [
        {
          id: `tx-${Date.now()}`,
          wallet_id: wallet.id,
          type: 'purchase',
          amount: total,
          description: `Purchase: ${selectedProduct.title}`,
          status: 'completed',
          created_at: new Date().toISOString(),
        },
        ...prev,
      ]);
    }

    setOrders((prev) => [newOrder, ...prev]);
    setSelectedOrder(newOrder);
    setCurrentScreen('payment_status');
  };

  // Add / Edit Product Save
  const handleSaveProduct = (product: DigitalProduct) => {
    setProducts((prev) => {
      const exists = prev.some((p) => p.id === product.id);
      if (exists) {
        return prev.map((p) => (p.id === product.id ? product : p));
      }
      return [product, ...prev];
    });
    setEditingProduct(null);
    setCurrentScreen('seller_dashboard');
  };

  // Deposit into wallet
  const handleDepositFunds = (amount: number) => {
    setWallet((prev) => ({
      ...prev,
      balance: prev.balance + amount,
    }));
    setTransactions((prev) => [
      {
        id: `tx-${Date.now()}`,
        wallet_id: wallet.id,
        type: 'deposit',
        amount: amount,
        description: `Deposit via USDT TRC-20`,
        status: 'completed',
        created_at: new Date().toISOString(),
      },
      ...prev,
    ]);
  };

  const handleWithdrawFunds = (amount: number) => {
    setWallet((prev) => ({
      ...prev,
      balance: Math.max(0, prev.balance - amount),
    }));
    setTransactions((prev) => [
      {
        id: `tx-${Date.now()}`,
        wallet_id: wallet.id,
        type: 'withdrawal',
        amount: amount,
        description: `Withdrawal request to TRC-20 wallet`,
        status: 'pending',
        created_at: new Date().toISOString(),
      },
      ...prev,
    ]);
  };

  return (
    <div
      className={`min-h-screen transition-colors duration-200 ${
        theme === 'dark' ? 'bg-neutral-950 text-neutral-100' : 'bg-slate-50 text-neutral-900'
      }`}
    >
      {/* 1. Header (Hidden during splash) */}
      {currentScreen !== 'splash' && (
        <Header
          currentScreen={currentScreen}
          setScreen={setCurrentScreen}
          language={language}
          toggleLanguage={toggleLanguage}
          theme={theme}
          toggleTheme={toggleTheme}
          currentUser={currentUser}
          isSupabaseConnected={isSupabaseConnected}
          onOpenSupabaseModal={() => setShowSupabaseModal(true)}
          isInstallable={!isPwaInstalled}
          onInstallPwa={handleInstallPwa}
        />
      )}

      {/* Main Container */}
      <main className="mx-auto max-w-7xl px-3.5 py-4 sm:px-6 sm:py-6">
        {/* Screen 1: Splash */}
        {currentScreen === 'splash' && (
          <SplashScreen
            language={language}
            onFinish={() => setCurrentScreen('home')}
          />
        )}

        {/* Screen 2: Home */}
        {currentScreen === 'home' && (
          <HomeScreen
            products={products}
            productsSource={productsSource}
            language={language}
            setScreen={setCurrentScreen}
            onSelectProduct={handleSelectProduct}
            onInstantBuy={handleInstantBuy}
            onOpenSupabaseModal={() => setShowSupabaseModal(true)}
          />
        )}

        {/* Screen 3: All Products */}
        {currentScreen === 'all_products' && (
          <AllProductsScreen
            products={products}
            language={language}
            setScreen={setCurrentScreen}
            onSelectProduct={handleSelectProduct}
            onInstantBuy={handleInstantBuy}
          />
        )}

        {/* Screen 4: Search */}
        {currentScreen === 'search' && (
          <SearchScreen
            products={products}
            language={language}
            onSelectProduct={handleSelectProduct}
            onInstantBuy={handleInstantBuy}
          />
        )}

        {/* Screen 5: Product Details */}
        {currentScreen === 'product_details' && selectedProduct && (
          <ProductDetailsScreen
            product={selectedProduct}
            language={language}
            onBack={() => setCurrentScreen('all_products')}
            onBuy={handleInstantBuy}
          />
        )}

        {/* Screens 6 & 7: Register & Login */}
        {(currentScreen === 'login' || currentScreen === 'register') && (
          <AuthScreen
            initialMode={currentScreen}
            language={language}
            onSuccess={(user) => {
              setCurrentUser(user);
              setCurrentScreen(user.role === 'seller' ? 'seller_dashboard' : 'profile');
            }}
            onGuestDemo={(role: UserRole) => {
              setCurrentUser({
                id: role === 'seller' ? 'seller-remo-01' : 'usr-remo-buyer-01',
                email: role === 'seller' ? 'seller@remoalmal.com' : 'buyer@remoalmal.com',
                full_name: role === 'seller' ? 'ريمو ديجيتال ستوديو' : 'محمد نور',
                role: role,
                created_at: new Date().toISOString(),
              });
              setCurrentScreen(role === 'seller' ? 'seller_dashboard' : 'home');
            }}
          />
        )}

        {/* Screen 8: Profile & Wallet */}
        {currentScreen === 'profile' && currentUser && (
          <ProfileScreen
            user={currentUser}
            wallet={wallet}
            transactions={transactions}
            language={language}
            setScreen={setCurrentScreen}
            onLogout={() => {
              setCurrentUser(null);
              setCurrentScreen('home');
            }}
            onDeposit={handleDepositFunds}
            onWithdraw={handleWithdrawFunds}
          />
        )}

        {/* Screen 9: Seller Dashboard */}
        {currentScreen === 'seller_dashboard' && currentUser && (
          <SellerDashboardScreen
            user={currentUser}
            products={products}
            orders={orders}
            language={language}
            setScreen={setCurrentScreen}
            onAddNewProduct={() => {
              setEditingProduct(null);
              setCurrentScreen('add_edit_product');
            }}
            onEditProduct={(prod) => {
              setEditingProduct(prod);
              setCurrentScreen('add_edit_product');
            }}
          />
        )}

        {/* Screen 10: Add / Edit Product */}
        {currentScreen === 'add_edit_product' && currentUser && (
          <AddEditProductScreen
            initialProduct={editingProduct}
            currentUser={currentUser}
            language={language}
            onSave={handleSaveProduct}
            onCancel={() => setCurrentScreen('seller_dashboard')}
          />
        )}

        {/* Screen 11: Orders */}
        {currentScreen === 'orders' && currentUser && (
          <OrdersScreen
            orders={orders}
            currentUser={currentUser}
            language={language}
            onSelectOrder={(ord) => {
              setSelectedOrder(ord);
              setCurrentScreen('order_details');
            }}
            onGoToDownload={() => setCurrentScreen('purchased_products')}
          />
        )}

        {/* Screen 12: Order Details */}
        {currentScreen === 'order_details' && selectedOrder && (
          <OrderDetailsScreen
            order={selectedOrder}
            language={language}
            onBack={() => setCurrentScreen('orders')}
            onGoToDownload={() => setCurrentScreen('purchased_products')}
          />
        )}

        {/* Screen 13: Payment Method Selection */}
        {currentScreen === 'payment_method' && selectedProduct && currentUser && (
          <PaymentMethodScreen
            product={selectedProduct}
            currentUser={currentUser}
            wallet={wallet}
            language={language}
            onBack={() => setCurrentScreen('product_details')}
            onProceedToVerification={handleProceedToVerification}
          />
        )}

        {/* Screen 14: Payment Status */}
        {currentScreen === 'payment_status' && selectedOrder && selectedProduct && (
          <PaymentStatusScreen
            order={selectedOrder}
            product={selectedProduct}
            language={language}
            onSuccessNavigate={() => setCurrentScreen('purchased_products')}
            onRetry={() => setCurrentScreen('payment_method')}
          />
        )}

        {/* Screen 15: Purchased Products */}
        {currentScreen === 'purchased_products' && currentUser && (
          <PurchasedProductsScreen
            orders={orders}
            products={products}
            currentUser={currentUser}
            language={language}
          />
        )}

        {/* Screen 16: Settings */}
        {currentScreen === 'settings' && (
          <SettingsScreen
            language={language}
            onLanguageChange={setLanguage}
            theme={theme}
            onThemeChange={setTheme}
            setScreen={setCurrentScreen}
            onOpenSupabaseModal={() => setShowSupabaseModal(true)}
          />
        )}

        {/* Screen 17: Help & Support */}
        {currentScreen === 'help_support' && (
          <HelpSupportScreen language={language} />
        )}

        {/* Screen 18: Privacy Policy */}
        {currentScreen === 'privacy_policy' && (
          <PrivacyPolicyScreen
            language={language}
            setScreen={setCurrentScreen}
          />
        )}

        {/* Screen 19: Terms of Service */}
        {currentScreen === 'terms_of_service' && (
          <TermsOfServiceScreen
            language={language}
            setScreen={setCurrentScreen}
          />
        )}

        {/* Screen 20: Connection Error */}
        {currentScreen === 'connection_error' && (
          <ConnectionErrorScreen
            language={language}
            onRetry={() => setCurrentScreen('home')}
            onOpenSupabaseModal={() => setShowSupabaseModal(true)}
          />
        )}

        {/* Bonus Native Hub: APK Build & Export */}
        {currentScreen === 'apk_export' && (
          <ApkExportScreen
            language={language}
            isInstallable={!isPwaInstalled}
            onInstallPwa={handleInstallPwa}
          />
        )}
      </main>

      {/* Mobile Bottom Navigation (Hidden on splash) */}
      {currentScreen !== 'splash' && (
        <BottomNav
          currentScreen={currentScreen}
          setScreen={setCurrentScreen}
          language={language}
          currentUser={currentUser}
          purchasesCount={orders.filter((o) => o.status === 'paid').length}
        />
      )}

      {/* Supabase Inspection Modal */}
      <SupabaseModal
        isOpen={showSupabaseModal}
        onClose={() => setShowSupabaseModal(false)}
        language={language}
        onConnectionStatusChange={(connected) => {
          setIsSupabaseConnected(connected);
          loadProducts();
        }}
      />
    </div>
  );
}
