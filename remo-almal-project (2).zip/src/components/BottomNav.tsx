import React from 'react';
import { Home, Layers, Search, DownloadCloud, Briefcase, User } from 'lucide-react';
import { Language, Screen, UserProfile } from '../types';
import { translations } from '../lib/i18n';

interface BottomNavProps {
  currentScreen: Screen;
  setScreen: (screen: Screen) => void;
  language: Language;
  currentUser: UserProfile | null;
  purchasesCount?: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentScreen,
  setScreen,
  language,
  currentUser,
  purchasesCount = 0,
}) => {
  const t = translations[language];

  const navItems = [
    {
      id: 'home' as Screen,
      label: t.navHome,
      icon: Home,
    },
    {
      id: 'all_products' as Screen,
      label: t.navProducts,
      icon: Layers,
    },
    {
      id: 'search' as Screen,
      label: t.navSearch,
      icon: Search,
    },
    {
      id: 'purchased_products' as Screen,
      label: t.navPurchases,
      icon: DownloadCloud,
      badge: purchasesCount > 0 ? purchasesCount : undefined,
    },
    {
      id: (currentUser?.role === 'seller' ? 'seller_dashboard' : 'profile') as Screen,
      label: currentUser?.role === 'seller' ? t.navSeller : t.navProfile,
      icon: currentUser?.role === 'seller' ? Briefcase : User,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 border-t border-neutral-800 bg-neutral-950/95 backdrop-blur-lg safe-bottom">
      <div className="mx-auto flex max-w-lg items-center justify-around px-2 py-1.5 sm:py-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentScreen === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setScreen(item.id)}
              className={`relative flex flex-1 flex-col items-center justify-center py-1 transition-all ${
                isActive
                  ? 'text-amber-400 font-bold scale-105'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <div className="relative">
                <Icon className={`h-5 w-5 ${isActive ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="absolute -top-1 -right-2 flex h-4 w-4 items-center justify-center rounded-full bg-amber-400 text-[9px] font-black text-neutral-950">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="mt-1 text-[10px] tracking-tight truncate max-w-[64px]">
                {item.label}
              </span>
              {isActive && (
                <div className="mt-0.5 h-0.5 w-4 rounded-full bg-amber-400" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
