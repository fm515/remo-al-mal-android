import React from 'react';
import {
  ShieldCheck,
  Globe,
  Sun,
  Moon,
  Smartphone,
  Database,
  User as UserIcon,
  ShoppingBag
} from 'lucide-react';
import { Language, Screen, Theme, UserProfile } from '../types';
import { translations } from '../lib/i18n';

interface HeaderProps {
  currentScreen: Screen;
  setScreen: (screen: Screen) => void;
  language: Language;
  toggleLanguage: () => void;
  theme: Theme;
  toggleTheme: () => void;
  currentUser: UserProfile | null;
  isSupabaseConnected: boolean;
  onOpenSupabaseModal: () => void;
  isInstallable: boolean;
  onInstallPwa: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  setScreen,
  language,
  toggleLanguage,
  theme,
  toggleTheme,
  currentUser,
  isSupabaseConnected,
  onOpenSupabaseModal,
  isInstallable,
  onInstallPwa,
}) => {
  const t = translations[language];

  return (
    <header className="sticky top-0 z-40 border-b border-neutral-800/80 bg-neutral-950/90 backdrop-blur-md transition-colors dark:border-neutral-800/80 dark:bg-neutral-950/90">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-3 py-2.5 sm:px-6 sm:py-3">
        {/* Brand Logo & Name */}
        <button
          onClick={() => setScreen('home')}
          className="group flex items-center gap-2.5 text-start transition"
        >
          <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-neutral-900 to-black p-0.5 shadow-md ring-1 ring-amber-400/40 transition group-hover:ring-amber-400">
            <svg viewBox="0 0 512 512" className="h-full w-full">
              <path
                d="M205 165 H275 C310 165 330 185 330 215 C330 240 315 258 290 263 L340 345 H295 L252 275 H245 V345 H205 V165 Z M245 200 V240 H272 C288 240 295 232 295 220 C295 208 288 200 272 200 H245 Z"
                fill="#FACC15"
              />
              <polygon points="345,125 352,140 367,147 352,154 345,169 338,154 323,147 338,140" fill="#EAB308" />
            </svg>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold tracking-tight text-white group-hover:text-amber-400 sm:text-lg">
                Remo Al-Mal
              </span>
              <span className="rounded bg-amber-400/20 px-1.5 py-0.5 text-[10px] font-bold text-amber-400">
                PRO
              </span>
            </div>
            <p className="text-[11px] font-medium text-neutral-400">
              {t.appName}
            </p>
          </div>
        </button>

        {/* Action Controls & Utilities */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Supabase Indicator */}
          <button
            onClick={onOpenSupabaseModal}
            title="حالة اتصال قاعدة بيانات Supabase"
            className="flex items-center gap-1.5 rounded-lg border border-neutral-800 bg-neutral-900/80 px-2 py-1 text-xs font-medium text-neutral-300 hover:border-amber-400/60 transition"
          >
            <Database className="h-3.5 w-3.5 text-amber-400" />
            <span className="hidden sm:inline">Supabase</span>
            <span
              className={`h-2 w-2 rounded-full ${
                isSupabaseConnected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-500'
              }`}
            />
          </button>

          {/* Android APK Hub Shortcut */}
          <button
            onClick={() => setScreen('apk_export')}
            className="flex items-center gap-1 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 px-2.5 py-1 text-xs font-bold text-neutral-950 shadow-sm hover:from-amber-400 hover:to-amber-500 transition active:scale-95"
            title="تثبيت واستخراج تطبيق Android APK"
          >
            <Smartphone className="h-3.5 w-3.5" />
            <span className="font-bold">APK</span>
          </button>

          {/* Language Switcher */}
          <button
            onClick={toggleLanguage}
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-neutral-800 bg-neutral-900 text-neutral-300 hover:border-amber-400 hover:text-amber-400 transition"
            title="تغيير اللغة / Change Language"
          >
            <span className="text-xs font-bold uppercase">{language === 'ar' ? 'EN' : 'عر'}</span>
          </button>

          {/* Theme Switcher */}
          <button
            onClick={toggleTheme}
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-neutral-800 bg-neutral-900 text-neutral-300 hover:border-amber-400 hover:text-amber-400 transition"
            title="تبديل المظهر / Toggle Theme"
          >
            {theme === 'dark' ? (
              <Sun className="h-4 w-4 text-amber-400" />
            ) : (
              <Moon className="h-4 w-4 text-neutral-300" />
            )}
          </button>

          {/* User Profile / Auth Button */}
          {currentUser ? (
            <button
              onClick={() => setScreen('profile')}
              className="flex items-center gap-2 rounded-lg border border-amber-400/30 bg-neutral-900 px-2.5 py-1 text-xs font-semibold text-neutral-200 hover:border-amber-400 transition"
            >
              <div className="flex h-5 w-5 items-center justify-center rounded-full bg-amber-400 text-neutral-950 text-[10px] font-black">
                {currentUser.full_name?.charAt(0) || 'U'}
              </div>
              <span className="hidden md:inline max-w-[90px] truncate">{currentUser.full_name}</span>
            </button>
          ) : (
            <button
              onClick={() => setScreen('login')}
              className="flex items-center gap-1 rounded-lg border border-neutral-800 bg-neutral-900 px-2.5 py-1 text-xs font-medium text-neutral-200 hover:border-amber-400 hover:text-amber-400 transition"
            >
              <UserIcon className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">{t.loginBtn}</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
