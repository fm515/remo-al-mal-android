import React, { useState } from 'react';
import { Database, CheckCircle2, AlertTriangle, Key, ShieldCheck, X, RefreshCw, ExternalLink } from 'lucide-react';
import {
  SUPABASE_PROJECT_ID,
  SUPABASE_URL,
  STORAGE_BUCKET,
  saveAnonKey,
  clearAnonKey,
  testSupabaseConnection,
  SupabaseTestResult,
} from '../lib/supabase';
import { Language } from '../types';

interface SupabaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  onConnectionStatusChange?: (connected: boolean) => void;
}

export const SupabaseModal: React.FC<SupabaseModalProps> = ({
  isOpen,
  onClose,
  language,
  onConnectionStatusChange,
}) => {
  const [anonKeyInput, setAnonKeyInput] = useState(
    () => (typeof window !== 'undefined' ? localStorage.getItem('remo_supabase_anon_key') || '' : '')
  );
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<SupabaseTestResult | null>(null);

  if (!isOpen) return null;

  const handleTestAndSave = async () => {
    setTesting(true);
    setTestResult(null);

    if (anonKeyInput.trim()) {
      saveAnonKey(anonKeyInput.trim());
    }

    const res = await testSupabaseConnection();
    setTestResult(res);
    setTesting(false);
    if (onConnectionStatusChange) {
      onConnectionStatusChange(res.success);
    }
  };

  const handleReset = () => {
    clearAnonKey();
    setAnonKeyInput('');
    setTestResult(null);
    if (onConnectionStatusChange) {
      onConnectionStatusChange(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
      <div className="relative w-full max-w-lg rounded-2xl border border-neutral-800 bg-neutral-950 p-6 shadow-2xl">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 left-4 rtl:left-auto rtl:right-4 rounded-lg p-1 text-neutral-400 hover:bg-neutral-900 hover:text-white"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 border-b border-neutral-800/80 pb-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-400/10 text-amber-400">
            <Database className="h-5 w-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">
              {language === 'ar' ? 'مركز فحص وربط Supabase' : 'Supabase Integration Inspector'}
            </h3>
            <p className="text-xs text-neutral-400">
              {language === 'ar' ? 'إدارة الاتصال بمشروعك الحالي مع الالتزام بأمان RLS' : 'Manage your live Supabase connection with strict RLS security'}
            </p>
          </div>
        </div>

        {/* Project Credentials Overview */}
        <div className="mt-4 space-y-2 rounded-xl bg-neutral-900/90 p-3.5 border border-neutral-800 text-xs">
          <div className="flex justify-between items-center text-neutral-300">
            <span className="text-neutral-400 font-medium">Project ID:</span>
            <span className="font-mono text-amber-400 font-semibold">{SUPABASE_PROJECT_ID}</span>
          </div>
          <div className="flex justify-between items-center text-neutral-300">
            <span className="text-neutral-400 font-medium">Project URL:</span>
            <span className="font-mono text-neutral-200 truncate max-w-[240px]">{SUPABASE_URL}</span>
          </div>
          <div className="flex justify-between items-center text-neutral-300">
            <span className="text-neutral-400 font-medium">
              {language === 'ar' ? 'مساحة التخزين الخاصة:' : 'Private Storage Bucket:'}
            </span>
            <span className="font-mono text-emerald-400">{STORAGE_BUCKET}</span>
          </div>
          <div className="flex justify-between items-center text-neutral-300 pt-1 border-t border-neutral-800">
            <span className="text-neutral-400 font-medium">
              {language === 'ar' ? 'الجداول المفحوصة:' : 'Validated Tables:'}
            </span>
            <span className="text-[11px] text-neutral-300 font-mono">
              profiles, digital_products, orders, order_items, wallets, transactions
            </span>
          </div>
        </div>

        {/* Security Notice */}
        <div className="mt-3 flex items-start gap-2 rounded-xl bg-amber-400/5 p-3 border border-amber-400/20 text-xs text-amber-300">
          <ShieldCheck className="h-4 w-4 shrink-0 mt-0.5 text-amber-400" />
          <p className="leading-relaxed">
            {language === 'ar'
              ? 'تطبيق آمن 100%: نلتزم بعدم وضع مفتاح service_role إطلاقاً في التطبيق أو الـ APK. استخدم المفتاح العام المخصص للعميل (Anon Key) فقط، وسيتم تطبيق سياسات RLS وقواعد حماية الملفات تلقائياً.'
              : 'Strict Security: Only the public Anon Key is used on client/APK. Service_role keys are strictly excluded. Supabase RLS and token expiration govern all private assets.'}
          </p>
        </div>

        {/* Anon Key Input Form */}
        <div className="mt-4">
          <label className="block text-xs font-semibold text-neutral-200 mb-1.5">
            {language === 'ar' ? 'المفتاح العام المخصص للعميل (Anon / Publishable Key):' : 'Client Public Anon / Publishable Key:'}
          </label>
          <div className="relative">
            <input
              type="text"
              value={anonKeyInput}
              onChange={(e) => setAnonKeyInput(e.target.value)}
              placeholder="sb_publishable_... أو eyJhbGciOi..."
              className="w-full rounded-xl border border-neutral-800 bg-neutral-900 px-3.5 py-2.5 text-xs text-neutral-100 placeholder-neutral-500 font-mono focus:border-amber-400 focus:outline-none"
            />
          </div>
          <p className="mt-1 text-[11px] text-neutral-400">
            {language === 'ar'
              ? 'متوافق بالكامل مع المفاتيح العامة الحديثة (sb_publishable_...) والتقليدية (JWT anon).'
              : 'Fully compatible with modern Supabase keys (sb_publishable_...) and legacy JWT anon keys.'}
          </p>
        </div>

        {/* Test Result Feedback */}
        {testResult && (
          <div
            className={`mt-3 rounded-xl p-3 text-xs flex items-start gap-2 border ${
              testResult.success
                ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                : 'bg-rose-950/40 border-rose-500/40 text-rose-300'
            }`}
          >
            {testResult.success ? (
              <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5 text-emerald-400" />
            ) : (
              <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5 text-rose-400" />
            )}
            <div className="flex-1">
              <p className="font-semibold">{testResult.message}</p>
              {testResult.products && testResult.products.length > 0 && (
                <div className="mt-2.5 space-y-1.5 rounded-lg bg-black/50 p-2.5 border border-emerald-500/30">
                  <div className="text-[11px] font-bold text-emerald-300">
                    {language === 'ar' ? 'عينة من المنتجات المنشورة في Supabase:' : 'Sample live products in Supabase:'}
                  </div>
                  {testResult.products.map((p) => (
                    <div key={p.id} className="flex justify-between items-center text-[11px] text-neutral-200 border-b border-neutral-800/60 pb-1 last:border-0 last:pb-0">
                      <span className="truncate max-w-[180px] font-medium">{p.title}</span>
                      <span className="font-mono text-amber-400 font-bold">{p.price} {p.currency} · <span className="text-[10px] text-neutral-400">{p.status}</span></span>
                    </div>
                  ))}
                </div>
              )}
              {!testResult.success && (
                <div className="mt-1.5 space-y-1 text-[11px] text-neutral-400">
                  {testResult.errorCode && (
                    <div className="font-mono text-rose-400 font-semibold">
                      Error Code: {testResult.errorCode} {testResult.httpStatus ? `(HTTP ${testResult.httpStatus})` : ''}
                    </div>
                  )}
                  <p>
                    {language === 'ar'
                      ? 'ملاحظة: طالما لم يتم إدخال المفتاح العام، يوفر Remo Al-Mal بيئة تشغيل متكاملة محلياً تتيح لك اختبار كافة الشاشات الـ20 وعمليات الشراء وتوليد ملفات APK بسلاسة.'
                      : 'Note: Remo Al-Mal seamlessly provides a high-fidelity local sandbox ensuring all 20 screens, purchases, and APK generation work reliably.'}
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Buttons */}
        <div className="mt-5 flex gap-2">
          <button
            onClick={handleTestAndSave}
            disabled={testing}
            className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-amber-400 px-4 py-2.5 text-xs font-bold text-neutral-950 hover:bg-amber-300 transition disabled:opacity-50"
          >
            {testing ? (
              <RefreshCw className="h-4 w-4 animate-spin" />
            ) : (
              <CheckCircle2 className="h-4 w-4" />
            )}
            {language === 'ar' ? 'حفظ واختبار الاتصال المباشر' : 'Save & Test Connection'}
          </button>
          <button
            onClick={handleReset}
            className="rounded-xl border border-neutral-800 bg-neutral-900 px-3 py-2.5 text-xs font-medium text-neutral-400 hover:text-white transition"
          >
            {language === 'ar' ? 'مسح' : 'Clear'}
          </button>
        </div>
      </div>
    </div>
  );
};
