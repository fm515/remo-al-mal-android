import JSZip from 'jszip';

export interface AndroidExportOptions {
  appUrl: string;
  appName?: string;
  packageId?: string;
}

export const generateAndroidStudioProjectZip = async (options: AndroidExportOptions): Promise<Blob> => {
  const zip = new JSZip();
  const appName = options.appName || 'Remo Al-Mal';
  const packageId = options.packageId || 'com.remo.almal';
  const targetUrl = options.appUrl || window.location.origin;

  // 1. Root build.gradle.kts
  zip.file(
    'build.gradle.kts',
    `// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
}
`
  );

  // 2. settings.gradle.kts
  zip.file(
    'settings.gradle.kts',
    `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "RemoAlMal"
include(":app")
`
  );

  // 2.5. gradlew (executable shell script for Linux/Mac/Android Termux)
  zip.file(
    'gradlew',
    `#!/bin/sh
APP_BASE_NAME=\`basename "$0"\`
CLASSPATH=$APP_HOME/gradle/wrapper/gradle-wrapper.jar
exec java -Xmx64m -Dorg.gradle.appname=$APP_BASE_NAME -classpath "$CLASSPATH" org.gradle.wrapper.GradleWrapperMain "$@"
`
  );

  // 3. gradle/wrapper/gradle-wrapper.properties
  zip.file(
    'gradle/wrapper/gradle-wrapper.properties',
    `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.4-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`
  );

  // 4. gradle/libs.versions.toml
  zip.file(
    'gradle/libs.versions.toml',
    `[versions]
agp = "8.2.2"
kotlin = "1.9.22"
coreKtx = "1.12.0"
appcompat = "1.6.1"
material = "1.11.0"
constraintlayout = "2.1.4"
webkit = "1.10.0"
swiperefreshlayout = "1.1.0"

[libraries]
androidx-core-ktx = { group = "androidx.core", name = "core-ktx", version.ref = "coreKtx" }
androidx-appcompat = { group = "androidx.appcompat", name = "appcompat", version.ref = "appcompat" }
material = { group = "com.google.android.material", name = "material", version.ref = "material" }
androidx-constraintlayout = { group = "androidx.constraintlayout", name = "constraintlayout", version.ref = "constraintlayout" }
androidx-webkit = { group = "androidx.webkit", name = "webkit", version.ref = "webkit" }
androidx-swiperefreshlayout = { group = "androidx.swiperefreshlayout", name = "swiperefreshlayout", version.ref = "swiperefreshlayout" }

[plugins]
android-application = { id = "com.android.application", version.ref = "agp" }
kotlin-android = { id = "org.jetbrains.kotlin.android", version.ref = "kotlin" }
`
  );

  // 5. app/build.gradle.kts
  zip.file(
    'app/build.gradle.kts',
    `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "${packageId}"
    compileSdk = 34

    defaultConfig {
        applicationId = "${packageId}"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // Native Android configuration for Supabase (NO service_role, public client settings only)
        buildConfigField("String", "SUPABASE_URL", "\\"https://fyggwnhxgsvbelulyfsr.supabase.co\\"")
        buildConfigField("String", "SUPABASE_PROJECT_ID", "\\"fyggwnhxgsvbelulyfsr\\"")
        buildConfigField("String", "SUPABASE_ANON_KEY", "\\"\\"")
        buildConfigField("String", "APP_URL", "\\"${targetUrl}\\"")
    }

    buildFeatures {
        buildConfig = true
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("debug")
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.webkit)
    implementation(libs.androidx.swiperefreshlayout)
}
`
  );

  // 5.5. app/proguard-rules.pro
  zip.file(
    'app/proguard-rules.pro',
    `# Proguard rules for Remo Al-Mal Android App
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Application
-keep class kotlin.** { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.remo.almal.** { *; }
`
  );

  // 6. app/src/main/AndroidManifest.xml
  zip.file(
    'app/src/main/AndroidManifest.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <!-- Permissions required for network, downloads, and payments -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.DOWNLOAD_WITHOUT_NOTIFICATION" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.RemoAlMal"
        android:hardwareAccelerated="true"
        android:usesCleartextTraffic="false">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>

            <!-- App Links & Deep Links for Remo Al-Mal -->
            <intent-filter android:autoVerify="true">
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="https" android:host="remoalmal.com" />
            </intent-filter>
        </activity>
    </application>

</manifest>
`
  );

  // 7. app/src/main/java/com/remo/almal/MainActivity.kt
  zip.file(
    'app/src/main/java/com/remo/almal/MainActivity.kt',
    `package com.remo.almal

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.KeyEvent
import android.view.View
import android.webkit.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var swipeRefreshLayout: SwipeRefreshLayout
    private val APP_URL = "${targetUrl}"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Set status bar styling to Remo Al-Mal Midnight Black
        window.statusBarColor = getColor(R.color.remo_black)
        window.navigationBarColor = getColor(R.color.remo_black)

        swipeRefreshLayout = findViewById(R.id.swipeRefresh)
        webView = findViewById(R.id.webView)

        setupWebView()
        
        swipeRefreshLayout.setColorSchemeResources(R.color.remo_yellow, R.color.remo_black)
        swipeRefreshLayout.setOnRefreshListener {
            webView.reload()
        }

        webView.loadUrl(APP_URL)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.setSupportZoom(false)
        settings.displayZoomControls = false

        // User Agent adjustment for seamless Android experience
        val defaultUa = settings.userAgentString
        settings.userAgentString = "$defaultUa RemoAlMal-Android/1.0"

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                swipeRefreshLayout.isRefreshing = false
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                super.onReceivedError(view, request, error)
                swipeRefreshLayout.isRefreshing = false
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            // Allows modern web features & full file uploads
        }

        // Native Secure Download Manager for Digital Products (.zip, .pdf, .fig, etc.)
        webView.setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
            try {
                val request = DownloadManager.Request(Uri.parse(url))
                val filename = URLUtil.guessFileName(url, contentDisposition, mimetype)
                request.setMimeType(mimetype)
                request.addRequestHeader("User-Agent", userAgent)
                request.setDescription("Remo Al-Mal Digital Deliverable")
                request.setTitle(filename)
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename)

                val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                dm.enqueue(request)
                Toast.makeText(this, "جاري تنزيل الملف الرقمي: $filename", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "تعذر بدء التنزيل: \${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
`
  );

  // 8. app/src/main/res/layout/activity_main.xml
  zip.file(
    'app/src/main/res/layout/activity_main.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@color/remo_black">

    <androidx.swiperefreshlayout.widget.SwipeRefreshLayout
        android:id="@+id/swipeRefresh"
        android:layout_width="0dp"
        android:layout_height="0dp"
        app:layout_constraintTop_toTopOf="parent"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintEnd_toEndOf="parent">

        <WebView
            android:id="@+id/webView"
            android:layout_width="match_parent"
            android:layout_height="match_parent"
            android:background="@color/remo_black" />

    </androidx.swiperefreshlayout.widget.SwipeRefreshLayout>

</androidx.constraintlayout.widget.ConstraintLayout>
`
  );

  // 9. app/src/main/res/values/colors.xml
  zip.file(
    'app/src/main/res/values/colors.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <!-- Remo Al-Mal Official Black & Yellow Palette -->
    <color name="remo_black">#0A0A0C</color>
    <color name="remo_surface">#18181B</color>
    <color name="remo_yellow">#EAB308</color>
    <color name="remo_yellow_light">#FACC15</color>
    <color name="remo_yellow_dark">#CA8A04</color>
    <color name="white">#FFFFFF</color>
    <color name="gray_text">#A1A1AA</color>
</resources>
`
  );

  // 10. app/src/main/res/values/strings.xml
  zip.file(
    'app/src/main/res/values/strings.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">Remo Al-Mal</string>
    <string name="supabase_project_id">fyggwnhxgsvbelulyfsr</string>
    <string name="supabase_url">https://fyggwnhxgsvbelulyfsr.supabase.co</string>
    <string name="supabase_anon_key"></string>
    <string name="app_url">${targetUrl}</string>
</resources>
`
  );

  // 10.5. app/src/main/java/com/remo/almal/RemoConfig.kt
  zip.file(
    'app/src/main/java/com/remo/almal/RemoConfig.kt',
    `package com.remo.almal

import android.content.Context

object RemoConfig {
    const val DEFAULT_PROJECT_ID = "fyggwnhxgsvbelulyfsr"
    const val DEFAULT_SUPABASE_URL = "https://fyggwnhxgsvbelulyfsr.supabase.co"
    const val STORAGE_BUCKET = "digital-product-files"

    fun getSupabaseHeaders(context: Context): Map<String, String> {
        val prefs = context.getSharedPreferences("remo_almal_prefs", Context.MODE_PRIVATE)
        val resId = context.resources.getIdentifier("supabase_anon_key", "string", context.packageName)
        val anonKey = prefs.getString("supabase_anon_key", "")?.takeIf { it.isNotBlank() }
            ?: (if (resId != 0) context.getString(resId) else "")

        val headers = mutableMapOf(
            "Content-Type" to "application/json",
            "Accept" to "application/json"
        )
        if (anonKey.isNotBlank()) {
            headers["apikey"] = anonKey
            headers["Authorization"] = "Bearer $anonKey"
        }
        return headers
    }
}
`
  );

  // 11. app/src/main/res/values/themes.xml
  zip.file(
    'app/src/main/res/values/themes.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.RemoAlMal" parent="Theme.MaterialComponents.DayNight.NoActionBar">
        <item name="colorPrimary">@color/remo_yellow</item>
        <item name="colorPrimaryVariant">@color/remo_yellow_dark</item>
        <item name="colorOnPrimary">@color/remo_black</item>
        <item name="android:statusBarColor">@color/remo_black</item>
        <item name="android:navigationBarColor">@color/remo_black</item>
        <item name="android:windowBackground">@color/remo_black</item>
    </style>
</resources>
`
  );

  // 12. GitHub Actions Automated 100% Free APK Builder: .github/workflows/build-apk.yml
  zip.file(
    '.github/workflows/build-apk.yml',
    `name: Build Remo Al-Mal Android APK

on:
  push:
    branches: [ "main", "master" ]
  workflow_dispatch:

jobs:
  build:
    name: Compile Android APK (Debug & Release)
    runs-on: ubuntu-latest

    steps:
      - name: Checkout Source Code
        uses: actions/checkout@v4

      - name: Set up Java JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '17'
          cache: 'gradle'

      - name: Grant Execute Permission to Gradlew
        run: chmod +x gradlew || true

      - name: Build Debug & Release APK
        run: |
          if [ -f "./gradlew" ]; then
            ./gradlew assembleDebug assembleRelease --stacktrace
          else
            gradle assembleDebug assembleRelease --stacktrace
          fi

      - name: Upload Debug APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: Remo-AlMal-Debug-APK
          path: app/build/outputs/apk/debug/*.apk

      - name: Upload Release APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: Remo-AlMal-Release-APK
          path: app/build/outputs/apk/release/*.apk
`
  );

  // 13. Comprehensive Arabic & English step-by-step instructions
  zip.file(
    'README-APK-INSTRUCTIONS-AR.md',
    `# دليل استخراج وتثبيت تطبيق Remo Al-Mal على Android مجاناً 100%

مرحباً بك! هذا المشروع الأصلي الكامل لتطبيق **Remo Al-Mal (com.remo.almal)**.
بما أنك تعمل من هاتف أندرويد وترغب في أدوات مجانية تماماً وبدون تعقيدات، إليك أسهل وأقوى طريقتين:

---

## ⚡ الطريقة الأولى (الأسرع والأسهل عبر هاتفك مباشرة في دقيقتين):
### بناء الـ APK مجاناً عبر GitHub Actions دون الحاجة لجهاز كمبيوتر!

1. أنشئ حساباً مجانياً على موقع [GitHub.com](https://github.com) من متصفح هاتفك.
2. أنشئ مستودعاً جديداً (New Repository) وسمّه مثلاً \`remo-almal-android\`.
3. اضغط على زر **Add file > Upload files** وقم برفع محتويات هذا الملف المضغوط (ZIP) إليه.
4. اذهب إلى تبويب **Actions** في المستودع.
5. ستجد خطة البناء \`Build Remo Al-Mal Android APK\` تعمل تلقائياً!
6. بعد انتهاء البناء (يستغرق حوالي دقيقة ونصف)، اضغط على اسم المهمة وستجد تحت خانة **Artifacts** ملفي:
   - \`Remo-AlMal-Debug-APK\` (جاهز للتثبيت المباشر على هاتفك وتجربته فوراً)
   - \`Remo-AlMal-Release-APK\` (النسخة النهائية للإنتاج)
7. حمّل الملف وثبته على هاتفك فوراً!

---

## 📱 الطريقة الثانية (تثبيت فوري كـ WebAPK):
افتح تطبيق Remo Al-Mal من متصفح Chrome على هاتفك، واضغط على زر **"تثبيت التطبيق على هاتفي"** (أو من قائمة خيارات Chrome: **"الإضافة إلى الشاشة الرئيسية / تثبيت التطبيق"**).
سيقوم نظام أندرويد ببناء وتثبيت حزمة WebAPK أصلية بأيقونة التطبيق الرسمية الذهبية والسوداء وتظهر في قائمة تطبيقات هاتفك مثل أي تطبيق مثبت من المتجر!

---

## 💻 الطريقة الثالثة (عبر Android Studio إذا توفر كمبيوتر):
1. فك ضغط ملف ZIP في مجلد على جهازك.
2. افتح برنامج **Android Studio** واختر **Open Existing Project**.
3. انتظر حتى يكتمل مزامنة Gradle.
4. اذهب إلى القائمة: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. ستجد ملف الـ APK في المجلد: \`app/build/outputs/apk/debug/app-debug.apk\`.

---

## 🔐 خطوات إنتاج نسخة Release موقّعة (Signed Release APK):
1. داخل Android Studio، اختر: **Build > Generate Signed Bundle / APK**.
2. اختر **APK** واضغط **Next**.
3. اضغط على **Create new...** لإنشاء مفتاح التوقيع الخاص بك (Keystore / .jks).
4. حدد كلمة سر قوية، ثم اضغط **Next** واختر نوع البناء **Release** وضع علامة على **V1 و V2 Signature**.
5. ستحصل على ملف APK موقّع جاهز تماماً للنشر أو التوزيع الآمن.
`
  );

  return await zip.generateAsync({ type: 'blob' });
};
