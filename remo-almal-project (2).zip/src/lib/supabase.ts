import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { DigitalProduct, Order, UserProfile, Wallet, WalletTransaction } from '../types';

export const SUPABASE_PROJECT_ID = 'fyggwnhxgsvbelulyfsr';

/**
 * Resolves Supabase URL from standard VITE_SUPABASE_URL or defaults to verified project URL
 */
export const getSupabaseUrl = (): string => {
  if (typeof window !== 'undefined') {
    const savedUrl = localStorage.getItem('remo_supabase_url');
    if (savedUrl && savedUrl.trim()) return savedUrl.trim();
  }

  const env = (import.meta as any).env || {};
  const metaUrl = env.VITE_SUPABASE_URL;
  if (metaUrl && typeof metaUrl === 'string' && metaUrl.trim()) {
    return metaUrl.trim();
  }

  if (typeof process !== 'undefined' && process.env) {
    const procUrl = process.env.VITE_SUPABASE_URL;
    if (procUrl && typeof procUrl === 'string' && procUrl.trim()) {
      return procUrl.trim();
    }
  }

  return `https://${SUPABASE_PROJECT_ID}.supabase.co`;
};

export const SUPABASE_URL = getSupabaseUrl();
export const STORAGE_BUCKET = 'digital-product-files';

/**
 * Resolves public client key from VITE_SUPABASE_ANON_KEY or local browser storage.
 * Compatible with modern Supabase publishable keys (sb_publishable_...) and legacy JWT anon keys.
 * NEVER loads or uses sb_secret or service_role in client-side code!
 */
export const getStoredAnonKey = (): string => {
  // 1. Browser localStorage (allows user configuration directly on mobile / preview)
  if (typeof window !== 'undefined') {
    const saved = localStorage.getItem('remo_supabase_anon_key');
    if (saved && saved.trim()) return saved.trim();
  }

  // 2. Standard Vite client environment variable
  const env = (import.meta as any).env || {};
  const metaKey = env.VITE_SUPABASE_ANON_KEY;
  if (metaKey && typeof metaKey === 'string' && metaKey.trim()) {
    return metaKey.trim();
  }

  // 3. Fallback for Node / test execution environment
  if (typeof process !== 'undefined' && process.env) {
    const procKey = process.env.VITE_SUPABASE_ANON_KEY;
    if (procKey && typeof procKey === 'string' && procKey.trim()) {
      return procKey.trim();
    }
  }

  return '';
};

/**
 * Constructs appropriate HTTP headers for direct REST fetch requests.
 * Ensures 'apikey' is ALWAYS attached.
 * For sb_publishable_ keys, avoids sending 'Authorization: Bearer sb_publishable_...'
 * to prevent PostgREST JWT decode failure.
 */
export const getRestHeaders = (key: string, userJwtToken?: string): Record<string, string> => {
  const headers: Record<string, string> = {
    apikey: key.trim(),
    Accept: 'application/json',
    'Content-Type': 'application/json',
  };

  if (userJwtToken && userJwtToken.trim()) {
    // If an authenticated user session token is present, use it
    headers['Authorization'] = `Bearer ${userJwtToken.trim()}`;
  } else if (!key.startsWith('sb_publishable_') && key.split('.').length === 3) {
    // Legacy anon JWT key containing 3 base64 segments
    headers['Authorization'] = `Bearer ${key.trim()}`;
  }
  // For sb_publishable_ keys without active user login, omit Authorization header
  // Kong API gateway authenticates via apikey header alone.

  return headers;
};

let supabaseInstance: SupabaseClient | null = null;
let activeClientKey: string | null = null;

/**
 * Initializes and returns a configured SupabaseClient.
 * Configures global fetch interceptor to prevent conflicting or malformed Bearer headers
 * when using modern sb_publishable_ keys.
 */
export const getSupabaseClient = (customKey?: string): SupabaseClient | null => {
  const key = (customKey || getStoredAnonKey()).trim();
  if (!key) return null;

  try {
    if (!supabaseInstance || activeClientKey !== key) {
      const isPublishableKey = key.startsWith('sb_publishable_');

      // Custom fetch handler to intercept outgoing requests from @supabase/supabase-js:
      // 1. Ensures apikey header is always set
      // 2. If using sb_publishable_ key, removes any default unauthenticated "Authorization: Bearer sb_publishable_..."
      //    injected by older client defaults, while preserving genuine user auth session JWT tokens.
      const customFetch: typeof fetch = async (input, init = {}) => {
        const reqHeaders = new Headers(init.headers || {});
        
        if (!reqHeaders.has('apikey')) {
          reqHeaders.set('apikey', key);
        }

        const authHeader = reqHeaders.get('Authorization') || reqHeaders.get('authorization');
        if (isPublishableKey && authHeader && authHeader.trim() === `Bearer ${key}`) {
          // Strip duplicate/unparseable Bearer on publishable key
          reqHeaders.delete('Authorization');
          reqHeaders.delete('authorization');
        }

        return fetch(input, {
          ...init,
          headers: reqHeaders,
        });
      };

      supabaseInstance = createClient(SUPABASE_URL, key, {
        auth: {
          persistSession: true,
          autoRefreshToken: true,
        },
        global: {
          fetch: customFetch,
          headers: {
            apikey: key,
          },
        },
      });

      activeClientKey = key;
    }
    return supabaseInstance;
  } catch (err) {
    console.warn('Failed to initialize Supabase client:', err);
    return null;
  }
};

export const saveAnonKey = (key: string) => {
  if (typeof window !== 'undefined') {
    localStorage.setItem('remo_supabase_anon_key', key.trim());
    supabaseInstance = null; // force reload
    activeClientKey = null;
  }
};

export const clearAnonKey = () => {
  if (typeof window !== 'undefined') {
    localStorage.removeItem('remo_supabase_anon_key');
    supabaseInstance = null;
    activeClientKey = null;
  }
};

// Initial Seed data for fallback & offline preview reliability
export const INITIAL_PRODUCTS: DigitalProduct[] = [
  {
    id: 'prod-001',
    seller_id: 'seller-remo-01',
    seller_name: 'ريمو ديجيتال ستوديو',
    title: 'حزمة قوالب تطبيقات Android و Flutter المتكاملة Pro',
    title_en: 'Android & Flutter Full App Architecture Template Pro',
    description: 'كود سورس كامل لتطبيق متجر إلكتروني أصلي مكتوب بـ Kotlin و Jetpack Compose مع دعم الدفع والمحافظ والوضع الليلي.',
    description_en: 'Production-ready native Android e-commerce template written with Jetpack Compose & Kotlin, fully architected with Clean Architecture.',
    price: 49.0,
    currency: 'USD',
    category: 'software',
    preview_image: 'https://images.unsplash.com/photo-1607252650355-f7fd0460ccdb?w=800&auto=format&fit=crop&q=80',
    file_path: 'templates/android-pro-pack.zip',
    file_name: 'remo-android-suite-v2.4.zip',
    file_size: '42.8 MB',
    file_type: 'ZIP / Kotlin',
    downloads_count: 142,
    rating: 4.9,
    reviews_count: 38,
    status: 'published',
    features: [
      'Jetpack Compose 100% Native',
      'Clean Architecture & MVVM',
      'دعم كامل للغة العربية RTL',
      'تكامل جاهز مع Supabase و Firebase',
      'ترخيص استخدام تجاري مفتوح'
    ],
    created_at: new Date(Date.now() - 86400000 * 4).toISOString(),
  },
  {
    id: 'prod-002',
    seller_id: 'seller-remo-02',
    seller_name: 'سفيان للأمن السيبراني',
    title: 'دليل الأمان المالي واكتشاف ثغرات العقود الذكية 2026',
    title_en: 'Financial Security & Smart Contract Audit Playbook 2026',
    description: 'كتاب تقني شامل (PDF + شفرات فحص) لحماية تطبيقات الدفع المشفر والتأكد من أمان معاملات TRC-20 و BEP-20.',
    description_en: 'Comprehensive technical handbook and scripts for securing crypto payments and preventing double-spend attacks.',
    price: 29.5,
    currency: 'USD',
    category: 'ebooks',
    preview_image: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=800&auto=format&fit=crop&q=80',
    file_path: 'ebooks/crypto-security-playbook.pdf',
    file_name: 'crypto-audit-guide-v4.pdf',
    file_size: '18.4 MB',
    file_type: 'PDF + Scripts',
    downloads_count: 89,
    rating: 4.8,
    reviews_count: 19,
    status: 'published',
    features: [
      '350 صفحة مرجعية مفصلة',
      'سكربتات فحص المعاملات بالبايثون',
      'أمثلة اختبار حية لمعاملات USDT',
      'تحديثات مجانية لمدة عام'
    ],
    created_at: new Date(Date.now() - 86400000 * 7).toISOString(),
  },
  {
    id: 'prod-003',
    seller_id: 'seller-remo-01',
    seller_name: 'ريمو ديجيتال ستوديو',
    title: 'نظام إدارة البوابات الرقمية والدفع المشفر (Node + TS)',
    title_en: 'Crypto Payment Gateway Webhook Engine (Node & TypeScript)',
    description: 'سكربت خادم متكامل للتحقق الآمن من مدفوعات TRC20 و BEP20 بدون وسطاء، مع دعم Webhooks موقّعة ومنع الازدواجية.',
    description_en: 'Server-side payment verification engine with cryptographic signature verification for Tron & BSC blockchain transactions.',
    price: 79.0,
    currency: 'USD',
    category: 'scripts',
    preview_image: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=80',
    file_path: 'scripts/crypto-gateway-engine.zip',
    file_name: 'crypto-webhook-engine-ts.zip',
    file_size: '8.2 MB',
    file_type: 'TypeScript / Node.js',
    downloads_count: 215,
    rating: 5.0,
    reviews_count: 54,
    status: 'published',
    features: [
      'منع الازدواجية والتأكيد المزدوج Idempotent',
      'تكامل جاهز مع Supabase PostgreSQL',
      'دعم كامل لشبكتي TRC-20 و BEP-20',
      'لوحة مراقبة حية للمعاملات'
    ],
    created_at: new Date(Date.now() - 86400000 * 12).toISOString(),
  },
  {
    id: 'prod-004',
    seller_id: 'seller-remo-03',
    seller_name: 'إيليت يو آي ديزاين',
    title: 'حزمة تصاميم تطبيقات المحافظ والتمويل الفاخرة (Figma 2026)',
    title_en: 'Luxury Fintech & Wallet App UI Kit for Figma',
    description: 'أكثر من 180 شاشة احترافية بأسلوب أسود وذهبي وأصفر فاخر متوافقة مع إرشادات Material 3 و iOS.',
    description_en: '180+ handcrafted luxury dark & gold UI screens designed specifically for crypto wallets and modern fintech apps.',
    price: 35.0,
    currency: 'USD',
    category: 'templates',
    preview_image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&auto=format&fit=crop&q=80',
    file_path: 'templates/luxury-fintech-figma.fig',
    file_name: 'remo-fintech-master.fig',
    file_size: '64.1 MB',
    file_type: 'Figma (.fig)',
    downloads_count: 310,
    rating: 4.9,
    reviews_count: 67,
    status: 'published',
    features: [
      '180+ شاشة مصممة بدقة',
      'نظام ألوان Black & Yellow متناسق',
      'Auto-Layout 5.0 و Variables',
      'دعم كامل لنسختي RTL العربية و LTR'
    ],
    created_at: new Date(Date.now() - 86400000 * 20).toISOString(),
  }
];

export interface SupabaseTestResult {
  success: boolean;
  httpStatus: number;
  errorCode: string;
  message: string;
  rowCount?: number;
  products?: Array<{
    id: string;
    title: string;
    price: number;
    currency: string;
    status: string;
  }>;
  details?: Record<string, unknown>;
}

/**
 * Performs a live diagnostic test against Supabase digital_products table.
 * Clearly isolates configuration vs gateway vs data errors.
 */
export const testSupabaseConnection = async (): Promise<SupabaseTestResult> => {
  const key = getStoredAnonKey();

  // If no key is set yet, report clear diagnostic status explaining the missing variable
  if (!key) {
    return {
      success: false,
      httpStatus: 401,
      errorCode: 'UNAUTHORIZED_MISSING_API_KEY',
      message: 'لم يتم العثور على المفتاح العام (VITE_SUPABASE_ANON_KEY) في متغيرات البيئة أو التطبيق. يتطلب خادم Supabase Kong Gateway ترويسة apikey صالحة في كل طلب (sb_publishable_... أو anon key).',
      details: {
        projectUrl: SUPABASE_URL,
        projectId: SUPABASE_PROJECT_ID,
        requiredVariable: 'VITE_SUPABASE_ANON_KEY',
        hint: 'أدخل المفتاح العام المخصص للعميل عبر نافذة Environment Variables أو من نافذة مركز Supabase بأعلى الشاشة.',
      },
    };
  }

  // Key is provided: Send genuine GET request with apikey header to digital_products table
  try {
    const headers = getRestHeaders(key);

    const res = await fetch(`${SUPABASE_URL}/rest/v1/digital_products?select=*`, {
      method: 'GET',
      headers,
    });

    const status = res.status;
    const errorCode = res.headers.get('sb-error-code') || '';

    if (!res.ok) {
      const errorBody = await res.json().catch(() => ({}));
      return {
        success: false,
        httpStatus: status,
        errorCode: errorCode || (status === 401 ? 'UNAUTHORIZED' : `HTTP_${status}`),
        message: `استجابة خادم Supabase الفعلية (HTTP ${status}): ${errorBody.message || 'خطأ في المصادقة'}. ${errorBody.hint ? `(${errorBody.hint})` : ''}`,
        details: {
          httpStatus: status,
          errorCode,
          errorBody,
        },
      };
    }

    const rawData = await res.json();
    const rows = Array.isArray(rawData) ? rawData : [];

    const productsSummary = rows.map((r: any) => ({
      id: String(r.id),
      title: String(r.title || r.title_en || 'منتج رقمي'),
      price: typeof r.price === 'number' ? r.price : parseFloat(r.price) || 0,
      currency: String(r.currency || 'USD'),
      status: String(r.status || 'published'),
    }));

    return {
      success: true,
      httpStatus: 200,
      errorCode: 'OK',
      message: `تم الاتصال بنجاح بمشروع Supabase (${SUPABASE_PROJECT_ID})! تم قراءة (${rows.length}) منتجات فعلية من جدول digital_products.`,
      rowCount: rows.length,
      products: productsSummary,
      details: {
        totalRows: rows.length,
        table: 'digital_products',
        endpoint: `${SUPABASE_URL}/rest/v1/digital_products`,
      },
    };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    return {
      success: false,
      httpStatus: 0,
      errorCode: 'FETCH_FAILED',
      message: `خطأ أثناء الاتصال بقاعدة البيانات: ${msg}`,
    };
  }
};

/**
 * Fetch real products from Supabase digital_products table
 */
export const fetchRealProducts = async (): Promise<{
  data: DigitalProduct[] | null;
  error: string | null;
  count: number;
}> => {
  const key = getStoredAnonKey();
  if (!key) {
    return {
      data: null,
      error: 'المفتاح العام (VITE_SUPABASE_ANON_KEY) غير مسجل. يرجى إدخال المفتاح العام المخصص للعميل للاتصال.',
      count: 0,
    };
  }

  try {
    const headers = getRestHeaders(key);

    const res = await fetch(`${SUPABASE_URL}/rest/v1/digital_products?select=*`, {
      method: 'GET',
      headers,
    });

    if (!res.ok) {
      const errJson = await res.json().catch(() => ({}));
      return {
        data: null,
        error: `Supabase HTTP ${res.status}: ${errJson.message || 'Failed to fetch products'}`,
        count: 0,
      };
    }

    const data = await res.json();
    if (!Array.isArray(data) || data.length === 0) {
      return {
        data: [],
        error: null,
        count: 0,
      };
    }

    // Map Supabase rows to DigitalProduct interface cleanly
    const mapped: DigitalProduct[] = data.map((row: any) => ({
      id: String(row.id),
      seller_id: row.seller_id || 'seller-unknown',
      seller_name: row.seller_name || 'بائع موثّق',
      title: row.title || 'منتج رقمي',
      title_en: row.title_en || row.title || 'Digital Product',
      description: row.description || '',
      description_en: row.description_en || row.description || '',
      price: typeof row.price === 'number' ? row.price : parseFloat(row.price) || 0,
      currency: row.currency || 'USD',
      category: row.category || 'software',
      preview_image: row.preview_image || 'https://images.unsplash.com/photo-1607252650355-f7fd0460ccdb?w=800&auto=format&fit=crop&q=80',
      file_path: row.file_path || '',
      file_name: row.file_name || 'deliverable.zip',
      file_size: row.file_size || 'N/A',
      file_type: row.file_type || 'Digital Asset',
      downloads_count: typeof row.downloads_count === 'number' ? row.downloads_count : 0,
      rating: typeof row.rating === 'number' ? row.rating : 5.0,
      reviews_count: typeof row.reviews_count === 'number' ? row.reviews_count : 0,
      status: row.status === 'draft' ? 'draft' : 'published',
      features: Array.isArray(row.features) ? row.features : ['تسليم رقمي فوري', 'ترخيص استخدام كامل'],
      created_at: row.created_at || new Date().toISOString(),
    }));

    return {
      data: mapped,
      error: null,
      count: mapped.length,
    };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    return {
      data: null,
      error: msg,
      count: 0,
    };
  }
};

/**
 * Create a secure expiring signed URL for deliverable files in digital-product-files private bucket
 */
export const createSecureSignedUrl = async (filePath: string): Promise<{
  signedUrl: string | null;
  error: string | null;
}> => {
  const client = getSupabaseClient();
  if (!client) {
    return {
      signedUrl: null,
      error: 'لم يتم ضبط المفتاح العام للاتصال بـ Supabase Storage.',
    };
  }

  try {
    const { data, error } = await client.storage
      .from(STORAGE_BUCKET)
      .createSignedUrl(filePath, 3600); // 60 minutes expiry

    if (error) {
      return {
        signedUrl: null,
        error: error.message,
      };
    }

    return {
      signedUrl: data?.signedUrl || null,
      error: null,
    };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    return {
      signedUrl: null,
      error: msg,
    };
  }
};
