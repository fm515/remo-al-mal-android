export type Language = 'ar' | 'en';
export type Theme = 'dark' | 'light';

export type Screen =
  | 'splash'
  | 'home'
  | 'all_products'
  | 'search'
  | 'product_details'
  | 'register'
  | 'login'
  | 'profile'
  | 'seller_dashboard'
  | 'add_edit_product'
  | 'orders'
  | 'order_details'
  | 'payment_method'
  | 'payment_status'
  | 'purchased_products'
  | 'settings'
  | 'help_support'
  | 'privacy_policy'
  | 'terms_of_service'
  | 'connection_error'
  | 'apk_export';

export type UserRole = 'buyer' | 'seller';

export interface UserProfile {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  avatar_url?: string;
  phone?: string;
  created_at: string;
}

export type ProductCategory =
  | 'software'
  | 'ebooks'
  | 'scripts'
  | 'templates'
  | 'graphics'
  | 'courses'
  | 'licenses';

export interface DigitalProduct {
  id: string;
  seller_id: string;
  seller_name?: string;
  title: string;
  title_en?: string;
  description: string;
  description_en?: string;
  price: number;
  currency: string;
  category: ProductCategory;
  preview_image: string;
  file_path: string;
  file_name?: string;
  file_size?: string;
  file_type?: string;
  downloads_count: number;
  rating: number;
  reviews_count: number;
  status: 'published' | 'draft';
  features?: string[];
  created_at: string;
}

export type PaymentMethod =
  | 'crypto_usdt_trc20'
  | 'crypto_usdt_bep20'
  | 'card_visa_mastercard'
  | 'wallet';

export type OrderStatus = 'pending' | 'paid' | 'completed' | 'cancelled';

export interface Order {
  id: string;
  buyer_id: string;
  seller_id: string;
  product_id: string;
  product_title: string;
  product_image?: string;
  total_amount: number;
  commission_fee: number; // 10%
  seller_net_amount: number; // 90%
  status: OrderStatus;
  payment_method: PaymentMethod;
  payment_ref?: string;
  tx_hash?: string;
  download_token?: string;
  download_expires_at?: string;
  created_at: string;
}

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string;
  price: number;
  quantity: number;
}

export interface Wallet {
  id: string;
  user_id: string;
  balance: number;
  pending_balance: number;
  currency: string;
  updated_at: string;
}

export interface WalletTransaction {
  id: string;
  wallet_id: string;
  type: 'deposit' | 'purchase' | 'sale_earning' | 'withdrawal' | 'fee';
  amount: number;
  description: string;
  status: 'completed' | 'pending' | 'failed';
  created_at: string;
}

export interface SupabaseConfigState {
  url: string;
  anonKey: string;
  isConnected: boolean;
  isLoading: boolean;
  lastChecked: string | null;
  error: string | null;
}
