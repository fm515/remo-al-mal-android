import React, { useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Upload,
  Image as ImageIcon,
  DollarSign,
  Layers,
  FileCode,
  ShieldCheck,
  CheckCircle2,
  Lock
} from 'lucide-react';
import { DigitalProduct, Language, ProductCategory, UserProfile } from '../types';
import { translations } from '../lib/i18n';
import { STORAGE_BUCKET, getSupabaseClient } from '../lib/supabase';

interface AddEditProductScreenProps {
  initialProduct?: DigitalProduct | null;
  currentUser: UserProfile;
  language: Language;
  onSave: (product: DigitalProduct) => void;
  onCancel: () => void;
}

export const AddEditProductScreen: React.FC<AddEditProductScreenProps> = ({
  initialProduct,
  currentUser,
  language,
  onSave,
  onCancel,
}) => {
  const t = translations[language];
  const isEditing = Boolean(initialProduct);

  const [title, setTitle] = useState(initialProduct?.title || '');
  const [description, setDescription] = useState(initialProduct?.description || '');
  const [price, setPrice] = useState(initialProduct ? initialProduct.price.toString() : '29.00');
  const [category, setCategory] = useState<ProductCategory>(initialProduct?.category || 'software');
  const [previewImage, setPreviewImage] = useState(
    initialProduct?.preview_image ||
      'https://images.unsplash.com/photo-1607252650355-f7fd0460ccdb?w=800&auto=format&fit=crop&q=80'
  );
  const [fileName, setFileName] = useState(initialProduct?.file_name || 'remo-digital-asset-v1.zip');
  const [fileType, setFileType] = useState(initialProduct?.file_type || 'ZIP / Source Code');
  const [fileSize, setFileSize] = useState(initialProduct?.file_size || '35.4 MB');
  const [saving, setSaving] = useState(false);

  const categories: { id: ProductCategory; label: string }[] = [
    { id: 'software', label: t.catSoftware },
    { id: 'ebooks', label: t.catEbooks },
    { id: 'scripts', label: t.catScripts },
    { id: 'templates', label: t.catTemplates },
    { id: 'graphics', label: t.catGraphics },
    { id: 'licenses', label: t.catLicenses },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    const productPayload: DigitalProduct = {
      id: initialProduct?.id || `prod-${Date.now()}`,
      seller_id: initialProduct?.seller_id || currentUser.id,
      seller_name: currentUser.full_name || 'Remo Official Seller',
      title: title.trim(),
      title_en: title.trim(),
      description: description.trim(),
      description_en: description.trim(),
      price: parseFloat(price) || 10,
      currency: 'USD',
      category: category,
      preview_image: previewImage.trim(),
      file_path: `${category}/${fileName}`,
      file_name: fileName,
      file_size: fileSize,
      file_type: fileType,
      downloads_count: initialProduct?.downloads_count || 0,
      rating: initialProduct?.rating || 5.0,
      reviews_count: initialProduct?.reviews_count || 1,
      status: 'published',
      features: [
        'تسليم رقمي فوري مشفّر',
        'ترخيص استخدام كامل',
        'دعم فني من البائع',
      ],
      created_at: initialProduct?.created_at || new Date().toISOString(),
    };

    setTimeout(() => {
      onSave(productPayload);
      setSaving(false);
    }, 400);
  };

  return (
    <div className="mx-auto max-w-xl pb-24">
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <button
          onClick={onCancel}
          className="flex items-center gap-2 rounded-xl border border-neutral-800 bg-neutral-900 px-3 py-1.5 text-xs font-semibold text-neutral-300 hover:text-white"
        >
          {language === 'ar' ? <ArrowRight className="h-4 w-4" /> : <ArrowLeft className="h-4 w-4" />}
          <span>{t.cancelBtn}</span>
        </button>

        <h1 className="text-base font-bold text-white sm:text-lg">
          {isEditing ? t.editProductTitle : t.addProductTitle}
        </h1>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4 rounded-3xl border border-neutral-800 bg-neutral-900/80 p-5 sm:p-6 shadow-2xl">
        {/* Title */}
        <div>
          <label className="block text-xs font-bold text-neutral-300 mb-1">
            {t.productNameAr}
          </label>
          <input
            type="text"
            required
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="مثال: تطبيق متجر إلكتروني متكامل Kotlin & Compose"
            className="w-full rounded-xl border border-neutral-800 bg-neutral-950 px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:border-amber-400 focus:outline-none"
          />
        </div>

        {/* Description */}
        <div>
          <label className="block text-xs font-bold text-neutral-300 mb-1">
            {t.productDescAr}
          </label>
          <textarea
            required
            rows={4}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="اكتب وصفاً مفصلاً للمنتج الرقمي وما يحتويه وطريقة تشغيله..."
            className="w-full rounded-xl border border-neutral-800 bg-neutral-950 p-3 text-xs text-white placeholder-neutral-500 focus:border-amber-400 focus:outline-none leading-relaxed"
          />
        </div>

        {/* Price & Category in 2 columns */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold text-neutral-300 mb-1">
              {t.productPrice}
            </label>
            <div className="relative">
              <DollarSign className="absolute top-1/2 -translate-y-1/2 left-3 rtl:left-auto rtl:right-3 h-4 w-4 text-amber-400" />
              <input
                type="number"
                step="0.5"
                min="1"
                required
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="w-full rounded-xl border border-neutral-800 bg-neutral-950 py-2.5 px-9 text-xs text-white font-bold focus:border-amber-400 focus:outline-none"
              />
            </div>
            <p className="mt-1 text-[10px] text-neutral-400">
              {language === 'ar' ? 'يتم احتساب 10% عمولة للمنصة و 90% لك صافياً' : '10% platform fee, 90% net to seller'}
            </p>
          </div>

          <div>
            <label className="block text-xs font-bold text-neutral-300 mb-1">
              {t.productCategory}
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as ProductCategory)}
              className="w-full rounded-xl border border-neutral-800 bg-neutral-950 py-2.5 px-3 text-xs text-white focus:border-amber-400 focus:outline-none"
            >
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Preview Image URL */}
        <div>
          <label className="block text-xs font-bold text-neutral-300 mb-1">
            {t.previewImageUrl}
          </label>
          <div className="relative">
            <ImageIcon className="absolute top-1/2 -translate-y-1/2 left-3 rtl:left-auto rtl:right-3 h-4 w-4 text-neutral-500" />
            <input
              type="url"
              required
              value={previewImage}
              onChange={(e) => setPreviewImage(e.target.value)}
              className="w-full rounded-xl border border-neutral-800 bg-neutral-950 py-2.5 px-9 text-xs text-white placeholder-neutral-500 focus:border-amber-400 focus:outline-none"
            />
          </div>
        </div>

        {/* Private Deliverable File Configuration (digital-product-files) */}
        <div className="rounded-2xl border border-neutral-800 bg-neutral-950 p-4">
          <div className="flex items-center gap-2 mb-2 text-xs font-bold text-amber-400">
            <Lock className="h-4 w-4" />
            <span>{t.fileUploadTitle}</span>
          </div>
          <p className="text-[11px] text-neutral-400 leading-relaxed mb-3">
            {t.fileUploadDesc}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            <div>
              <label className="block text-[11px] font-medium text-neutral-400 mb-1">
                {language === 'ar' ? 'اسم الملف الرقمي:' : 'File Deliverable Name:'}
              </label>
              <input
                type="text"
                value={fileName}
                onChange={(e) => setFileName(e.target.value)}
                className="w-full rounded-lg border border-neutral-800 bg-neutral-900 px-3 py-1.5 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-[11px] font-medium text-neutral-400 mb-1">
                {language === 'ar' ? 'الحجم والنوع التقريبي:' : 'Approx. Size & Type:'}
              </label>
              <input
                type="text"
                value={`${fileSize} • ${fileType}`}
                onChange={(e) => {
                  const parts = e.target.value.split('•');
                  setFileSize(parts[0]?.trim() || '25 MB');
                  setFileType(parts[1]?.trim() || 'ZIP');
                }}
                className="w-full rounded-lg border border-neutral-800 bg-neutral-900 px-3 py-1.5 text-xs text-white"
              />
            </div>
          </div>

          <div className="mt-3 flex items-center gap-1.5 text-[11px] text-emerald-400">
            <ShieldCheck className="h-3.5 w-3.5" />
            <span>Target Bucket: {STORAGE_BUCKET} (RLS Enforced)</span>
          </div>
        </div>

        {/* Submit Button */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={saving}
            className="w-full flex items-center justify-center gap-2 rounded-xl bg-amber-400 py-3 text-xs font-bold text-neutral-950 hover:bg-amber-300 transition active:scale-95 disabled:opacity-50"
          >
            <CheckCircle2 className="h-4 w-4" />
            <span>{saving ? '...' : t.saveProductBtn}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
