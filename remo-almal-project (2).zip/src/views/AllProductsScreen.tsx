import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  ArrowUpDown,
  Star,
  Download,
  Zap,
  LayoutGrid,
  List,
  AlertCircle
} from 'lucide-react';
import { DigitalProduct, Language, ProductCategory, Screen } from '../types';
import { translations } from '../lib/i18n';

interface AllProductsScreenProps {
  products: DigitalProduct[];
  language: Language;
  setScreen: (screen: Screen) => void;
  onSelectProduct: (product: DigitalProduct) => void;
  onInstantBuy: (product: DigitalProduct) => void;
}

export const AllProductsScreen: React.FC<AllProductsScreenProps> = ({
  products,
  language,
  onSelectProduct,
  onInstantBuy,
}) => {
  const t = translations[language];

  const [selectedCategory, setSelectedCategory] = useState<ProductCategory | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'price_asc' | 'price_desc' | 'rating' | 'newest'>('newest');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const categories: { id: ProductCategory | 'all'; label: string }[] = [
    { id: 'all', label: t.catAll },
    { id: 'software', label: t.catSoftware },
    { id: 'ebooks', label: t.catEbooks },
    { id: 'scripts', label: t.catScripts },
    { id: 'templates', label: t.catTemplates },
    { id: 'graphics', label: t.catGraphics },
    { id: 'licenses', label: t.catLicenses },
  ];

  const filteredProducts = useMemo(() => {
    return products
      .filter((p) => {
        const matchesCategory = selectedCategory === 'all' || p.category === selectedCategory;
        const query = searchQuery.toLowerCase().trim();
        const matchesSearch =
          !query ||
          p.title.toLowerCase().includes(query) ||
          (p.title_en && p.title_en.toLowerCase().includes(query)) ||
          p.description.toLowerCase().includes(query) ||
          p.category.toLowerCase().includes(query);
        return matchesCategory && matchesSearch;
      })
      .sort((a, b) => {
        if (sortBy === 'price_asc') return a.price - b.price;
        if (sortBy === 'price_desc') return b.price - a.price;
        if (sortBy === 'rating') return b.rating - a.rating;
        return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
      });
  }, [products, selectedCategory, searchQuery, sortBy]);

  return (
    <div className="space-y-5 pb-20">
      {/* Title & Header */}
      <div>
        <h1 className="text-xl font-black text-white sm:text-2xl">
          {t.productsTitle}
        </h1>
        <p className="mt-1 text-xs text-neutral-400">
          {t.productsSubtitle}
        </p>
      </div>

      {/* Search & Layout Toggle Bar */}
      <div className="flex flex-col sm:flex-row gap-2.5">
        <div className="relative flex-1">
          <Search className="absolute top-1/2 -translate-y-1/2 left-3 rtl:left-auto rtl:right-3 h-4 w-4 text-neutral-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={language === 'ar' ? 'ابحث عن تطبيق، كود سورس، كتاب، قالب...' : 'Search software, source code, ebooks, templates...'}
            className="w-full rounded-xl border border-neutral-800 bg-neutral-900/90 py-2.5 px-9 text-xs text-neutral-100 placeholder-neutral-500 focus:border-amber-400 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-2">
          {/* Sort selector */}
          <div className="relative flex-1 sm:flex-initial">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full appearance-none rounded-xl border border-neutral-800 bg-neutral-900 py-2.5 px-3.5 pr-8 rtl:pr-3.5 rtl:pl-8 text-xs font-semibold text-neutral-200 focus:border-amber-400 focus:outline-none"
            >
              <option value="newest">{language === 'ar' ? 'الأحدث أولاً' : 'Newest'}</option>
              <option value="rating">{t.filterRating}</option>
              <option value="price_asc">{t.filterPriceAsc}</option>
              <option value="price_desc">{t.filterPriceDesc}</option>
            </select>
            <ArrowUpDown className="pointer-events-none absolute top-1/2 -translate-y-1/2 right-3 rtl:right-auto rtl:left-3 h-3.5 w-3.5 text-neutral-400" />
          </div>

          {/* View mode toggle */}
          <div className="flex rounded-xl border border-neutral-800 bg-neutral-900 p-1">
            <button
              onClick={() => setViewMode('grid')}
              className={`rounded-lg p-1.5 transition ${viewMode === 'grid' ? 'bg-amber-400 text-neutral-950 font-bold' : 'text-neutral-400 hover:text-white'}`}
              title="Grid View"
            >
              <LayoutGrid className="h-4 w-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`rounded-lg p-1.5 transition ${viewMode === 'list' ? 'bg-amber-400 text-neutral-950 font-bold' : 'text-neutral-400 hover:text-white'}`}
              title="List View"
            >
              <List className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {categories.map((cat) => {
          const isSelected = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`whitespace-nowrap rounded-xl px-3.5 py-1.5 text-xs font-bold transition ${
                isSelected
                  ? 'bg-amber-400 text-neutral-950 shadow-md shadow-amber-400/20'
                  : 'border border-neutral-800 bg-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              {cat.label}
            </button>
          );
        })}
      </div>

      {/* Products Render */}
      {filteredProducts.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-2xl border border-neutral-800 bg-neutral-900/40 p-10 text-center">
          <AlertCircle className="h-10 w-10 text-neutral-500 mb-3" />
          <h3 className="text-sm font-bold text-white">{t.noProductsFound}</h3>
          <p className="mt-1 text-xs text-neutral-400">
            {language === 'ar' ? 'جرب البحث بكلمات مختلفة أو تغيير التصنيف المحدد.' : 'Try different keywords or reset selected categories.'}
          </p>
          <button
            onClick={() => {
              setSelectedCategory('all');
              setSearchQuery('');
            }}
            className="mt-4 rounded-xl bg-amber-400 px-4 py-2 text-xs font-bold text-neutral-950 hover:bg-amber-300"
          >
            {language === 'ar' ? 'إعادة ضبط الفلاتر' : 'Reset Filters'}
          </button>
        </div>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className="group flex flex-col justify-between overflow-hidden rounded-2xl border border-neutral-800 bg-neutral-900/60 transition hover:border-amber-400/60 hover:shadow-lg"
            >
              <div
                onClick={() => onSelectProduct(product)}
                className="relative aspect-video w-full overflow-hidden bg-neutral-950 cursor-pointer"
              >
                <img
                  src={product.preview_image}
                  alt={product.title}
                  className="h-full w-full object-cover transition duration-300 group-hover:scale-105"
                  loading="lazy"
                />
                <div className="absolute top-2.5 right-2.5 rounded-lg bg-neutral-950/80 px-2 py-0.5 text-xs font-black text-amber-400 backdrop-blur-md">
                  ${product.price.toFixed(2)}
                </div>
                <div className="absolute bottom-2 left-2 flex items-center gap-1 rounded bg-neutral-950/80 px-1.5 py-0.5 text-[10px] font-medium text-neutral-300 backdrop-blur-md">
                  <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
                  <span>{product.rating}</span>
                </div>
              </div>

              <div className="p-4 flex-1 flex flex-col justify-between">
                <div>
                  <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">
                    {product.category}
                  </span>
                  <h3
                    onClick={() => onSelectProduct(product)}
                    className="font-bold text-white text-sm line-clamp-2 hover:text-amber-400 transition cursor-pointer mt-1"
                  >
                    {language === 'ar' ? product.title : (product.title_en || product.title)}
                  </h3>
                  <p className="mt-1.5 text-xs text-neutral-400 line-clamp-2 leading-relaxed">
                    {language === 'ar' ? product.description : (product.description_en || product.description)}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-neutral-800/80">
                  <div className="flex items-center justify-between mb-3 text-xs text-neutral-400">
                    <span className="truncate max-w-[130px]">{product.seller_name || t.seller}</span>
                    <span className="flex items-center gap-1 text-[11px] text-neutral-300">
                      <Download className="h-3 w-3 text-neutral-400" />
                      {product.downloads_count}
                    </span>
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => onSelectProduct(product)}
                      className="flex-1 rounded-xl border border-neutral-700 bg-neutral-800/90 py-2 text-xs font-semibold text-neutral-200 hover:border-neutral-500 transition"
                    >
                      {t.viewDetails}
                    </button>
                    <button
                      onClick={() => onInstantBuy(product)}
                      className="flex items-center justify-center gap-1.5 rounded-xl bg-amber-400 px-3 py-2 text-xs font-bold text-neutral-950 hover:bg-amber-300 transition"
                    >
                      <Zap className="h-3.5 w-3.5 fill-current" />
                      <span>{t.instantBuy}</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* List Mode */
        <div className="space-y-3">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className="flex flex-col sm:flex-row items-center gap-4 rounded-2xl border border-neutral-800 bg-neutral-900/60 p-3.5 transition hover:border-amber-400/50"
            >
              <img
                src={product.preview_image}
                alt={product.title}
                className="h-28 w-full sm:w-44 rounded-xl object-cover shrink-0 cursor-pointer"
                onClick={() => onSelectProduct(product)}
              />
              <div className="flex-1 w-full">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">
                    {product.category}
                  </span>
                  <span className="text-sm font-black text-amber-400">
                    ${product.price.toFixed(2)}
                  </span>
                </div>
                <h3
                  onClick={() => onSelectProduct(product)}
                  className="mt-1 text-sm font-bold text-white hover:text-amber-400 transition cursor-pointer"
                >
                  {language === 'ar' ? product.title : (product.title_en || product.title)}
                </h3>
                <p className="mt-1 text-xs text-neutral-400 line-clamp-2">
                  {language === 'ar' ? product.description : (product.description_en || product.description)}
                </p>
                <div className="mt-3 flex items-center justify-between pt-2 border-t border-neutral-800/80">
                  <div className="flex items-center gap-3 text-xs text-neutral-400">
                    <span>{product.seller_name || t.seller}</span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
                      {product.rating}
                    </span>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => onSelectProduct(product)}
                      className="rounded-lg border border-neutral-700 px-3 py-1.5 text-xs font-semibold text-neutral-200 hover:border-neutral-500"
                    >
                      {t.viewDetails}
                    </button>
                    <button
                      onClick={() => onInstantBuy(product)}
                      className="flex items-center gap-1 rounded-lg bg-amber-400 px-3 py-1.5 text-xs font-bold text-neutral-950 hover:bg-amber-300"
                    >
                      <Zap className="h-3.5 w-3.5 fill-current" />
                      <span>{t.instantBuy}</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
