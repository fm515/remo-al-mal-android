import React, { useState } from 'react';
import {
  Smartphone,
  Download,
  FileCode,
  Github,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  Copy,
  Check,
  Zap,
  Layers,
  ArrowRight,
  ArrowLeft,
  ExternalLink
} from 'lucide-react';
import { Language } from '../types';
import { translations } from '../lib/i18n';
import { generateAndroidStudioProjectZip } from '../lib/androidProjectGenerator';

interface ApkExportScreenProps {
  language: Language;
  isInstallable: boolean;
  onInstallPwa: () => void;
}

export const ApkExportScreen: React.FC<ApkExportScreenProps> = ({
  language,
  isInstallable,
  onInstallPwa,
}) => {
  const t = translations[language];

  const [generatingZip, setGeneratingZip] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [copiedWorkflow, setCopiedWorkflow] = useState(false);

  const handleDownloadZip = async () => {
    try {
      setGeneratingZip(true);
      setDownloadSuccess(false);

      // Attempt to download the complete pre-packaged repository ZIP from public root
      try {
        const response = await fetch('/remo-almal-project.zip');
        if (response.ok) {
          const blob = await response.blob();
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = 'remo-almal-project.zip';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(url);
          setDownloadSuccess(true);
          setTimeout(() => setDownloadSuccess(false), 5000);
          return;
        }
      } catch (e) {
        console.warn('Direct zip fetch failed, falling back to generator', e);
      }

      // Fallback
      const blob = await generateAndroidStudioProjectZip({
        appUrl: window.location.origin,
        appName: 'Remo Al-Mal',
        packageId: 'com.remo.almal',
      });

      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'remo-almal-project.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 5000);
    } catch (err) {
      console.error('Error bundling project:', err);
      window.location.href = '/remo-almal-project.zip';
    } finally {
      setGeneratingZip(false);
    }
  };

  const gitHubWorkflowSnippet = `name: Build Remo Al-Mal Android APK
on: [push, workflow_dispatch]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '17'
      - run: chmod +x gradlew || true
      - run: ./gradlew assembleDebug assembleRelease
      - uses: actions/upload-artifact@v4
        with:
          name: Remo-AlMal-Debug-APK
          path: app/build/outputs/apk/debug/*.apk`;

  const handleCopyWorkflow = () => {
    navigator.clipboard.writeText(gitHubWorkflowSnippet);
    setCopiedWorkflow(true);
    setTimeout(() => setCopiedWorkflow(false), 2000);
  };

  return (
    <div className="mx-auto max-w-2xl space-y-6 pb-24">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-amber-400 text-neutral-950 font-black shadow-lg shadow-amber-400/20">
          <Smartphone className="h-6 w-6" />
        </div>
        <div>
          <h1 className="text-xl font-black text-white sm:text-2xl">
            {t.apkCenterTitle}
          </h1>
          <p className="text-xs text-neutral-400">
            {t.apkCenterSubtitle}
          </p>
        </div>
      </div>

      {/* 1. Quick In-App Install (WebAPK) */}
      <div className="rounded-3xl border border-amber-400/40 bg-gradient-to-br from-neutral-900 to-amber-950/20 p-5 sm:p-6 shadow-2xl">
        <div className="flex items-start gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-400/20 text-amber-400">
            <Zap className="h-5 w-5" />
          </div>
          <div className="flex-1">
            <h2 className="text-sm font-bold text-white sm:text-base">
              {t.pwaInstallQuickTitle}
            </h2>
            <p className="mt-1 text-xs text-neutral-300 leading-relaxed">
              {t.pwaInstallQuickDesc}
            </p>
            <div className="mt-4">
              <button
                onClick={onInstallPwa}
                className="flex items-center gap-2 rounded-xl bg-amber-400 px-5 py-2.5 text-xs font-black text-neutral-950 hover:bg-amber-300 transition active:scale-95 shadow-md shadow-amber-400/20"
              >
                <Smartphone className="h-4 w-4" />
                <span>{t.installNowBtn}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Download Full Android Studio Source Project ZIP */}
      <div className="rounded-3xl border border-neutral-800 bg-neutral-900/80 p-5 sm:p-6 shadow-2xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-bold text-neutral-200">
            <FileCode className="h-4 w-4 text-amber-400" />
            <span>
              {language === 'ar'
                ? 'مشروع Android Studio كامل قابل للبناء (Kotlin & Gradle)'
                : 'Full Compilable Android Studio Project (Kotlin & Gradle)'}
            </span>
          </div>
          <span className="rounded bg-neutral-800 px-2 py-0.5 text-[10px] font-mono text-neutral-400">
            com.remo.almal
          </span>
        </div>

        <p className="text-xs text-neutral-300 leading-relaxed">
          {language === 'ar'
            ? 'يشمل ملف الـ ZIP جميع ملفات المشروع: build.gradle.kts، و AndroidManifest.xml، و MainActivity.kt، وأيقونات التطبيق الرسمية، وخطة GitHub Actions لبناء APK مجاناً.'
            : 'The ZIP package includes all build scripts, Gradle configs, AndroidManifest, MainActivity.kt, adaptive icons, and GitHub Actions CI/CD.'}
        </p>

        <div className="grid grid-cols-2 gap-2 text-[11px] font-mono text-neutral-400">
          <div className="rounded-xl bg-neutral-950 p-2 border border-neutral-800/80">
            Namespace: com.remo.almal
          </div>
          <div className="rounded-xl bg-neutral-950 p-2 border border-neutral-800/80">
            Min SDK: 24 (Android 7.0+)
          </div>
          <div className="rounded-xl bg-neutral-950 p-2 border border-neutral-800/80">
            Target SDK: 34 (Android 14)
          </div>
          <div className="rounded-xl bg-neutral-950 p-2 border border-neutral-800/80">
            Languages: Kotlin 1.9 + Java 17
          </div>
        </div>

        <button
          onClick={handleDownloadZip}
          disabled={generatingZip}
          className="w-full flex items-center justify-center gap-2 rounded-2xl bg-amber-400 py-3.5 text-xs font-black text-neutral-950 hover:bg-amber-300 transition active:scale-95 shadow-lg shadow-amber-400/20 disabled:opacity-50"
        >
          <Download className={`h-4 w-4 ${generatingZip ? 'animate-bounce' : ''}`} />
          <span>{generatingZip ? (language === 'ar' ? 'جاري تجهيز حزمة الأندرويد...' : 'Packaging Project...') : t.downloadAndroidProjectBtn}</span>
        </button>

        {downloadSuccess && (
          <div className="flex items-center gap-2 rounded-xl bg-emerald-950/40 border border-emerald-500/40 p-3 text-xs text-emerald-300">
            <CheckCircle2 className="h-4 w-4 text-emerald-400" />
            <span>
              {language === 'ar'
                ? 'تم تنزيل Remo-AlMal-Android-Project.zip بنجاح! يمكنك الآن بناء APK كما هو موضح بالأسفل.'
                : 'Remo-AlMal-Android-Project.zip downloaded successfully! Follow the steps below to compile.'}
            </span>
          </div>
        )}
      </div>

      {/* 3. 100% Free Phone Workflow via GitHub Actions */}
      <div className="rounded-3xl border border-neutral-800 bg-neutral-900/80 p-5 sm:p-6 space-y-4">
        <div className="flex items-center gap-2 text-xs font-bold text-white">
          <Github className="h-4 w-4 text-amber-400" />
          <span>{t.githubActionsTitle}</span>
        </div>

        <p className="text-xs text-neutral-300 leading-relaxed">
          {t.githubActionsDesc}
        </p>

        {/* Step-by-Step Instructions */}
        <div className="space-y-3 rounded-2xl bg-neutral-950 p-4 border border-neutral-800/80 text-xs">
          <div className="flex items-start gap-2.5 text-neutral-300">
            <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-amber-400/20 text-amber-400 font-bold text-[10px]">
              1
            </span>
            <span>
              {language === 'ar'
                ? 'افتح موقع GitHub.com من هاتفك وسجل حساباً مجانياً ثم أنشئ مستودعاً جديداً (New Repository).'
                : 'Open GitHub.com on your Android browser, register a free account and create a new repository.'}
            </span>
          </div>

          <div className="flex items-start gap-2.5 text-neutral-300">
            <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-amber-400/20 text-amber-400 font-bold text-[10px]">
              2
            </span>
            <span>
              {language === 'ar'
                ? 'اضغط Upload Files وارفع محتويات ملف Remo-AlMal-Android-Project.zip إليه.'
                : 'Click Upload Files and upload the contents of Remo-AlMal-Android-Project.zip.'}
            </span>
          </div>

          <div className="flex items-start gap-2.5 text-neutral-300">
            <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-amber-400/20 text-amber-400 font-bold text-[10px]">
              3
            </span>
            <span>
              {language === 'ar'
                ? 'ستعمل خطة البناء التلقائية في تبويب Actions وتقوم بتوليد ملف APK قابل للتنزيل والتثبيت على هاتفك خلال دقيقتين!'
                : 'The included GitHub Actions workflow will automatically build your downloadable APK in ~2 minutes!'}
            </span>
          </div>
        </div>

        {/* Workflow code preview */}
        <div>
          <div className="flex items-center justify-between mb-1.5 text-[11px] text-neutral-400">
            <span>.github/workflows/build-apk.yml</span>
            <button
              onClick={handleCopyWorkflow}
              className="flex items-center gap-1 text-amber-400 hover:underline"
            >
              {copiedWorkflow ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
              <span>{copiedWorkflow ? (language === 'ar' ? 'تم النسخ' : 'Copied') : (language === 'ar' ? 'نسخ الكود' : 'Copy')}</span>
            </button>
          </div>
          <pre className="overflow-x-auto rounded-xl bg-neutral-950 p-3 font-mono text-[10px] text-neutral-300 border border-neutral-800">
            {gitHubWorkflowSnippet}
          </pre>
        </div>
      </div>

      {/* 4. Debug vs Release APK & Installation Steps */}
      <div className="rounded-3xl border border-neutral-800 bg-neutral-900/80 p-5 sm:p-6 space-y-4">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider">
          {language === 'ar' ? 'الفرق بين نسخة Debug ونسخة Release:' : 'Debug vs Release APK:'}
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="rounded-2xl border border-neutral-800 bg-neutral-950 p-3.5">
            <span className="font-bold text-amber-400 block mb-1">نسخة Debug APK</span>
            <p className="text-[11px] text-neutral-400 leading-relaxed">
              جاهزة فورياً للتثبيت والتجربة على أي هاتف Android دون الحاجة لشهادة توقيع خاصة.
            </p>
          </div>
          <div className="rounded-2xl border border-neutral-800 bg-neutral-950 p-3.5">
            <span className="font-bold text-emerald-400 block mb-1">نسخة Release الموقّعة</span>
            <p className="text-[11px] text-neutral-400 leading-relaxed">
              تُوقّع بمفتاح Keystore خاص بك لنشرها رسمياً على المتاجر أو التوزيع الآمن للمستخدمين.
            </p>
          </div>
        </div>

        <div className="pt-2 border-t border-neutral-800/80">
          <h4 className="text-xs font-bold text-neutral-200 mb-2">{t.apkStepsTitle}</h4>
          <ol className="list-decimal list-inside space-y-1.5 text-xs text-neutral-300 leading-relaxed">
            <li>{t.apkStep1}</li>
            <li>{t.apkStep2}</li>
            <li>{t.apkStep3}</li>
          </ol>
        </div>
      </div>
    </div>
  );
};
