import React, { useState } from 'react';
import { Mail, Lock, User, Shield, AlertTriangle, CheckCircle, ArrowRight, ArrowLeft } from 'lucide-react';
import { Language, UserProfile, UserRole } from '../types';
import { translations } from '../lib/i18n';
import { getSupabaseClient } from '../lib/supabase';

interface AuthScreenProps {
  initialMode: 'login' | 'register';
  language: Language;
  onSuccess: (user: UserProfile) => void;
  onGuestDemo: (role: UserRole) => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({
  initialMode,
  language,
  onSuccess,
  onGuestDemo,
}) => {
  const t = translations[language];
  const [mode, setMode] = useState<'login' | 'register'>(initialMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [role, setRole] = useState<UserRole>('buyer');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setLoading(true);

    const client = getSupabaseClient();

    if (client) {
      try {
        if (mode === 'register') {
          const { data, error } = await client.auth.signUp({
            email,
            password,
            options: {
              data: {
                full_name: fullName,
                role: role,
              },
            },
          });

          if (error) throw error;

          if (data.user) {
            const userProfile: UserProfile = {
              id: data.user.id,
              email: data.user.email || email,
              full_name: fullName || email.split('@')[0],
              role: role,
              created_at: new Date().toISOString(),
            };
            onSuccess(userProfile);
            return;
          }
        } else {
          // Login
          const { data, error } = await client.auth.signInWithPassword({
            email,
            password,
          });

          if (error) throw error;

          if (data.user) {
            const userProfile: UserProfile = {
              id: data.user.id,
              email: data.user.email || email,
              full_name: data.user.user_metadata?.full_name || email.split('@')[0],
              role: data.user.user_metadata?.role || 'buyer',
              created_at: new Date().toISOString(),
            };
            onSuccess(userProfile);
            return;
          }
        }
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : String(err);
        setErrorMsg(`Supabase Auth: ${msg}`);
        setLoading(false);
        return;
      }
    } else {
      // In sandbox mode without anon key, inform the user clearly
      setErrorMsg(
        language === 'ar'
          ? 'تنبيه: المفتاح العام (Anon Key) لـ Supabase غير مسجل حتى الآن. يرجى إدخال المفتاح العام من مركز Supabase بأعلى الشاشة للاتصال بخدمة Supabase Auth الحقيقية، أو استخدم أزرار (الدخول التجريبي السريع) بالأسفل.'
          : 'Notice: Supabase Anon Key is not set. Please provide the Anon Key via the Supabase modal in the header to authenticate with live Supabase Auth, or use the Instant Demo buttons below.'
      );
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-md pb-20 pt-2">
      <div className="rounded-3xl border border-neutral-800 bg-neutral-900/80 p-6 sm:p-8 shadow-2xl backdrop-blur-md">
        {/* Header Monogram */}
        <div className="flex justify-center mb-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-400 to-amber-500 text-neutral-950 font-black shadow-lg shadow-amber-400/20">
            <Shield className="h-6 w-6 stroke-[2.5]" />
          </div>
        </div>

        <h1 className="text-center text-xl font-black text-white sm:text-2xl">
          {mode === 'login' ? t.loginTitle : t.registerTitle}
        </h1>
        <p className="mt-1 text-center text-xs text-neutral-400">
          {mode === 'login' ? t.loginSubtitle : t.registerSubtitle}
        </p>

        {/* Mode Toggle Tabs */}
        <div className="mt-6 flex rounded-2xl border border-neutral-800 bg-neutral-950 p-1">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setErrorMsg(null);
            }}
            className={`flex-1 rounded-xl py-2 text-xs font-bold transition ${
              mode === 'login'
                ? 'bg-amber-400 text-neutral-950 shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            {t.loginBtn}
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('register');
              setErrorMsg(null);
            }}
            className={`flex-1 rounded-xl py-2 text-xs font-bold transition ${
              mode === 'register'
                ? 'bg-amber-400 text-neutral-950 shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            {t.registerBtn}
          </button>
        </div>

        {errorMsg && (
          <div className="mt-4 flex items-start gap-2 rounded-xl border border-rose-500/30 bg-rose-950/40 p-3 text-xs text-rose-300">
            <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5 text-rose-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          {mode === 'register' && (
            <div>
              <label className="block text-xs font-bold text-neutral-300 mb-1">
                {t.fullNameLabel}
              </label>
              <div className="relative">
                <User className="absolute top-1/2 -translate-y-1/2 left-3 rtl:left-auto rtl:right-3 h-4 w-4 text-neutral-500" />
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="محمد أحمد / John Doe"
                  className="w-full rounded-xl border border-neutral-800 bg-neutral-950 py-2.5 px-9 text-xs text-neutral-100 placeholder-neutral-500 focus:border-amber-400 focus:outline-none"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-neutral-300 mb-1">
              {t.emailLabel}
            </label>
            <div className="relative">
              <Mail className="absolute top-1/2 -translate-y-1/2 left-3 rtl:left-auto rtl:right-3 h-4 w-4 text-neutral-500" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full rounded-xl border border-neutral-800 bg-neutral-950 py-2.5 px-9 text-xs text-neutral-100 placeholder-neutral-500 focus:border-amber-400 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-bold text-neutral-300">
                {t.passwordLabel}
              </label>
              {mode === 'login' && (
                <button
                  type="button"
                  onClick={() => alert(language === 'ar' ? 'يمكنك استعادة كلمة المرور عبر بريدك في Supabase Auth' : 'Password reset link will be sent to your Supabase Auth email')}
                  className="text-[11px] font-semibold text-amber-400 hover:underline"
                >
                  {t.forgotPassword}
                </button>
              )}
            </div>
            <div className="relative">
              <Lock className="absolute top-1/2 -translate-y-1/2 left-3 rtl:left-auto rtl:right-3 h-4 w-4 text-neutral-500" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full rounded-xl border border-neutral-800 bg-neutral-950 py-2.5 px-9 text-xs text-neutral-100 placeholder-neutral-500 focus:border-amber-400 focus:outline-none"
              />
            </div>
          </div>

          {mode === 'register' && (
            <div>
              <label className="block text-xs font-bold text-neutral-300 mb-1.5">
                {t.roleLabel}
              </label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setRole('buyer')}
                  className={`rounded-xl border p-2.5 text-start font-semibold transition ${
                    role === 'buyer'
                      ? 'border-amber-400 bg-amber-400/10 text-amber-400'
                      : 'border-neutral-800 bg-neutral-950 text-neutral-400'
                  }`}
                >
                  <div className="font-bold">{language === 'ar' ? 'مشتري' : 'Buyer'}</div>
                  <div className="text-[10px] text-neutral-400 font-normal mt-0.5">
                    {language === 'ar' ? 'شراء وتنزيل الملفات' : 'Browse & download'}
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => setRole('seller')}
                  className={`rounded-xl border p-2.5 text-start font-semibold transition ${
                    role === 'seller'
                      ? 'border-amber-400 bg-amber-400/10 text-amber-400'
                      : 'border-neutral-800 bg-neutral-950 text-neutral-400'
                  }`}
                >
                  <div className="font-bold">{language === 'ar' ? 'بائع منتجات' : 'Seller'}</div>
                  <div className="text-[10px] text-neutral-400 font-normal mt-0.5">
                    {language === 'ar' ? 'إضافة منتجات وأرباح' : 'List assets & earn'}
                  </div>
                </button>
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 rounded-xl bg-amber-400 py-3 text-xs font-bold text-neutral-950 hover:bg-amber-300 transition active:scale-95 disabled:opacity-50"
          >
            <span>{loading ? '...' : mode === 'login' ? t.loginBtn : t.registerBtn}</span>
            {language === 'ar' ? (
              <ArrowLeft className="h-4 w-4" />
            ) : (
              <ArrowRight className="h-4 w-4" />
            )}
          </button>
        </form>

        {/* Demo Fast Access for Quick Evaluation */}
        <div className="mt-6 pt-5 border-t border-neutral-800/80">
          <p className="text-center text-[11px] font-semibold text-neutral-400 mb-2.5">
            {language === 'ar' ? 'تجربة سريعة بدون إدخال بريد:' : 'Instant Demo Login Profiles:'}
          </p>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => onGuestDemo('buyer')}
              className="flex-1 rounded-xl border border-neutral-800 bg-neutral-950 py-2 text-xs font-semibold text-neutral-300 hover:border-amber-400/60 hover:text-amber-400"
            >
              {language === 'ar' ? 'دخول كمشتري' : 'Demo Buyer'}
            </button>
            <button
              type="button"
              onClick={() => onGuestDemo('seller')}
              className="flex-1 rounded-xl border border-neutral-800 bg-neutral-950 py-2 text-xs font-semibold text-neutral-300 hover:border-amber-400/60 hover:text-amber-400"
            >
              {language === 'ar' ? 'دخول كبائع' : 'Demo Seller'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
