import React, { useState } from 'react';
import { WifiOff, RefreshCw, AlertCircle, Database, CheckCircle2, Smartphone } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../lib/i18n';
import { testSupabaseConnection } from '../lib/supabase';

interface ConnectionErrorScreenProps {
  language: Language;
  onRetry: () => void;
  onOpenSupabaseModal: () => void;
}

export const ConnectionErrorScreen: React.FC<ConnectionErrorScreenProps> = ({
  language,
  onRetry,
  onOpenSupabaseModal,
}) => {
  const t = translations[language];
  const [retrying, setRetrying] = useState(false);
  const [testResult, setTestResult] = useState<string | null>(null);

  const handleTest = async () => {
    setRetrying(true);
    setTestResult(null);
    const res = await testSupabaseConnection();
    setRetrying(false);
    setTestResult(res.message);
    if (res.success) {
      onRetry();
    }
  };

  return (
    <div className="mx-auto max-w-md pb-24 text-center">
      <div className="rounded-3xl border border-neutral-800 bg-neutral-900/90 p-6 sm:p-8 shadow-2xl backdrop-blur-md space-y-5">
        <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-rose-500/10 text-rose-400 ring-2 ring-rose-500/20">
          <WifiOff className="h-10 w-10" />
        </div>

        <div>
          <h1 className="text-lg font-black text-white sm:text-xl">
            {t.connErrorTitle}
          </h1>
          <p className="mt-1.5 text-xs text-neutral-400 leading-relaxed">
            {t.connErrorDesc}
          </p>
        </div>

        {/* Diagnostic Checklist */}
        <div className="rounded-2xl border border-neutral-800 bg-neutral-950 p-4 text-start text-xs space-y-2 text-neutral-300">
          <div className="flex items-center gap-2 text-neutral-400 font-bold mb-1">
            <Smartphone className="h-4 w-4 text-amber-400" />
            <span>{language === 'ar' ? 'فحص اتصال هاتف Android:' : 'Android Connectivity Checklist:'}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-amber-400" />
            <span>{language === 'ar' ? 'تأكد من تفعيل بيانات الهاتف أو شبكة Wi-Fi.' : 'Ensure Wi-Fi or Mobile Data is active.'}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-amber-400" />
            <span>{language === 'ar' ? 'تحقق من المفتاح العام (Anon Key) في إعدادات Supabase.' : 'Verify the client public Anon Key in settings.'}</span>
          </div>
        </div>

        {testResult && (
          <div className="rounded-xl border border-neutral-700 bg-neutral-950 p-3 text-start text-xs text-neutral-300 font-mono">
            {testResult}
          </div>
        )}

        {/* Action Buttons */}
        <div className="space-y-2 pt-2">
          <button
            onClick={handleTest}
            disabled={retrying}
            className="w-full flex items-center justify-center gap-2 rounded-2xl bg-amber-400 py-3.5 text-xs font-black text-neutral-950 hover:bg-amber-300 transition active:scale-95 disabled:opacity-50"
          >
            <RefreshCw className={`h-4 w-4 ${retrying ? 'animate-spin' : ''}`} />
            <span>{retrying ? '...' : t.retryBtn}</span>
          </button>

          <button
            onClick={onOpenSupabaseModal}
            className="w-full rounded-2xl border border-neutral-800 bg-neutral-950 py-2.5 text-xs font-semibold text-neutral-300 hover:text-white"
          >
            {language === 'ar' ? 'فتح إعدادات Supabase' : 'Open Supabase Settings'}
          </button>

          <button
            onClick={onRetry}
            className="w-full text-xs text-neutral-500 hover:text-neutral-400 pt-1"
          >
            {language === 'ar' ? 'المتابعة في وضع المعاينة السريعة (Sandbox)' : 'Continue in Offline Sandbox Mode'}
          </button>
        </div>
      </div>
    </div>
  );
};
