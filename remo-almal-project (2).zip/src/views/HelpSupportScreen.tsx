import React, { useState } from 'react';
import {
  HelpCircle,
  MessageSquare,
  Send,
  ChevronDown,
  ChevronUp,
  ShieldCheck,
  Headphones,
  CheckCircle2
} from 'lucide-react';
import { Language } from '../types';
import { translations } from '../lib/i18n';

interface HelpSupportScreenProps {
  language: Language;
}

export const HelpSupportScreen: React.FC<HelpSupportScreenProps> = ({ language }) => {
  const t = translations[language];

  const faqs = [
    { q: t.faq1Q, a: t.faq1A },
    { q: t.faq2Q, a: t.faq2A },
    { q: t.faq3Q, a: t.faq3A },
    {
      q: language === 'ar' ? 'كيف أقوم بتثبيت التطبيق على هاتفي بصيغة APK؟' : 'How can I build and install the APK on Android?',
      a: language === 'ar'
        ? 'يمكنك تثبيته فورياً كـ WebAPK بنقرة واحدة من شريط المتصفح أو قسم (تطبيق Android)، أو تحميل ملف المشروع المضغوط واستخراج الـ APK مجاناً عبر GitHub Actions في دقيقتين.'
        : 'You can install it instantly via 1-click WebAPK, or download the full project ZIP to compile debug and release APKs for free on GitHub Actions without needing a PC.',
    },
  ];

  const [expandedIndex, setExpandedIndex] = useState<number | null>(0);
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketMessage, setTicketMessage] = useState('');
  const [ticketSent, setTicketSent] = useState(false);

  const handleSubmitTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketSubject || !ticketMessage) return;
    setTicketSent(true);
    setTimeout(() => {
      setTicketSubject('');
      setTicketMessage('');
      setTicketSent(false);
      alert(language === 'ar' ? 'تم استلام تذكرتك بنجاح وسيتم الرد خلال ساعات العمل.' : 'Support ticket received. We will respond shortly.');
    }, 1500);
  };

  return (
    <div className="mx-auto max-w-xl space-y-6 pb-24">
      <div>
        <h1 className="text-xl font-black text-white sm:text-2xl">
          {t.helpTitle}
        </h1>
        <p className="mt-1 text-xs text-neutral-400">
          {t.helpSubtitle}
        </p>
      </div>

      {/* FAQs */}
      <div className="space-y-3">
        <h2 className="text-xs font-bold text-neutral-300 uppercase tracking-wider flex items-center gap-1.5">
          <HelpCircle className="h-4 w-4 text-amber-400" />
          <span>{language === 'ar' ? 'الأسئلة الشائعة' : 'Frequently Asked Questions'}</span>
        </h2>

        {faqs.map((faq, idx) => {
          const isExpanded = expandedIndex === idx;
          return (
            <div
              key={idx}
              className="overflow-hidden rounded-2xl border border-neutral-800 bg-neutral-900/70"
            >
              <button
                type="button"
                onClick={() => setExpandedIndex(isExpanded ? null : idx)}
                className="flex w-full items-center justify-between p-4 text-start text-xs font-bold text-white transition hover:text-amber-400"
              >
                <span>{faq.q}</span>
                {isExpanded ? (
                  <ChevronUp className="h-4 w-4 text-amber-400 shrink-0" />
                ) : (
                  <ChevronDown className="h-4 w-4 text-neutral-400 shrink-0" />
                )}
              </button>
              {isExpanded && (
                <div className="px-4 pb-4 pt-1 text-xs text-neutral-300 leading-relaxed border-t border-neutral-800/80 bg-neutral-950/40">
                  {faq.a}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Support Ticket Submission */}
      <div className="rounded-3xl border border-neutral-800 bg-neutral-900/80 p-5 sm:p-6 shadow-2xl">
        <div className="flex items-center gap-2 mb-3 text-xs font-bold text-white">
          <MessageSquare className="h-4 w-4 text-amber-400" />
          <span>{language === 'ar' ? 'إرسال تذكرة دعم فني جديدة' : 'Submit a Support Ticket'}</span>
        </div>

        <form onSubmit={handleSubmitTicket} className="space-y-3">
          <div>
            <label className="block text-[11px] font-semibold text-neutral-400 mb-1">
              {language === 'ar' ? 'موضوع الاستفسار:' : 'Subject:'}
            </label>
            <input
              type="text"
              required
              value={ticketSubject}
              onChange={(e) => setTicketSubject(e.target.value)}
              placeholder={language === 'ar' ? 'مثال: استفسار حول تأكيد معاملة USDT' : 'e.g. Question regarding USDT confirmation'}
              className="w-full rounded-xl border border-neutral-800 bg-neutral-950 px-3.5 py-2 text-xs text-white placeholder-neutral-500 focus:border-amber-400 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-neutral-400 mb-1">
              {language === 'ar' ? 'التفاصيل:' : 'Message:'}
            </label>
            <textarea
              required
              rows={3}
              value={ticketMessage}
              onChange={(e) => setTicketMessage(e.target.value)}
              placeholder={language === 'ar' ? 'اشرح بالتفصيل المشكلة أو رقم الطلب...' : 'Explain your inquiry or provide order ID...'}
              className="w-full rounded-xl border border-neutral-800 bg-neutral-950 p-3 text-xs text-white placeholder-neutral-500 focus:border-amber-400 focus:outline-none leading-relaxed"
            />
          </div>

          <button
            type="submit"
            disabled={ticketSent}
            className="w-full flex items-center justify-center gap-2 rounded-xl bg-amber-400 py-3 text-xs font-bold text-neutral-950 hover:bg-amber-300 transition"
          >
            {ticketSent ? <CheckCircle2 className="h-4 w-4" /> : <Send className="h-4 w-4" />}
            <span>{ticketSent ? (language === 'ar' ? 'تم الإرسال!' : 'Sent!') : (language === 'ar' ? 'إرسال التذكرة' : 'Send Ticket')}</span>
          </button>
        </form>
      </div>

      {/* Direct Contact Channels */}
      <div className="rounded-2xl border border-neutral-800 bg-neutral-900/50 p-4 text-center">
        <p className="text-xs text-neutral-400 mb-2">
          {t.contactUs}
        </p>
        <a
          href="https://t.me"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 rounded-xl bg-neutral-800 px-4 py-2 text-xs font-semibold text-white hover:text-amber-400 hover:border-amber-400 transition"
        >
          <Headphones className="h-4 w-4 text-amber-400" />
          <span>{t.telegramBtn}</span>
        </a>
      </div>
    </div>
  );
};
