import React from 'react';
import {
  ShieldCheck,
  Zap,
  ArrowRight,
  ArrowLeft,
  Smartphone,
  Sparkles,
  Download,
  Star,
  CheckCircle,
  TrendingUp,
  Cpu,
  BookOpen,
  Code2,
  Layout,
  Palette,
  Key
} from 'lucide-react';
import { DigitalProduct, Language, ProductCategory, Screen } from '../types';
import { translations } from '../lib/i18n';

interface HomeScreenProps {
  products: DigitalProduct[];
  productsSource?: 'supabase_live' | 'local_sandbox';
  language: Language;
  setScreen: (screen: Screen) => void;
  onSelectProduct: (product: DigitalProduct) => void;
  onInstantBuy: (product: DigitalProduct) => void;
  onOpenSupabaseModal?: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  products,
  productsSource = 'local_sandbox',
  language,
  setScreen,
  onSelectProduct,
  onInstantBuy,
  onOpenSupabaseModal,
}) => {
  const t = translations[language];

  const categories: { id: ProductCategory; label: string; icon: React.ElementType }[] = [
    { id: 'software', label: t.catSoftware, icon: Cpu },
    { id: 'ebooks', label: t.catEbooks, icon: BookOpen },
    { id: 'scripts', label: t.catScripts, icon: Code2 },
    { id: 'templates', label: t.catTemplates, icon: Layout },
    { id: 'graphics', label: t.catGraphics, icon: Palette },
    { id: 'licenses', label: t.catLicenses, icon: Key },
  ];

  return (
    <div className="space-y-6 pb-20">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-3xl border border-amber-400/20 bg-gradient-to-b from-neutral-900 to-neutral-950 p-5 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 h-64 w-64 rounded-full bg-amber-400/10 blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-16 -mb-16 h-64 w-64 rounded-full bg-amber-500/5 blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 rounded-full border border-amber-400/30 bg-amber-400/10 px-3.5 py-1 text-xs font-bold text-amber-400 mb-4">
            <Sparkles className="h-3.5 w-3.5" />
            <span>Remo Al-Mal • الأصول الرقمية الموثوقة</span>
          </div>

          <h1 className="text-2xl font-black tracking-tight text-white sm:text-4xl leading-tight">
            {t.homeHeroTitle}
          </h1>

          <p className="mt-3 text-sm text-neutral-300 leading-relaxed sm:text-base">
            {t.homeHeroDesc}
          </p>

          <div className="mt-6 flex flex-wrap items-center gap-3">
            <button
              onClick={() => setScreen('all_products')}
              className="group flex items-center gap-2 rounded-xl bg-amber-400 px-5 py-3 text-sm font-bold text-neutral-950 shadow-md shadow-amber-400/20 hover:bg-amber-300 transition active:scale-95"
            >
              <span>{t.homeExploreBtn}</span>
              {language === 'ar' ? (
                <ArrowLeft className="h-4 w-4 transition group-hover:-translate-x-1" />
              ) : (
                <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
              )}
            </button>

            <button
              onClick={() => setScreen('seller_dashboard')}
              className="flex items-center gap-2 rounded-xl border border-neutral-700 bg-neutral-900/90 px-5 py-3 text-sm font-semibold text-neutral-200 hover:border-amber-400 hover:text-white transition"
            >
              <span>{t.homeSellerBtn}</span>
            </button>
          </div>
        </div>

        {/* Quick Android APK Banner Bar */}
        <div className="mt-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 rounded-2xl border border-amber-400/25 bg-neutral-950/80 p-3.5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-400 text-neutral-950 font-black">
              <Smartphone className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-white">
                {language === 'ar' ? 'تطبيق Android الأصلي متاح للتثبيت والبناء' : 'Native Android APK Package Available'}
              </p>
              <p className="text-[11px] text-neutral-400">
                {language === 'ar' ? 'com.remo.almal • تثبيت PWA فوري + تنزيل كود Gradle مجاناً' : 'One-click PWA install + downloadable full Gradle project'}
              </p>
            </div>
          </div>
          <button
            onClick={() => setScreen('apk_export')}
            className="w-full sm:w-auto rounded-xl bg-neutral-900 border border-amber-400/40 px-3.5 py-1.5 text-xs font-bold text-amber-400 hover:bg-amber-400 hover:text-neutral-950 transition"
          >
            {language === 'ar' ? 'فتح مركز APK' : 'Open APK Hub'}
          </button>
        </div>
      </section>

      {/* Metrics & Guarantees */}
      <section className="grid grid-cols-3 gap-2.5 sm:gap-4">
        <div className="rounded-2xl border border-neutral-800 bg-neutral-900/70 p-3 text-center sm:p-4">
          <div className="text-lg font-black text-amber-400 sm:text-2xl">$124,500+</div>
          <div className="mt-1 text-[11px] font-medium text-neutral-400 sm:text-xs">
            {t.homeStatsSales}
          </div>
        </div>
        <div className="rounded-2xl border border-neutral-800 bg-neutral-900/70 p-3 text-center sm:p-4">
          <div className="text-lg font-black text-white sm:text-2xl">48+</div>
          <div className="mt-1 text-[11px] font-medium text-neutral-400 sm:text-xs">
            {t.homeStatsProducts}
          </div>
        </div>
        <div className="rounded-2xl border border-neutral-800 bg-neutral-900/70 p-3 text-center sm:p-4">
          <div className="text-lg font-black text-emerald-400 sm:text-2xl">100%</div>
          <div className="mt-1 text-[11px] font-medium text-neutral-400 sm:text-xs">
            {t.homeStatsProtection}
          </div>
        </div>
      </section>

      {/* Categories Grid */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-base font-bold text-white sm:text-lg">
            {t.homeCategoriesTitle}
          </h2>
          <button
            onClick={() => setScreen('all_products')}
            className="text-xs font-semibold text-amber-400 hover:underline"
          >
            {t.catAll}
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 md:grid-cols-6">
          {categories.map((cat) => {
            const Icon = cat.icon;
            return (
              <button
                key={cat.id}
                onClick={() => setScreen('all_products')}
                className="group flex flex-col items-center justify-center rounded-2xl border border-neutral-800/80 bg-neutral-900/50 p-3.5 transition hover:border-amber-400/50 hover:bg-neutral-900"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-400/10 text-amber-400 group-hover:bg-amber-400 group-hover:text-neutral-950 transition">
                  <Icon className="h-5 w-5" />
                </div>
                <span className="mt-2 text-xs font-semibold text-neutral-300 text-center truncate max-w-full">
                  {cat.label}
                </span>
              </button>
            );
          })}
        </div>
      </section>

      {/* Featured Products */}
      <section>
        {/* Supabase Status Banner */}
        <div className="mb-3.5 flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-neutral-800 bg-neutral-900/60 px-3.5 py-2 text-xs">
          <div className="flex items-center gap-2">
            <span
              className={`h-2.5 w-2.5 rounded-full ${
                productsSource === 'supabase_live'
                  ? 'bg-emerald-400 animate-pulse'
                  : 'bg-amber-400'
              }`}
            />
            <span className="font-medium text-neutral-300">
              {productsSource === 'supabase_live'
                ? (language === 'ar'
                    ? 'قاعدة بيانات Supabase الحية: جدول digital_products متصل'
                    : 'Supabase Live: Connected to digital_products table')
                : (language === 'ar'
                    ? 'وضع المعاينة (Sandbox): في انتظار إدخال المفتاح العام (Anon Key) لقراءة المنتجات الحية'
                    : 'Sandbox Preview: Enter Anon Key to fetch live Supabase products')}
            </span>
          </div>

          {productsSource !== 'supabase_live' && onOpenSupabaseModal && (
            <button
              onClick={onOpenSupabaseModal}
              className="font-bold text-amber-400 hover:underline"
            >
              {language === 'ar' ? 'ربط المفتاح الآن' : 'Connect Key'}
            </button>
          )}
        </div>

        <div className="flex items-center justify-between mb-3.5">
          <div>
            <h2 className="text-base font-bold text-white sm:text-lg">
              {t.homeFeaturedTitle}
            </h2>
            <p className="text-xs text-neutral-400">
              {language === 'ar' ? 'جاهزة للتحميل الفوري فور تأكيد الدفع من الخادم' : 'Verified digital assets ready for instant download'}
            </p>
          </div>
          <button
            onClick={() => setScreen('all_products')}
            className="text-xs font-semibold text-amber-400 hover:underline shrink-0"
          >
            {language === 'ar' ? 'عرض المزيد' : 'See More'}
          </button>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {products.map((product) => (
            <div
              key={product.id}
              className="group flex flex-col justify-between overflow-hidden rounded-2xl border border-neutral-800 bg-neutral-900/60 transition hover:border-amber-400/60 hover:shadow-xl hover:shadow-amber-400/5"
            >
              {/* Product Thumbnail */}
              <div
                onClick={() => onSelectProduct(product)}
                className="relative aspect-video w-full overflow-hidden bg-neutral-950 cursor-pointer"
              >
                <img
                  src={product.preview_image}
                  alt={product.title}
                  className="h-full w-full object-cover transition duration-300 group-hover:scale-105"
                  loading="lazy"
                />
                <div className="absolute top-2.5 right-2.5 rounded-lg bg-neutral-950/80 px-2 py-0.5 text-[11px] font-bold text-amber-400 backdrop-blur-md">
                  ${product.price.toFixed(2)}
                </div>
                <div className="absolute bottom-2 left-2 flex items-center gap-1 rounded bg-neutral-950/80 px-1.5 py-0.5 text-[10px] font-medium text-neutral-300 backdrop-blur-md">
                  <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
                  <span>{product.rating}</span>
                  <span className="text-neutral-400">({product.reviews_count})</span>
                </div>
              </div>

              {/* Product Info */}
              <div className="p-4 flex-1 flex flex-col justify-between">
                <div>
                  <div className="text-[11px] font-semibold text-amber-400 uppercase tracking-wider mb-1">
                    {product.category}
                  </div>
                  <h3
                    onClick={() => onSelectProduct(product)}
                    className="font-bold text-white text-sm line-clamp-2 hover:text-amber-400 transition cursor-pointer"
                  >
                    {language === 'ar' ? product.title : (product.title_en || product.title)}
                  </h3>
                  <p className="mt-1.5 text-xs text-neutral-400 line-clamp-2 leading-relaxed">
                    {language === 'ar' ? product.description : (product.description_en || product.description)}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-neutral-800/80">
                  <div className="flex items-center justify-between mb-3 text-xs text-neutral-400">
                    <span className="truncate max-w-[130px]">
                      {product.seller_name || t.seller}
                    </span>
                    <span className="flex items-center gap-1 text-[11px] text-neutral-300">
                      <Download className="h-3 w-3 text-neutral-400" />
                      {product.downloads_count} {t.downloads}
                    </span>
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => onSelectProduct(product)}
                      className="flex-1 rounded-xl border border-neutral-700 bg-neutral-800/90 py-2 text-xs font-semibold text-neutral-200 hover:border-neutral-500 transition"
                    >
                      {t.viewDetails}
                    </button>
                    <button
                      onClick={() => onInstantBuy(product)}
                      className="flex items-center justify-center gap-1.5 rounded-xl bg-amber-400 px-3.5 py-2 text-xs font-bold text-neutral-950 hover:bg-amber-300 transition"
                    >
                      <Zap className="h-3.5 w-3.5 fill-current" />
                      <span>{t.instantBuy}</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Trust & Guarantee Banner */}
      <section className="rounded-2xl border border-amber-400/30 bg-gradient-to-r from-neutral-900 via-neutral-900 to-amber-950/20 p-5">
        <div className="flex items-start gap-3.5">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-amber-400/20 text-amber-400 ring-1 ring-amber-400/40">
            <ShieldCheck className="h-6 w-6" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white sm:text-base">
              {t.homeGuaranteeTitle}
            </h3>
            <p className="mt-1 text-xs text-neutral-300 leading-relaxed sm:text-sm">
              {t.homeGuaranteeDesc}
            </p>
            <div className="mt-3 flex flex-wrap items-center gap-4 text-xs font-medium text-amber-400">
              <span className="flex items-center gap-1.5">
                <CheckCircle className="h-3.5 w-3.5" />
                {language === 'ar' ? 'تشفير كامل للروابط' : 'Expiring Encrypted Tokens'}
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle className="h-3.5 w-3.5" />
                {language === 'ar' ? 'عمولة شفافة 10% فقط' : 'Strict 10% Platform Fee'}
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle className="h-3.5 w-3.5" />
                {language === 'ar' ? 'حماية RLS من Supabase' : 'Supabase RLS Protected'}
              </span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
