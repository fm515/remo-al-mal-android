import React from 'react';
import {
  ArrowLeft,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Printer,
  Download,
  DollarSign,
  Package,
  Layers,
  FileText
} from 'lucide-react';
import { Language, Order } from '../types';
import { translations } from '../lib/i18n';

interface OrderDetailsScreenProps {
  order: Order;
  language: Language;
  onBack: () => void;
  onGoToDownload: (order: Order) => void;
}

export const OrderDetailsScreen: React.FC<OrderDetailsScreenProps> = ({
  order,
  language,
  onBack,
  onGoToDownload,
}) => {
  const t = translations[language];

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="mx-auto max-w-xl space-y-6 pb-24">
      {/* Top Bar */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-2 rounded-xl border border-neutral-800 bg-neutral-900 px-3 py-1.5 text-xs font-semibold text-neutral-300 hover:text-white"
        >
          {language === 'ar' ? <ArrowRight className="h-4 w-4" /> : <ArrowLeft className="h-4 w-4" />}
          <span>{language === 'ar' ? 'الرجوع للطلبات' : 'Back to Orders'}</span>
        </button>

        <button
          onClick={handlePrint}
          className="flex items-center gap-1.5 rounded-xl border border-neutral-800 bg-neutral-900 px-3 py-1.5 text-xs font-semibold text-neutral-300 hover:text-white"
        >
          <Printer className="h-4 w-4 text-amber-400" />
          <span>{t.downloadReceipt}</span>
        </button>
      </div>

      {/* Invoice Card */}
      <div className="rounded-3xl border border-neutral-800 bg-neutral-900/90 p-6 shadow-2xl backdrop-blur-md">
        {/* Invoice Top */}
        <div className="flex items-start justify-between border-b border-neutral-800 pb-5">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-extrabold text-white">Remo Al-Mal Invoice</span>
              <span className="rounded bg-amber-400/20 px-2 py-0.5 text-[10px] font-bold text-amber-400 uppercase">
                {order.status}
              </span>
            </div>
            <p className="mt-1 font-mono text-xs text-neutral-400">
              Order ID: #{order.id}
            </p>
            <p className="text-[11px] text-neutral-500">
              {new Date(order.created_at).toLocaleString()}
            </p>
          </div>

          <div className="text-end">
            <span className="text-xs text-neutral-400 block">{language === 'ar' ? 'المبلغ الإجمالي' : 'Total Amount'}</span>
            <span className="text-2xl font-black text-amber-400">${order.total_amount.toFixed(2)}</span>
          </div>
        </div>

        {/* Item details */}
        <div className="py-4 border-b border-neutral-800 space-y-3">
          <h4 className="text-xs font-bold text-neutral-300 uppercase tracking-wider">
            {language === 'ar' ? 'المنتج الرقمي المشترى' : 'Purchased Digital Item'}
          </h4>
          <div className="flex items-center justify-between rounded-xl bg-neutral-950 p-3.5 border border-neutral-800/80">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-neutral-900 text-amber-400">
                <Package className="h-5 w-5" />
              </div>
              <div>
                <h5 className="text-xs font-bold text-white line-clamp-1">{order.product_title}</h5>
                <span className="text-[11px] text-neutral-400">Product ID: {order.product_id}</span>
              </div>
            </div>
            <span className="text-xs font-bold text-white">${order.total_amount.toFixed(2)}</span>
          </div>
        </div>

        {/* Fee & Commission Breakdown (10% platform rule) */}
        <div className="py-4 border-b border-neutral-800 space-y-2 text-xs">
          <div className="flex justify-between text-neutral-400">
            <span>{language === 'ar' ? 'قيمة المنتج:' : 'Item Subtotal:'}</span>
            <span className="text-white">${order.total_amount.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-neutral-400">
            <span>{language === 'ar' ? 'عمولة منصة Remo Al-Mal (10%):' : 'Remo Platform Commission (10%):'}</span>
            <span className="text-amber-400">${(order.total_amount * 0.1).toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-neutral-400">
            <span>{language === 'ar' ? 'صافي مستحق البائع (90%):' : 'Net Seller Payout (90%):'}</span>
            <span className="text-emerald-400 font-semibold">${(order.total_amount * 0.9).toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-white font-bold pt-2 border-t border-neutral-800/80">
            <span>{language === 'ar' ? 'المبلغ الإجمالي المدفوع:' : 'Grand Total Paid:'}</span>
            <span className="text-amber-400 font-black">${order.total_amount.toFixed(2)}</span>
          </div>
        </div>

        {/* Payment Verification Proof */}
        <div className="pt-4 space-y-2 text-xs">
          <div className="flex justify-between text-neutral-400">
            <span>{language === 'ar' ? 'وسيلة الدفع:' : 'Payment Method:'}</span>
            <span className="font-semibold text-neutral-200 uppercase">{order.payment_method.replace('_', ' ')}</span>
          </div>
          {order.tx_hash && (
            <div className="flex justify-between text-neutral-400">
              <span>{language === 'ar' ? 'معرّف المعاملة (TXID):' : 'TXID Hash:'}</span>
              <span className="font-mono text-[10px] text-amber-400 truncate max-w-[200px]">{order.tx_hash}</span>
            </div>
          )}
          <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 pt-1">
            <ShieldCheck className="h-4 w-4" />
            <span>{language === 'ar' ? 'معاملة مؤكدة ومحمية من قبل خادم Remo Al-Mal' : 'Server-Verified & Secured Transaction'}</span>
          </div>
        </div>

        {/* Action Button */}
        {order.status === 'paid' && (
          <div className="mt-6 pt-2">
            <button
              onClick={() => onGoToDownload(order)}
              className="w-full flex items-center justify-center gap-2 rounded-2xl bg-amber-400 py-3.5 text-xs font-black text-neutral-950 hover:bg-amber-300 transition active:scale-95 shadow-lg shadow-amber-400/20"
            >
              <Download className="h-4 w-4" />
              <span>{t.goToDownload}</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
