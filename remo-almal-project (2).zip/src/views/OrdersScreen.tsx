import React, { useState } from 'react';
import { Package, Clock, CheckCircle2, XCircle, ArrowUpRight, ArrowDownLeft, FileText, Download } from 'lucide-react';
import { Language, Order, Screen, UserProfile } from '../types';
import { translations } from '../lib/i18n';

interface OrdersScreenProps {
  orders: Order[];
  currentUser: UserProfile;
  language: Language;
  onSelectOrder: (order: Order) => void;
  onGoToDownload: (order: Order) => void;
}

export const OrdersScreen: React.FC<OrdersScreenProps> = ({
  orders,
  currentUser,
  language,
  onSelectOrder,
  onGoToDownload,
}) => {
  const t = translations[language];
  const [activeTab, setActiveTab] = useState<'purchases' | 'sales'>(
    currentUser.role === 'seller' ? 'sales' : 'purchases'
  );

  const purchaseOrders = orders.filter((o) => o.buyer_id === currentUser.id || !o.buyer_id);
  const salesOrders = orders.filter((o) => o.seller_id === currentUser.id || o.seller_id === 'seller-remo-01');

  const currentList = activeTab === 'purchases' ? purchaseOrders : salesOrders;

  const getStatusBadge = (status: Order['status']) => {
    switch (status) {
      case 'paid':
      case 'completed':
        return (
          <span className="inline-flex items-center gap-1 rounded-md bg-emerald-400/10 px-2 py-0.5 text-[11px] font-bold text-emerald-400">
            <CheckCircle2 className="h-3 w-3" />
            {t.statusPaid}
          </span>
        );
      case 'pending':
        return (
          <span className="inline-flex items-center gap-1 rounded-md bg-amber-400/10 px-2 py-0.5 text-[11px] font-bold text-amber-400">
            <Clock className="h-3 w-3" />
            {t.statusPending}
          </span>
        );
      case 'cancelled':
        return (
          <span className="inline-flex items-center gap-1 rounded-md bg-rose-400/10 px-2 py-0.5 text-[11px] font-bold text-rose-400">
            <XCircle className="h-3 w-3" />
            {t.statusCancelled}
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-5 pb-24">
      {/* Title */}
      <div>
        <h1 className="text-xl font-black text-white sm:text-2xl">
          {t.ordersTitle}
        </h1>
        <p className="mt-1 text-xs text-neutral-400">
          {t.ordersSubtitle}
        </p>
      </div>

      {/* Tabs Switcher */}
      <div className="flex rounded-2xl border border-neutral-800 bg-neutral-900 p-1">
        <button
          onClick={() => setActiveTab('purchases')}
          className={`flex-1 rounded-xl py-2 text-xs font-bold transition ${
            activeTab === 'purchases'
              ? 'bg-amber-400 text-neutral-950 shadow-sm'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          {t.myPurchasesTab} ({purchaseOrders.length})
        </button>
        <button
          onClick={() => setActiveTab('sales')}
          className={`flex-1 rounded-xl py-2 text-xs font-bold transition ${
            activeTab === 'sales'
              ? 'bg-amber-400 text-neutral-950 shadow-sm'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          {t.mySalesTab} ({salesOrders.length})
        </button>
      </div>

      {/* Orders List */}
      {currentList.length === 0 ? (
        <div className="rounded-2xl border border-neutral-800 bg-neutral-900/40 p-10 text-center text-xs text-neutral-400">
          <Package className="mx-auto h-8 w-8 text-neutral-500 mb-2" />
          <p>{t.noOrders}</p>
        </div>
      ) : (
        <div className="space-y-3">
          {currentList.map((order) => (
            <div
              key={order.id}
              className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 rounded-2xl border border-neutral-800 bg-neutral-900/70 p-4 transition hover:border-amber-400/50"
            >
              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-neutral-800 font-mono text-amber-400">
                  <Package className="h-6 w-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-neutral-400">
                      #{order.id.slice(0, 8)}
                    </span>
                    {getStatusBadge(order.status)}
                  </div>
                  <h3 className="font-bold text-white text-sm mt-0.5 line-clamp-1">
                    {order.product_title}
                  </h3>
                  <div className="mt-1 flex items-center gap-2 text-[11px] text-neutral-400">
                    <span>{new Date(order.created_at).toLocaleString()}</span>
                    <span>•</span>
                    <span className="font-semibold text-neutral-300">
                      {order.payment_method.replace('_', ' ').toUpperCase()}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between sm:justify-end gap-3 w-full sm:w-auto pt-2 sm:pt-0 border-t border-neutral-800/80 sm:border-0">
                <div className="text-start sm:text-end">
                  <span className="text-base font-black text-amber-400 block">
                    ${order.total_amount.toFixed(2)}
                  </span>
                  {activeTab === 'sales' && (
                    <span className="text-[10px] text-neutral-400 block">
                      {language === 'ar' ? `صافيك (90%): $${(order.total_amount * 0.9).toFixed(2)}` : `Net (90%): $${(order.total_amount * 0.9).toFixed(2)}`}
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onSelectOrder(order)}
                    className="flex items-center gap-1 rounded-xl border border-neutral-700 bg-neutral-800 px-3 py-1.5 text-xs font-semibold text-neutral-200 hover:text-white"
                  >
                    <FileText className="h-3.5 w-3.5 text-amber-400" />
                    <span>{language === 'ar' ? 'التفاصيل' : 'Details'}</span>
                  </button>

                  {order.status === 'paid' && activeTab === 'purchases' && (
                    <button
                      onClick={() => onGoToDownload(order)}
                      className="flex items-center gap-1 rounded-xl bg-amber-400 px-3 py-1.5 text-xs font-bold text-neutral-950 hover:bg-amber-300"
                    >
                      <Download className="h-3.5 w-3.5" />
                      <span>{language === 'ar' ? 'تحميل' : 'Download'}</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
