import React, { useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  ShieldCheck,
  CreditCard,
  QrCode,
  Copy,
  Check,
  AlertTriangle,
  Wallet as WalletIcon,
  Lock,
  Zap,
  Info
} from 'lucide-react';
import { DigitalProduct, Language, PaymentMethod, UserProfile, Wallet } from '../types';
import { translations } from '../lib/i18n';

interface PaymentMethodScreenProps {
  product: DigitalProduct;
  currentUser: UserProfile;
  wallet: Wallet;
  language: Language;
  onBack: () => void;
  onProceedToVerification: (paymentMethod: PaymentMethod, paymentData: Record<string, any>) => void;
}

export const PaymentMethodScreen: React.FC<PaymentMethodScreenProps> = ({
  product,
  currentUser,
  wallet,
  language,
  onBack,
  onProceedToVerification,
}) => {
  const t = translations[language];

  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod>('crypto_usdt_trc20');
  const [copied, setCopied] = useState(false);
  const [txHash, setTxHash] = useState('');
  const [cardHolder, setCardHolder] = useState(currentUser.full_name || '');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvc, setCardCvc] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Official merchant settlement deposit addresses for USDT
  const TRC20_ADDRESS = 'TX9RemoAlMalOfficialTRC20Gateway7qY8x';
  const BEP20_ADDRESS = '0x8f3C9remoAlMalOfficialBEP20Settlement4a2b';

  const currentCryptoAddress =
    selectedMethod === 'crypto_usdt_trc20' ? TRC20_ADDRESS : BEP20_ADDRESS;

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(currentCryptoAddress);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleProceed = () => {
    setErrorMsg(null);

    if (selectedMethod === 'crypto_usdt_trc20' || selectedMethod === 'crypto_usdt_bep20') {
      if (!txHash.trim()) {
        setErrorMsg(
          language === 'ar'
            ? 'يرجى إدخال رقم المعاملة (TXID Hash) للتحقق منها عبر شبكة البلوكشين.'
            : 'Please enter the Transaction Hash (TXID) for blockchain network verification.'
        );
        return;
      }
      onProceedToVerification(selectedMethod, {
        tx_hash: txHash.trim(),
        network: selectedMethod === 'crypto_usdt_trc20' ? 'TRC-20' : 'BEP-20',
        amount: product.price,
      });
    } else if (selectedMethod === 'card_visa_mastercard') {
      if (cardNumber.replace(/\s+/g, '').length < 15 || !cardExpiry || !cardCvc) {
        setErrorMsg(
          language === 'ar'
            ? 'يرجى إدخال جميع بيانات البطاقة البنكية للمصادقة الآمنة عبر الخادم.'
            : 'Please complete all card details for server-side 3D Secure authentication.'
        );
        return;
      }
      onProceedToVerification(selectedMethod, {
        card_last4: cardNumber.slice(-4) || '4242',
        card_holder: cardHolder,
        card_type: cardNumber.startsWith('5') ? 'Mastercard' : 'Visa',
        amount: product.price,
      });
    } else if (selectedMethod === 'wallet') {
      if (wallet.balance < product.price) {
        setErrorMsg(
          language === 'ar'
            ? `رصيد محفظتك غير كافٍ ($${wallet.balance.toFixed(2)}). يمكنك شحن المحفظة أو اختيار وسيلة دفع أخرى.`
            : `Insufficient wallet balance ($${wallet.balance.toFixed(2)}). Please top up or choose another method.`
        );
        return;
      }
      onProceedToVerification('wallet', {
        wallet_id: wallet.id,
        amount: product.price,
      });
    }
  };

  return (
    <div className="mx-auto max-w-xl space-y-6 pb-24">
      {/* Top Bar */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-2 rounded-xl border border-neutral-800 bg-neutral-900 px-3 py-1.5 text-xs font-semibold text-neutral-300 hover:text-white"
        >
          {language === 'ar' ? <ArrowRight className="h-4 w-4" /> : <ArrowLeft className="h-4 w-4" />}
          <span>{language === 'ar' ? 'الرجوع للمنتج' : 'Back to Product'}</span>
        </button>

        <span className="text-xs font-bold text-neutral-400">
          {language === 'ar' ? 'الخطوة 1 من 2: اختيار الدفع' : 'Step 1 of 2: Payment'}
        </span>
      </div>

      {/* Product Summary Header */}
      <div className="flex items-center justify-between rounded-2xl border border-amber-400/20 bg-neutral-900/80 p-4">
        <div className="flex items-center gap-3">
          <img
            src={product.preview_image}
            alt={product.title}
            className="h-12 w-16 rounded-xl object-cover"
          />
          <div>
            <h3 className="text-xs font-bold text-white line-clamp-1">{product.title}</h3>
            <span className="text-[11px] text-neutral-400 font-mono">
              {language === 'ar' ? 'المبلغ المستحق للدفع:' : 'Payable Amount:'}
            </span>
          </div>
        </div>
        <div className="text-end">
          <span className="text-lg font-black text-amber-400">${product.price.toFixed(2)}</span>
          <span className="text-[11px] text-neutral-400 block font-bold">USD</span>
        </div>
      </div>

      {/* Mandatory Financial Disclaimer & Test Mode Badge */}
      <div className="rounded-2xl border border-amber-500/40 bg-amber-950/20 p-3.5 text-xs text-amber-200">
        <div className="flex items-center gap-2 font-bold text-amber-400 mb-1">
          <AlertTriangle className="h-4 w-4 shrink-0" />
          <span>{language === 'ar' ? 'تنبيه الأمان المالي والشفافية (Sandbox Simulation):' : 'Financial Security Notice (Sandbox Simulation):'}</span>
        </div>
        <p className="leading-relaxed text-[11px] text-neutral-300">
          {language === 'ar'
            ? 'بوابات الدفع بالعملات المشفرة (USDT) والبطاقات معروضة في وضع المعاينة والاختبار البرمجي. لا تدعي المنصة اكتمال تحويل أموال حقيقية حتى يتم ربط مزوّد دفع رسمي مرخص واختبار الـ Webhook من جهة الخادم.'
            : 'Payment methods are running in Sandbox mode. Live fiat or crypto settlements will be processed once an official payment provider webhook is connected and verified server-side.'}
        </p>
      </div>

      {/* Payment Methods Options */}
      <div className="space-y-3">
        <h2 className="text-sm font-bold text-white">
          {t.paymentSelectTitle}
        </h2>

        <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
          {/* USDT TRC-20 */}
          <button
            type="button"
            onClick={() => {
              setSelectedMethod('crypto_usdt_trc20');
              setErrorMsg(null);
            }}
            className={`flex items-start gap-3 rounded-2xl border p-4 text-start transition ${
              selectedMethod === 'crypto_usdt_trc20'
                ? 'border-amber-400 bg-amber-400/10 text-white shadow-md'
                : 'border-neutral-800 bg-neutral-900/60 text-neutral-400 hover:border-neutral-700'
            }`}
          >
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-400 font-black">
              ₮
            </div>
            <div>
              <div className="text-xs font-bold text-white">{t.payWithCryptoTRC20}</div>
              <div className="text-[10px] text-neutral-400 mt-0.5">
                {language === 'ar' ? 'شبكة ترون الفورية برسم تحويل منخفض' : 'Tron network low gas fee'}
              </div>
            </div>
          </button>

          {/* USDT BEP-20 */}
          <button
            type="button"
            onClick={() => {
              setSelectedMethod('crypto_usdt_bep20');
              setErrorMsg(null);
            }}
            className={`flex items-start gap-3 rounded-2xl border p-4 text-start transition ${
              selectedMethod === 'crypto_usdt_bep20'
                ? 'border-amber-400 bg-amber-400/10 text-white shadow-md'
                : 'border-neutral-800 bg-neutral-900/60 text-neutral-400 hover:border-neutral-700'
            }`}
          >
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-amber-500/10 text-amber-400 font-black">
              ₮
            </div>
            <div>
              <div className="text-xs font-bold text-white">{t.payWithCryptoBEP20}</div>
              <div className="text-[10px] text-neutral-400 mt-0.5">
                {language === 'ar' ? 'شبكة بينانس الذكية BSC' : 'BNB Smart Chain (BSC)'}
              </div>
            </div>
          </button>

          {/* Bank Cards */}
          <button
            type="button"
            onClick={() => {
              setSelectedMethod('card_visa_mastercard');
              setErrorMsg(null);
            }}
            className={`flex items-start gap-3 rounded-2xl border p-4 text-start transition ${
              selectedMethod === 'card_visa_mastercard'
                ? 'border-amber-400 bg-amber-400/10 text-white shadow-md'
                : 'border-neutral-800 bg-neutral-900/60 text-neutral-400 hover:border-neutral-700'
            }`}
          >
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-blue-500/10 text-blue-400">
              <CreditCard className="h-5 w-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-white">{t.payWithCard}</div>
              <div className="text-[10px] text-neutral-400 mt-0.5">
                {language === 'ar' ? 'فيزا وماستركارد عبر بوابة مشفرة' : 'Visa & Mastercard SSL 256-bit'}
              </div>
            </div>
          </button>

          {/* Remo Al-Mal Wallet */}
          <button
            type="button"
            onClick={() => {
              setSelectedMethod('wallet');
              setErrorMsg(null);
            }}
            className={`flex items-start gap-3 rounded-2xl border p-4 text-start transition ${
              selectedMethod === 'wallet'
                ? 'border-amber-400 bg-amber-400/10 text-white shadow-md'
                : 'border-neutral-800 bg-neutral-900/60 text-neutral-400 hover:border-neutral-700'
            }`}
          >
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-amber-400/10 text-amber-400">
              <WalletIcon className="h-5 w-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-white">{t.payWithWallet}</div>
              <div className="text-[10px] text-neutral-400 mt-0.5">
                {language === 'ar' ? `الرصيد: $${wallet.balance.toFixed(2)}` : `Balance: $${wallet.balance.toFixed(2)}`}
              </div>
            </div>
          </button>
        </div>
      </div>

      {errorMsg && (
        <div className="flex items-start gap-2 rounded-xl border border-rose-500/30 bg-rose-950/40 p-3 text-xs text-rose-300">
          <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5 text-rose-400" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Dynamic Payment Method Form */}
      {(selectedMethod === 'crypto_usdt_trc20' || selectedMethod === 'crypto_usdt_bep20') && (
        <div className="rounded-3xl border border-neutral-800 bg-neutral-900/80 p-5 space-y-4">
          <div className="flex items-start gap-2.5 rounded-xl bg-amber-400/10 border border-amber-400/20 p-3 text-xs text-amber-300">
            <Info className="h-4 w-4 shrink-0 text-amber-400 mt-0.5" />
            <p className="leading-relaxed">{t.cryptoWarning}</p>
          </div>

          <div>
            <label className="block text-xs font-bold text-neutral-300 mb-1">
              {language === 'ar' ? 'عنوان محفظة الإيداع الرسمية:' : 'Remo Official Deposit Address:'}
            </label>
            <div className="flex items-center gap-2 rounded-xl border border-neutral-800 bg-neutral-950 p-2.5">
              <span className="flex-1 font-mono text-xs text-amber-400 truncate">
                {currentCryptoAddress}
              </span>
              <button
                type="button"
                onClick={handleCopyAddress}
                className="flex items-center gap-1 rounded-lg bg-neutral-800 px-2.5 py-1 text-xs font-semibold text-neutral-200 hover:text-white"
              >
                {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                <span>{copied ? (language === 'ar' ? 'تم النسخ!' : 'Copied!') : t.copyAddress}</span>
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-neutral-300 mb-1">
              {language === 'ar' ? 'المبلغ المطلوب إرساله بالضبط:' : 'Exact USDT to send:'}
            </label>
            <div className="rounded-xl border border-neutral-800 bg-neutral-950 p-2.5 font-mono text-sm text-white font-black">
              {product.price.toFixed(2)} USDT
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-neutral-300 mb-1">
              {language === 'ar' ? 'رقم المعاملة (TXID / Hash):' : 'Transaction Hash (TXID):'}
            </label>
            <input
              type="text"
              value={txHash}
              onChange={(e) => setTxHash(e.target.value)}
              placeholder="e.g. 7f8c9d2a1b3e4f5061728394a5b6c7d8e9f0123456789abcdef0123456789abc"
              className="w-full rounded-xl border border-neutral-800 bg-neutral-950 p-2.5 text-xs font-mono text-white placeholder-neutral-500 focus:border-amber-400 focus:outline-none"
            />
            <p className="mt-1 text-[10px] text-neutral-500">
              {language === 'ar'
                ? 'سيقوم الخادم بالتحقق من العقد الذكي والتأكد من عدم استخدام المعاملة سابقاً (Idempotent).'
                : 'Server executes cryptographic ledger confirmation against double-spend.'}
            </p>
          </div>
        </div>
      )}

      {selectedMethod === 'card_visa_mastercard' && (
        <div className="rounded-3xl border border-neutral-800 bg-neutral-900/80 p-5 space-y-3.5">
          <div className="flex items-center gap-2 rounded-xl bg-blue-500/10 border border-blue-500/20 p-3 text-xs text-blue-300">
            <Lock className="h-4 w-4 shrink-0 text-blue-400" />
            <p>{t.pciNotice}</p>
          </div>

          <div>
            <label className="block text-xs font-bold text-neutral-300 mb-1">
              {t.cardHolderName}
            </label>
            <input
              type="text"
              value={cardHolder}
              onChange={(e) => setCardHolder(e.target.value)}
              className="w-full rounded-xl border border-neutral-800 bg-neutral-950 px-3 py-2 text-xs text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-neutral-300 mb-1">
              {t.cardNumber}
            </label>
            <input
              type="text"
              maxLength={19}
              value={cardNumber}
              onChange={(e) => {
                const val = e.target.value.replace(/\D/g, '').replace(/(.{4})/g, '$1 ').trim();
                setCardNumber(val);
              }}
              placeholder="4242 •••• •••• 4242"
              className="w-full rounded-xl border border-neutral-800 bg-neutral-950 px-3 py-2 text-xs font-mono text-white"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-neutral-300 mb-1">
                {t.cardExpiry}
              </label>
              <input
                type="text"
                maxLength={5}
                value={cardExpiry}
                onChange={(e) => setCardExpiry(e.target.value)}
                placeholder="12/28"
                className="w-full rounded-xl border border-neutral-800 bg-neutral-950 px-3 py-2 text-xs font-mono text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-neutral-300 mb-1">
                {t.cardCvc}
              </label>
              <input
                type="password"
                maxLength={4}
                value={cardCvc}
                onChange={(e) => setCardCvc(e.target.value)}
                placeholder="•••"
                className="w-full rounded-xl border border-neutral-800 bg-neutral-950 px-3 py-2 text-xs font-mono text-white"
              />
            </div>
          </div>
        </div>
      )}

      {selectedMethod === 'wallet' && (
        <div className="rounded-3xl border border-neutral-800 bg-neutral-900/80 p-5 space-y-3">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span>{t.walletBalance}:</span>
            <span className="font-bold text-white">${wallet.balance.toFixed(2)}</span>
          </div>
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span>{language === 'ar' ? 'المبلغ المطلوب خصمه:' : 'Deduction Amount:'}</span>
            <span className="font-bold text-rose-400">-${product.price.toFixed(2)}</span>
          </div>
          <div className="flex items-center justify-between text-xs text-neutral-300 pt-2 border-t border-neutral-800 font-bold">
            <span>{language === 'ar' ? 'الرصيد المتبقي بعد الشراء:' : 'Balance After Purchase:'}</span>
            <span className="font-mono text-amber-400">
              ${Math.max(0, wallet.balance - product.price).toFixed(2)}
            </span>
          </div>
        </div>
      )}

      {/* Confirmation Button */}
      <button
        type="button"
        onClick={handleProceed}
        className="w-full flex items-center justify-center gap-2 rounded-2xl bg-amber-400 py-4 text-sm font-black text-neutral-950 hover:bg-amber-300 transition active:scale-95 shadow-lg shadow-amber-400/20"
      >
        <Zap className="h-4 w-4 fill-current" />
        <span>{t.confirmPaymentBtn}</span>
      </button>
    </div>
  );
};
