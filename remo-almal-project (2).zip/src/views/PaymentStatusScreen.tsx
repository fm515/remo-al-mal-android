import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import {
  CheckCircle2,
  RefreshCw,
  AlertTriangle,
  ShieldCheck,
  Download,
  ArrowRight,
  ArrowLeft,
  Lock,
  ExternalLink
} from 'lucide-react';
import { DigitalProduct, Language, Order, PaymentMethod } from '../types';
import { translations } from '../lib/i18n';

interface PaymentStatusScreenProps {
  order: Order;
  product: DigitalProduct;
  language: Language;
  onSuccessNavigate: (order: Order) => void;
  onRetry: () => void;
}

export const PaymentStatusScreen: React.FC<PaymentStatusScreenProps> = ({
  order,
  product,
  language,
  onSuccessNavigate,
  onRetry,
}) => {
  const t = translations[language];

  const [step, setStep] = useState<'verifying' | 'success' | 'failed'>('verifying');
  const [statusMessage, setStatusMessage] = useState(
    language === 'ar'
      ? 'جاري الاتصال بخادم المعالجة وعقد البلوكشين الذكي...'
      : 'Contacting settlement server and blockchain smart contract...'
  );

  useEffect(() => {
    let t1: NodeJS.Timeout;
    let t2: NodeJS.Timeout;
    let t3: NodeJS.Timeout;

    t1 = setTimeout(() => {
      setStatusMessage(
        language === 'ar'
          ? 'تم استلام إشعار الدفع • جاري التحقق من التوقيع الرقمي (Signature Verification)...'
          : 'Payment packet received • Validating digital cryptographic signature...'
      );
    }, 1200);

    t2 = setTimeout(() => {
      setStatusMessage(
        language === 'ar'
          ? 'تم تأكيد المعاملة من الخادم • جاري إصدار ترخيص التنزيل المؤقت...'
          : 'Transaction confirmed by server • Generating secure expiring deliverable token...'
      );
    }, 2400);

    t3 = setTimeout(() => {
      setStep('success');
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#FACC15', '#EAB308', '#FFFFFF', '#0A0A0C'],
      });
    }, 3600);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, [language]);

  return (
    <div className="mx-auto max-w-md pb-24 text-center">
      <div className="rounded-3xl border border-neutral-800 bg-neutral-900/90 p-6 sm:p-8 shadow-2xl backdrop-blur-md">
        {step === 'verifying' && (
          <div className="py-6 space-y-4">
            <div className="relative mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-amber-400/10 text-amber-400">
              <RefreshCw className="h-10 w-10 animate-spin" />
            </div>

            <h2 className="text-lg font-black text-white sm:text-xl">
              {t.paymentStatusTitle}
            </h2>

            <p className="text-xs text-neutral-300 leading-relaxed font-mono">
              {statusMessage}
            </p>

            <div className="pt-4 border-t border-neutral-800/80 text-[11px] text-neutral-400 flex items-center justify-center gap-1.5">
              <ShieldCheck className="h-4 w-4 text-emerald-400" />
              <span>Remo Al-Mal Idempotency & RLS Protection</span>
            </div>
          </div>
        )}

        {step === 'success' && (
          <div className="py-4 space-y-4">
            <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-emerald-400/10 text-emerald-400 ring-2 ring-emerald-400/30">
              <CheckCircle2 className="h-10 w-10 stroke-[2.5]" />
            </div>

            <h2 className="text-xl font-black text-white sm:text-2xl">
              {t.paymentSuccess}
            </h2>

            <div className="inline-block rounded-full bg-amber-400/20 px-3 py-1 text-[11px] font-bold text-amber-300">
              {language === 'ar' ? 'وضع المحاكاة والاختبار (Sandbox Simulation)' : 'Sandbox Simulation Mode'}
            </div>

            <p className="text-xs text-neutral-300 leading-relaxed">
              {t.paymentSuccessDesc}
            </p>

            {/* Token Badge */}
            <div className="rounded-2xl border border-neutral-800 bg-neutral-950 p-4 text-start">
              <div className="flex items-center justify-between text-xs text-neutral-400 mb-1">
                <span>{language === 'ar' ? 'رقم الطلب المؤكد:' : 'Confirmed Order ID:'}</span>
                <span className="font-mono text-amber-400 font-bold">#{order.id.slice(0, 8)}</span>
              </div>
              <div className="flex items-center justify-between text-xs text-neutral-400 mb-1">
                <span>{language === 'ar' ? 'المنتج:' : 'Product:'}</span>
                <span className="font-semibold text-white truncate max-w-[170px]">{product.title}</span>
              </div>
              <div className="flex items-center justify-between text-xs text-neutral-400">
                <span>{language === 'ar' ? 'حالة التنزيل:' : 'Download Access:'}</span>
                <span className="font-bold text-emerald-400">نشط (مؤقت 60 دقيقة)</span>
              </div>
            </div>

            <button
              onClick={() => onSuccessNavigate(order)}
              className="w-full flex items-center justify-center gap-2 rounded-2xl bg-amber-400 py-3.5 text-xs font-black text-neutral-950 hover:bg-amber-300 transition active:scale-95 shadow-lg shadow-amber-400/20"
            >
              <Download className="h-4 w-4" />
              <span>{t.accessDownloadBtn}</span>
            </button>
          </div>
        )}

        {step === 'failed' && (
          <div className="py-6 space-y-4">
            <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-rose-500/10 text-rose-400">
              <AlertTriangle className="h-10 w-10" />
            </div>
            <h2 className="text-lg font-black text-white">
              {t.paymentFailed}
            </h2>
            <p className="text-xs text-neutral-400 leading-relaxed">
              {language === 'ar'
                ? 'تعذر التحقق من وصول الدفعة أو أن المعاملة لم تسجل بعد على الشبكة.'
                : 'Unable to verify payment settlement or hash was not yet confirmed.'}
            </p>
            <button
              onClick={onRetry}
              className="w-full rounded-2xl bg-neutral-800 py-3 text-xs font-bold text-white hover:bg-neutral-700"
            >
              {language === 'ar' ? 'إعادة المحاولة' : 'Try Again'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
