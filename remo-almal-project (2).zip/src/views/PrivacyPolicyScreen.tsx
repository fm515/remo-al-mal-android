import React from 'react';
import { ShieldCheck, Lock, Database, ArrowLeft, ArrowRight } from 'lucide-react';
import { Language, Screen } from '../types';
import { translations } from '../lib/i18n';

interface PrivacyPolicyScreenProps {
  language: Language;
  setScreen: (screen: Screen) => void;
}

export const PrivacyPolicyScreen: React.FC<PrivacyPolicyScreenProps> = ({
  language,
  setScreen,
}) => {
  const t = translations[language];

  return (
    <div className="mx-auto max-w-xl space-y-6 pb-24">
      <div className="flex items-center justify-between">
        <button
          onClick={() => setScreen('settings')}
          className="flex items-center gap-2 rounded-xl border border-neutral-800 bg-neutral-900 px-3 py-1.5 text-xs font-semibold text-neutral-300 hover:text-white"
        >
          {language === 'ar' ? <ArrowRight className="h-4 w-4" /> : <ArrowLeft className="h-4 w-4" />}
          <span>{language === 'ar' ? 'الرجوع للإعدادات' : 'Back to Settings'}</span>
        </button>

        <span className="text-[11px] font-mono text-neutral-500">
          Last Updated: 2026-10-27
        </span>
      </div>

      <div className="rounded-3xl border border-neutral-800 bg-neutral-900/80 p-6 sm:p-8 space-y-5 shadow-2xl">
        <div className="flex items-center gap-3 border-b border-neutral-800 pb-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-400/10 text-amber-400">
            <ShieldCheck className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-base font-bold text-white sm:text-lg">{t.privacyTitle}</h1>
            <p className="text-xs text-neutral-400">Remo Al-Mal Financial Security & Data Governance</p>
          </div>
        </div>

        <div className="space-y-4 text-xs text-neutral-300 leading-relaxed">
          <section>
            <h3 className="font-bold text-white text-sm mb-1.5 flex items-center gap-2">
              <Lock className="h-4 w-4 text-amber-400" />
              <span>1. عدم تخزين البيانات المالية الحساسة</span>
            </h3>
            <p>
              تلتزم منصة Remo Al-Mal بالمعايير العالمية الصارمة (PCI-DSS): لا نقوم بتخزين أرقام البطاقات الائتمانية أو رموز CVV على خوادمنا. تتم معالجة المدفوعات البنكية عبر بوابات تشفير بنكية متوافقة ومرخصة، بينما تتم مدفوعات العملات المشفّرة (USDT) مباشرة عبر عقود البلوكشين الذكية.
            </p>
          </section>

          <section>
            <h3 className="font-bold text-white text-sm mb-1.5 flex items-center gap-2">
              <Database className="h-4 w-4 text-amber-400" />
              <span>2. أمان قاعدة البيانات وسياسات RLS</span>
            </h3>
            <p>
              يتم حفظ بيانات الحسابات والملفات الشخصية عبر Supabase المحمية بسياسات مستوى الصف (Row Level Security - RLS). لا يمكن لأي مستخدم أو بائع الوصول إلى بيانات أو ملفات مستخدم آخر.
            </p>
          </section>

          <section>
            <h3 className="font-bold text-white text-sm mb-1.5 flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-amber-400" />
              <span>3. حماية الملفات الرقمية الخاصة</span>
            </h3>
            <p>
              تُخزّن جميع ملفات المنتجات الرقمية في مساحة خاصة ومقفلة (digital-product-files). لا تتوفر أي روابط تحميل عامة أو دائمة داخل التطبيق. يتم إصدار روابط مشفرة مؤقتة (Expiring Signed URLs) تنتهي صلاحيتها خلال 60 دقيقة فقط للمشتري الموثّق بعد تأكيد الدفع.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
};
