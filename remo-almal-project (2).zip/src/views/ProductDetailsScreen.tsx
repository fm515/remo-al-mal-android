import React from 'react';
import {
  ArrowLeft,
  ArrowRight,
  ShieldCheck,
  Star,
  Download,
  CheckCircle2,
  Lock,
  FileCode,
  HardDrive,
  Calendar,
  Share2,
  Zap,
  Sparkles
} from 'lucide-react';
import { DigitalProduct, Language } from '../types';
import { translations } from '../lib/i18n';

interface ProductDetailsScreenProps {
  product: DigitalProduct;
  language: Language;
  onBack: () => void;
  onBuy: (product: DigitalProduct) => void;
}

export const ProductDetailsScreen: React.FC<ProductDetailsScreenProps> = ({
  product,
  language,
  onBack,
  onBuy,
}) => {
  const t = translations[language];

  return (
    <div className="space-y-6 pb-24">
      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-2 rounded-xl border border-neutral-800 bg-neutral-900/80 px-3 py-1.5 text-xs font-semibold text-neutral-300 hover:text-white hover:border-amber-400/60 transition"
        >
          {language === 'ar' ? (
            <ArrowRight className="h-4 w-4" />
          ) : (
            <ArrowLeft className="h-4 w-4" />
          )}
          <span>{language === 'ar' ? 'الرجوع للمنتجات' : 'Back to Products'}</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="rounded-lg bg-amber-400/10 border border-amber-400/30 px-2.5 py-1 text-[11px] font-bold text-amber-400 uppercase tracking-wider">
            {product.category}
          </span>
        </div>
      </div>

      {/* Main Preview Banner */}
      <div className="relative overflow-hidden rounded-3xl border border-neutral-800 bg-neutral-900 shadow-2xl">
        <div className="aspect-video w-full bg-neutral-950">
          <img
            src={product.preview_image}
            alt={product.title}
            className="h-full w-full object-cover"
          />
        </div>
        <div className="absolute top-4 right-4 rounded-xl bg-neutral-950/85 px-3 py-1.5 backdrop-blur-md border border-neutral-800">
          <span className="text-xl font-black text-amber-400">
            ${product.price.toFixed(2)}
          </span>
          <span className="text-[11px] text-neutral-400 mx-1">{product.currency}</span>
        </div>
      </div>

      {/* Header Info */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center gap-3 text-xs text-neutral-400">
          <div className="flex items-center gap-1 text-amber-400 font-semibold">
            <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
            <span>{product.rating}</span>
            <span className="text-neutral-400">({product.reviews_count} {t.rating})</span>
          </div>
          <span>•</span>
          <div className="flex items-center gap-1">
            <Download className="h-3.5 w-3.5 text-neutral-400" />
            <span>{product.downloads_count} {t.downloads}</span>
          </div>
          <span>•</span>
          <div className="flex items-center gap-1">
            <Calendar className="h-3.5 w-3.5 text-neutral-400" />
            <span>{new Date(product.created_at).toLocaleDateString()}</span>
          </div>
        </div>

        <h1 className="text-xl font-extrabold text-white sm:text-2xl leading-snug">
          {language === 'ar' ? product.title : (product.title_en || product.title)}
        </h1>

        <p className="text-xs text-neutral-300 sm:text-sm leading-relaxed whitespace-pre-line">
          {language === 'ar' ? product.description : (product.description_en || product.description)}
        </p>
      </div>

      {/* Deliverable File Specifications Card */}
      <div className="rounded-2xl border border-neutral-800 bg-neutral-900/60 p-4">
        <h3 className="text-xs font-bold text-neutral-300 uppercase tracking-wider mb-3 flex items-center gap-1.5">
          <FileCode className="h-4 w-4 text-amber-400" />
          <span>{language === 'ar' ? 'مواصفات الملف الرقمي الخاص' : 'Digital Asset Technical Specifications'}</span>
        </h3>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 text-xs">
          <div className="rounded-xl bg-neutral-950/60 p-2.5 border border-neutral-800/80">
            <span className="text-neutral-400 block text-[11px]">{t.fileType}</span>
            <span className="font-semibold text-white mt-0.5 block">{product.file_type || 'ZIP Archive'}</span>
          </div>
          <div className="rounded-xl bg-neutral-950/60 p-2.5 border border-neutral-800/80">
            <span className="text-neutral-400 block text-[11px]">{t.fileSize}</span>
            <span className="font-semibold text-white mt-0.5 block">{product.file_size || '24.5 MB'}</span>
          </div>
          <div className="rounded-xl bg-neutral-950/60 p-2.5 border border-neutral-800/80 col-span-2 sm:col-span-1">
            <span className="text-neutral-400 block text-[11px]">
              {language === 'ar' ? 'مساحة التخزين' : 'Storage Engine'}
            </span>
            <span className="font-semibold text-emerald-400 mt-0.5 block truncate">
              digital-product-files (Private)
            </span>
          </div>
        </div>
      </div>

      {/* Features Checklist */}
      {product.features && product.features.length > 0 && (
        <div className="rounded-2xl border border-neutral-800 bg-neutral-900/60 p-4">
          <h3 className="text-xs font-bold text-neutral-300 uppercase tracking-wider mb-3 flex items-center gap-1.5">
            <Sparkles className="h-4 w-4 text-amber-400" />
            <span>{t.productFeatures}</span>
          </h3>
          <div className="space-y-2">
            {product.features.map((feat, index) => (
              <div key={index} className="flex items-start gap-2.5 text-xs text-neutral-200">
                <CheckCircle2 className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
                <span>{feat}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Seller Badge & Guarantee Notice */}
      <div className="rounded-2xl border border-amber-400/30 bg-amber-400/5 p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-400 text-neutral-950 font-black">
            <ShieldCheck className="h-5 w-5" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white">
              {t.verifiedProduct}
            </h4>
            <p className="text-[11px] text-neutral-400 mt-0.5">
              {t.guaranteeNotice}
            </p>
          </div>
        </div>
        <div className="text-xs font-bold text-amber-400 sm:text-end shrink-0">
          <span>{t.licenseInfo}</span>
        </div>
      </div>

      {/* Sticky Bottom Purchase Bar */}
      <div className="fixed bottom-14 left-0 right-0 z-30 border-t border-neutral-800 bg-neutral-950/95 p-3 backdrop-blur-lg safe-bottom">
        <div className="mx-auto flex max-w-lg items-center justify-between gap-4">
          <div>
            <span className="text-[10px] uppercase font-bold text-neutral-400 block">
              {language === 'ar' ? 'السعر الإجمالي' : 'Total Price'}
            </span>
            <div className="flex items-baseline gap-1">
              <span className="text-xl font-black text-amber-400">
                ${product.price.toFixed(2)}
              </span>
              <span className="text-[11px] text-neutral-400">USD</span>
            </div>
          </div>

          <button
            onClick={() => onBuy(product)}
            className="flex-1 flex items-center justify-center gap-2 rounded-2xl bg-amber-400 py-3.5 px-6 text-sm font-extrabold text-neutral-950 shadow-lg shadow-amber-400/20 hover:bg-amber-300 transition active:scale-95"
          >
            <Zap className="h-4 w-4 fill-current" />
            <span>{t.buyNowBtn}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
