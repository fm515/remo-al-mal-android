import React, { useState } from 'react';
import {
  Wallet as WalletIcon,
  ArrowUpRight,
  ArrowDownLeft,
  ShieldCheck,
  LogOut,
  Clock,
  User,
  DollarSign,
  PlusCircle,
  Briefcase
} from 'lucide-react';
import { Language, Screen, UserProfile, Wallet, WalletTransaction } from '../types';
import { translations } from '../lib/i18n';

interface ProfileScreenProps {
  user: UserProfile;
  wallet: Wallet;
  transactions: WalletTransaction[];
  language: Language;
  setScreen: (screen: Screen) => void;
  onLogout: () => void;
  onDeposit: (amount: number) => void;
  onWithdraw: (amount: number) => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  user,
  wallet,
  transactions,
  language,
  setScreen,
  onLogout,
  onDeposit,
  onWithdraw,
}) => {
  const t = translations[language];
  const [showDepositModal, setShowDepositModal] = useState(false);
  const [depositAmount, setDepositAmount] = useState('50');

  return (
    <div className="space-y-6 pb-24">
      {/* Profile Header Card */}
      <div className="flex flex-col sm:flex-row items-center sm:items-start justify-between gap-4 rounded-3xl border border-neutral-800 bg-neutral-900/80 p-5 sm:p-6">
        <div className="flex flex-col sm:flex-row items-center sm:items-center gap-4 text-center sm:text-start">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-amber-400 text-neutral-950 text-2xl font-black shadow-lg shadow-amber-400/20">
            {user.full_name?.charAt(0) || 'U'}
          </div>
          <div>
            <div className="flex items-center gap-2 justify-center sm:justify-start">
              <h1 className="text-lg font-bold text-white sm:text-xl">{user.full_name}</h1>
              <span className="rounded-full bg-amber-400/10 border border-amber-400/30 px-2 py-0.5 text-[10px] font-bold text-amber-400 uppercase">
                {user.role === 'seller' ? (language === 'ar' ? 'بائع معتمد' : 'Seller') : (language === 'ar' ? 'مشتري' : 'Buyer')}
              </span>
            </div>
            <p className="text-xs text-neutral-400 font-mono mt-0.5">{user.email}</p>
            <div className="mt-2 flex items-center gap-1.5 text-[11px] text-emerald-400">
              <ShieldCheck className="h-3.5 w-3.5" />
              <span>{t.securityStatus}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {user.role === 'seller' && (
            <button
              onClick={() => setScreen('seller_dashboard')}
              className="flex items-center gap-1.5 rounded-xl bg-neutral-800 px-3.5 py-2 text-xs font-bold text-neutral-200 hover:border-amber-400/50 hover:text-white transition"
            >
              <Briefcase className="h-4 w-4 text-amber-400" />
              <span>{t.sellerTitle}</span>
            </button>
          )}

          <button
            onClick={onLogout}
            className="flex items-center gap-1.5 rounded-xl border border-rose-500/30 bg-rose-950/20 px-3 py-2 text-xs font-semibold text-rose-300 hover:bg-rose-900/30 transition"
          >
            <LogOut className="h-3.5 w-3.5" />
            <span>{t.logoutBtn}</span>
          </button>
        </div>
      </div>

      {/* Wallet Balance Card */}
      <div className="relative overflow-hidden rounded-3xl border border-amber-400/30 bg-gradient-to-br from-neutral-900 via-neutral-950 to-neutral-900 p-6 shadow-2xl">
        <div className="absolute top-0 right-0 -mr-12 -mt-12 h-44 w-44 rounded-full bg-amber-400/10 blur-2xl pointer-events-none" />

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-bold text-neutral-400">
            <WalletIcon className="h-4 w-4 text-amber-400" />
            <span>{t.walletBalance}</span>
          </div>
          <span className="rounded-lg bg-amber-400/20 px-2 py-0.5 text-[10px] font-black text-amber-400">
            Remo Al-Mal Pay
          </span>
        </div>

        <div className="mt-4 flex items-baseline gap-2">
          <span className="text-3xl font-black text-white sm:text-4xl tracking-tight">
            ${wallet.balance.toFixed(2)}
          </span>
          <span className="text-xs font-bold text-amber-400">USD</span>
        </div>

        <div className="mt-1 text-xs text-neutral-400">
          {language === 'ar' ? 'الرصيد المعلق قيد التحقق:' : 'Pending Verification:'}{' '}
          <span className="font-semibold text-neutral-300">${wallet.pending_balance.toFixed(2)}</span>
        </div>

        <div className="mt-6 flex flex-wrap gap-2.5">
          <button
            onClick={() => setShowDepositModal(true)}
            className="flex items-center gap-1.5 rounded-xl bg-amber-400 px-4 py-2.5 text-xs font-extrabold text-neutral-950 hover:bg-amber-300 transition"
          >
            <PlusCircle className="h-4 w-4" />
            <span>{t.depositFunds}</span>
          </button>

          <button
            onClick={() => {
              if (wallet.balance <= 0) {
                alert(language === 'ar' ? 'رصيدك الحالي غير كافٍ للسحب.' : 'Insufficient balance for withdrawal.');
                return;
              }
              const amt = prompt(language === 'ar' ? 'أدخل المبلغ المراد سحبه بالدولار:' : 'Enter amount to withdraw in USD:', '20');
              if (amt && parseFloat(amt) > 0) {
                onWithdraw(parseFloat(amt));
              }
            }}
            className="flex items-center gap-1.5 rounded-xl border border-neutral-700 bg-neutral-900 px-4 py-2.5 text-xs font-bold text-neutral-200 hover:border-amber-400/60 hover:text-white transition"
          >
            <ArrowUpRight className="h-4 w-4 text-amber-400" />
            <span>{t.withdrawFunds}</span>
          </button>
        </div>
      </div>

      {/* Transactions History */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-bold text-white sm:text-base">
            {t.recentTransactions}
          </h2>
          <span className="text-xs text-neutral-400 font-mono">
            {transactions.length} {language === 'ar' ? 'معاملة' : 'records'}
          </span>
        </div>

        {transactions.length === 0 ? (
          <div className="rounded-2xl border border-neutral-800 bg-neutral-900/40 p-8 text-center text-xs text-neutral-400">
            {t.noTransactions}
          </div>
        ) : (
          <div className="space-y-2.5">
            {transactions.map((tx) => (
              <div
                key={tx.id}
                className="flex items-center justify-between rounded-2xl border border-neutral-800/80 bg-neutral-900/50 p-3.5"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`flex h-9 w-9 items-center justify-center rounded-xl ${
                      tx.type === 'deposit' || tx.type === 'sale_earning'
                        ? 'bg-emerald-950/60 text-emerald-400'
                        : 'bg-rose-950/60 text-rose-400'
                    }`}
                  >
                    {tx.type === 'deposit' || tx.type === 'sale_earning' ? (
                      <ArrowDownLeft className="h-4 w-4" />
                    ) : (
                      <ArrowUpRight className="h-4 w-4" />
                    )}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">{tx.description}</h4>
                    <span className="text-[11px] text-neutral-400">
                      {new Date(tx.created_at).toLocaleString()}
                    </span>
                  </div>
                </div>

                <div className="text-end">
                  <span
                    className={`text-xs font-black ${
                      tx.type === 'deposit' || tx.type === 'sale_earning'
                        ? 'text-emerald-400'
                        : 'text-neutral-200'
                    }`}
                  >
                    {tx.type === 'deposit' || tx.type === 'sale_earning' ? '+' : '-'}$
                    {Math.abs(tx.amount).toFixed(2)}
                  </span>
                  <div className="text-[10px] font-semibold text-neutral-400 uppercase">
                    {tx.status}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quick Deposit Modal */}
      {showDepositModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
          <div className="w-full max-w-sm rounded-2xl border border-neutral-800 bg-neutral-950 p-5">
            <h3 className="text-sm font-bold text-white mb-2">{t.depositFunds}</h3>
            <p className="text-xs text-neutral-400 mb-4">
              {language === 'ar'
                ? 'إضافة رصيد فوري لمحفظة Remo Al-Mal لاستخدامه في الشراء السريع بنقرة واحدة.'
                : 'Instantly add funds to your internal Remo wallet for 1-click purchases.'}
            </p>
            <div className="space-y-3">
              <label className="block text-xs font-semibold text-neutral-300">
                {language === 'ar' ? 'المبلغ بالدولار ($):' : 'Amount in USD ($):'}
              </label>
              <input
                type="number"
                min="10"
                value={depositAmount}
                onChange={(e) => setDepositAmount(e.target.value)}
                className="w-full rounded-xl border border-neutral-800 bg-neutral-900 px-3.5 py-2 text-sm text-white focus:border-amber-400 focus:outline-none"
              />
            </div>
            <div className="mt-5 flex gap-2">
              <button
                onClick={() => {
                  const val = parseFloat(depositAmount);
                  if (val > 0) {
                    onDeposit(val);
                    setShowDepositModal(false);
                  }
                }}
                className="flex-1 rounded-xl bg-amber-400 py-2.5 text-xs font-bold text-neutral-950 hover:bg-amber-300"
              >
                {language === 'ar' ? 'تأكيد الإيداع' : 'Confirm Deposit'}
              </button>
              <button
                onClick={() => setShowDepositModal(false)}
                className="rounded-xl border border-neutral-800 px-3 py-2.5 text-xs font-medium text-neutral-400"
              >
                {t.cancelBtn}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
