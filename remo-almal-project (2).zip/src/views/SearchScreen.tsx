import React, { useState, useMemo } from 'react';
import { Search, X, Star, Zap, History, Sparkles } from 'lucide-react';
import { DigitalProduct, Language, Screen } from '../types';
import { translations } from '../lib/i18n';

interface SearchScreenProps {
  products: DigitalProduct[];
  language: Language;
  onSelectProduct: (product: DigitalProduct) => void;
  onInstantBuy: (product: DigitalProduct) => void;
}

export const SearchScreen: React.FC<SearchScreenProps> = ({
  products,
  language,
  onSelectProduct,
  onInstantBuy,
}) => {
  const t = translations[language];
  const [searchTerm, setSearchTerm] = useState('');

  const quickTags = [
    'Android',
    'Kotlin',
    'USDT TRC20',
    'Jetpack Compose',
    'Crypto Gateway',
    'Figma UI Kit',
    'Security Audit',
    'Scripts'
  ];

  const searchResults = useMemo(() => {
    const term = searchTerm.toLowerCase().trim();
    if (!term) return [];
    return products.filter((p) => {
      return (
        p.title.toLowerCase().includes(term) ||
        (p.title_en && p.title_en.toLowerCase().includes(term)) ||
        p.description.toLowerCase().includes(term) ||
        p.category.toLowerCase().includes(term) ||
        (p.seller_name && p.seller_name.toLowerCase().includes(term))
      );
    });
  }, [products, searchTerm]);

  return (
    <div className="space-y-5 pb-20">
      <div>
        <h1 className="text-xl font-black text-white sm:text-2xl">
          {t.navSearch}
        </h1>
        <p className="mt-1 text-xs text-neutral-400">
          {language === 'ar' ? 'البحث اللحظي في قاعدة بيانات المنتجات الرقمية والتراخيص' : 'Instant search across digital assets and licenses'}
        </p>
      </div>

      {/* Main Search Input */}
      <div className="relative">
        <Search className="absolute top-1/2 -translate-y-1/2 left-3.5 rtl:left-auto rtl:right-3.5 h-5 w-5 text-amber-400" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder={language === 'ar' ? 'اكتب اسم المنتج أو التقنية (مثال: Kotlin, USDT, Figma)...' : 'Type product title, technology or keyword...'}
          autoFocus
          className="w-full rounded-2xl border border-neutral-800 bg-neutral-900/90 py-3.5 px-11 text-sm text-neutral-100 placeholder-neutral-500 focus:border-amber-400 focus:outline-none shadow-lg shadow-black/40"
        />
        {searchTerm && (
          <button
            onClick={() => setSearchTerm('')}
            className="absolute top-1/2 -translate-y-1/2 right-3.5 rtl:right-auto rtl:left-3.5 rounded-full p-1 text-neutral-400 hover:bg-neutral-800 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* Suggested Quick Tags */}
      <div>
        <div className="flex items-center gap-1.5 text-xs font-semibold text-neutral-400 mb-2.5">
          <Sparkles className="h-3.5 w-3.5 text-amber-400" />
          <span>{language === 'ar' ? 'كلمات البحث الشائعة:' : 'Trending Searches:'}</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {quickTags.map((tag) => (
            <button
              key={tag}
              onClick={() => setSearchTerm(tag)}
              className="rounded-xl border border-neutral-800 bg-neutral-900/80 px-3 py-1.5 text-xs font-medium text-neutral-300 hover:border-amber-400/60 hover:text-amber-400 transition"
            >
              #{tag}
            </button>
          ))}
        </div>
      </div>

      {/* Search Results */}
      {searchTerm.trim() ? (
        <div className="space-y-3 pt-2">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span>
              {language === 'ar' ? `نتائج البحث لـ "${searchTerm}"` : `Results for "${searchTerm}"`}
            </span>
            <span className="font-bold text-amber-400">
              {searchResults.length} {language === 'ar' ? 'منتج' : 'items'}
            </span>
          </div>

          {searchResults.length === 0 ? (
            <div className="rounded-2xl border border-neutral-800 bg-neutral-900/30 p-8 text-center text-xs text-neutral-400">
              {language === 'ar' ? 'لا توجد نتائج تطابق بحثك حالياً.' : 'No matching digital goods found.'}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {searchResults.map((product) => (
                <div
                  key={product.id}
                  className="flex items-center gap-3 rounded-2xl border border-neutral-800 bg-neutral-900/60 p-3 hover:border-amber-400/50 transition cursor-pointer"
                  onClick={() => onSelectProduct(product)}
                >
                  <img
                    src={product.preview_image}
                    alt={product.title}
                    className="h-20 w-24 rounded-xl object-cover shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">
                      {product.category}
                    </span>
                    <h4 className="font-bold text-white text-xs truncate mt-0.5">
                      {language === 'ar' ? product.title : (product.title_en || product.title)}
                    </h4>
                    <div className="mt-1 flex items-center gap-2 text-[11px] text-neutral-400">
                      <span className="font-black text-amber-400">${product.price.toFixed(2)}</span>
                      <span>•</span>
                      <span className="flex items-center gap-0.5">
                        <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
                        {product.rating}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        /* Empty State / Search Guide */
        <div className="rounded-2xl border border-dashed border-neutral-800 p-8 text-center text-neutral-400">
          <History className="mx-auto h-8 w-8 text-neutral-500 mb-2" />
          <p className="text-xs">
            {language === 'ar'
              ? 'ابدأ بكتابة اسم المنتج الرقمي أو اختر من الكلمات الشائعة أعلاه'
              : 'Start typing to instantly query digital assets and tools'}
          </p>
        </div>
      )}
    </div>
  );
};
