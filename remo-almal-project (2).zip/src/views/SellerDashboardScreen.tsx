import React from 'react';
import {
  Plus,
  DollarSign,
  TrendingUp,
  Package,
  Clock,
  Edit3,
  ExternalLink,
  ShieldCheck,
  AlertCircle,
  FileCheck
} from 'lucide-react';
import { DigitalProduct, Language, Order, Screen, UserProfile } from '../types';
import { translations } from '../lib/i18n';

interface SellerDashboardScreenProps {
  user: UserProfile;
  products: DigitalProduct[];
  orders: Order[];
  language: Language;
  setScreen: (screen: Screen) => void;
  onAddNewProduct: () => void;
  onEditProduct: (product: DigitalProduct) => void;
}

export const SellerDashboardScreen: React.FC<SellerDashboardScreenProps> = ({
  user,
  products,
  orders,
  language,
  setScreen,
  onAddNewProduct,
  onEditProduct,
}) => {
  const t = translations[language];

  // Filter only products belonging to current seller
  const sellerProducts = products.filter((p) => p.seller_id === user.id || p.seller_id === 'seller-remo-01');
  const sellerOrders = orders.filter((o) => o.seller_id === user.id || o.seller_id === 'seller-remo-01');

  // Strict 10% platform commission calculation
  const totalGrossSales = sellerOrders
    .filter((o) => o.status === 'paid' || o.status === 'completed')
    .reduce((sum, o) => sum + o.total_amount, 0);

  const totalCommission = totalGrossSales * 0.10; // 10% official fee
  const netSellerEarnings = totalGrossSales * 0.90; // 90% net to seller

  return (
    <div className="space-y-6 pb-24">
      {/* Header with Title and Add Product Action */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-black text-white sm:text-2xl">
            {t.sellerTitle}
          </h1>
          <p className="mt-1 text-xs text-neutral-400">
            {t.sellerSubtitle}
          </p>
        </div>

        <button
          onClick={onAddNewProduct}
          className="flex items-center gap-2 rounded-xl bg-amber-400 px-4 py-2.5 text-xs font-extrabold text-neutral-950 shadow-md shadow-amber-400/20 hover:bg-amber-300 transition active:scale-95"
        >
          <Plus className="h-4 w-4" />
          <span>{t.addNewProductBtn}</span>
        </button>
      </div>

      {/* Financial Metrics Cards */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        {/* Net Earnings */}
        <div className="rounded-2xl border border-amber-400/40 bg-gradient-to-br from-neutral-900 to-amber-950/20 p-4">
          <div className="flex items-center justify-between text-xs text-amber-400 font-bold">
            <span>{t.sellerEarnings}</span>
            <DollarSign className="h-4 w-4" />
          </div>
          <div className="mt-2 text-2xl font-black text-white sm:text-3xl">
            ${netSellerEarnings.toFixed(2)}
          </div>
          <div className="mt-1 text-[11px] text-neutral-400">
            {language === 'ar' ? 'صافي مستحق بعد عمولة 10%' : 'Net withdrawable (90%)'}
          </div>
        </div>

        {/* Total Gross Sales */}
        <div className="rounded-2xl border border-neutral-800 bg-neutral-900/60 p-4">
          <div className="flex items-center justify-between text-xs text-neutral-400 font-bold">
            <span>{t.sellerTotalSales}</span>
            <TrendingUp className="h-4 w-4 text-emerald-400" />
          </div>
          <div className="mt-2 text-2xl font-black text-white sm:text-3xl">
            ${totalGrossSales.toFixed(2)}
          </div>
          <div className="mt-1 text-[11px] text-neutral-400">
            {language === 'ar' ? `العمولة المقتطعة: $${totalCommission.toFixed(2)} (10%)` : `Platform Fee: $${totalCommission.toFixed(2)} (10%)`}
          </div>
        </div>

        {/* Listed Products */}
        <div className="rounded-2xl border border-neutral-800 bg-neutral-900/60 p-4">
          <div className="flex items-center justify-between text-xs text-neutral-400 font-bold">
            <span>{t.sellerActiveProducts}</span>
            <Package className="h-4 w-4 text-amber-400" />
          </div>
          <div className="mt-2 text-2xl font-black text-white sm:text-3xl">
            {sellerProducts.length}
          </div>
          <div className="mt-1 text-[11px] text-neutral-400">
            {language === 'ar' ? 'منتجات في مساحة التخزين الخاصة' : 'Stored in digital-product-files'}
          </div>
        </div>
      </div>

      {/* Security & Commission Policy Notice */}
      <div className="rounded-2xl border border-amber-400/25 bg-amber-400/5 p-4 text-xs text-amber-300 flex items-start gap-3">
        <ShieldCheck className="h-5 w-5 shrink-0 text-amber-400 mt-0.5" />
        <div className="leading-relaxed">
          <p className="font-bold text-white mb-0.5">{t.commissionNotice}</p>
          <p className="text-neutral-300 text-[11px]">
            {language === 'ar'
              ? 'تتم معالجة الملفات المرفوعة في Bucket خاص "digital-product-files" دون إمكانية الوصول المباشر إلا عبر خادم مؤمّن بعد تأكيد حالة الدفع "paid". لا يمكن لأي بائع تعديل بيانات أو أسعار منتجات بائعين آخرين وفق سياسات RLS الصارمة.'
              : 'Uploaded files are securely stored inside the private "digital-product-files" bucket. Only verified "paid" orders obtain timed signed links under strict RLS isolation.'}
          </p>
        </div>
      </div>

      {/* Seller's Products Management Table */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-bold text-white sm:text-base">
            {t.myProductsTitle}
          </h2>
          <span className="text-xs text-neutral-400">
            {sellerProducts.length} {language === 'ar' ? 'منتج معروض' : 'items'}
          </span>
        </div>

        {sellerProducts.length === 0 ? (
          <div className="rounded-2xl border border-neutral-800 bg-neutral-900/30 p-8 text-center text-xs text-neutral-400">
            {language === 'ar'
              ? 'لم تقم بإضافة أي منتجات رقمية بعد. اضغط "إضافة منتج رقمي جديد" للبدء!'
              : 'No digital products listed yet. Click "Add New Digital Product" to start!'}
          </div>
        ) : (
          <div className="space-y-3">
            {sellerProducts.map((prod) => (
              <div
                key={prod.id}
                className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 rounded-2xl border border-neutral-800 bg-neutral-900/60 p-4 transition hover:border-amber-400/50"
              >
                <div className="flex items-center gap-3">
                  <img
                    src={prod.preview_image}
                    alt={prod.title}
                    className="h-14 w-20 rounded-xl object-cover"
                  />
                  <div>
                    <span className="text-[10px] font-bold text-amber-400 uppercase">
                      {prod.category}
                    </span>
                    <h3 className="text-xs font-bold text-white line-clamp-1">
                      {language === 'ar' ? prod.title : (prod.title_en || prod.title)}
                    </h3>
                    <div className="mt-1 flex items-center gap-3 text-[11px] text-neutral-400">
                      <span className="font-black text-amber-400">${prod.price.toFixed(2)}</span>
                      <span>•</span>
                      <span>{prod.downloads_count} {t.downloads}</span>
                      <span>•</span>
                      <span className="font-mono text-[10px] text-neutral-500">{prod.file_name || prod.file_path}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-auto">
                  <button
                    onClick={() => onEditProduct(prod)}
                    className="flex items-center gap-1.5 rounded-xl border border-neutral-700 bg-neutral-800 px-3 py-1.5 text-xs font-semibold text-neutral-200 hover:border-amber-400 hover:text-white"
                  >
                    <Edit3 className="h-3.5 w-3.5" />
                    <span>{t.editProductBtn}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Seller Sales Orders */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-bold text-white sm:text-base">
            {t.salesOrdersTitle}
          </h2>
          <button
            onClick={() => setScreen('orders')}
            className="text-xs font-semibold text-amber-400 hover:underline"
          >
            {language === 'ar' ? 'عرض السجل الكامل' : 'Full History'}
          </button>
        </div>

        {sellerOrders.length === 0 ? (
          <div className="rounded-2xl border border-neutral-800 bg-neutral-900/30 p-6 text-center text-xs text-neutral-400">
            {language === 'ar' ? 'لا توجد مبيعات مسجلة حتى الآن.' : 'No sales orders recorded yet.'}
          </div>
        ) : (
          <div className="space-y-2.5">
            {sellerOrders.map((ord) => (
              <div
                key={ord.id}
                className="flex items-center justify-between rounded-xl border border-neutral-800/80 bg-neutral-900/40 p-3 text-xs"
              >
                <div>
                  <div className="font-bold text-white">{ord.product_title}</div>
                  <span className="text-[11px] text-neutral-400 font-mono">
                    #{ord.id.slice(0, 8)} • {new Date(ord.created_at).toLocaleDateString()}
                  </span>
                </div>
                <div className="text-end">
                  <span className="font-black text-amber-400 block">${ord.total_amount.toFixed(2)}</span>
                  <span className="text-[10px] font-semibold text-emerald-400 uppercase">
                    {ord.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
