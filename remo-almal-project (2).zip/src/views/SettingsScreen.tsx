import React from 'react';
import {
  Globe,
  Sun,
  Moon,
  Database,
  Smartphone,
  Shield,
  CheckCircle2,
  Lock,
  HardDrive
} from 'lucide-react';
import { Language, Screen, Theme } from '../types';
import { translations } from '../lib/i18n';
import { SUPABASE_PROJECT_ID, SUPABASE_URL } from '../lib/supabase';

interface SettingsScreenProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  theme: Theme;
  onThemeChange: (theme: Theme) => void;
  setScreen: (screen: Screen) => void;
  onOpenSupabaseModal: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  language,
  onLanguageChange,
  theme,
  onThemeChange,
  setScreen,
  onOpenSupabaseModal,
}) => {
  const t = translations[language];

  return (
    <div className="mx-auto max-w-xl space-y-6 pb-24">
      <div>
        <h1 className="text-xl font-black text-white sm:text-2xl">
          {t.settingsTitle}
        </h1>
        <p className="mt-1 text-xs text-neutral-400">
          {language === 'ar' ? 'تخصيص لغة التطبيق، المظهر، وربط قواعد البيانات' : 'Personalize language, appearance, and database configuration'}
        </p>
      </div>

      {/* Language Section */}
      <div className="rounded-3xl border border-neutral-800 bg-neutral-900/80 p-5 space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold text-neutral-200">
          <Globe className="h-4 w-4 text-amber-400" />
          <span>{t.languageSection}</span>
        </div>

        <div className="grid grid-cols-2 gap-3 text-xs">
          <button
            onClick={() => onLanguageChange('ar')}
            className={`flex items-center justify-between rounded-2xl border p-3.5 font-bold transition ${
              language === 'ar'
                ? 'border-amber-400 bg-amber-400/10 text-amber-400'
                : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:text-white'
            }`}
          >
            <span>العربية (RTL)</span>
            {language === 'ar' && <CheckCircle2 className="h-4 w-4 text-amber-400" />}
          </button>

          <button
            onClick={() => onLanguageChange('en')}
            className={`flex items-center justify-between rounded-2xl border p-3.5 font-bold transition ${
              language === 'en'
                ? 'border-amber-400 bg-amber-400/10 text-amber-400'
                : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:text-white'
            }`}
          >
            <span>English (LTR)</span>
            {language === 'en' && <CheckCircle2 className="h-4 w-4 text-amber-400" />}
          </button>
        </div>
      </div>

      {/* Theme Section */}
      <div className="rounded-3xl border border-neutral-800 bg-neutral-900/80 p-5 space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold text-neutral-200">
          <Sun className="h-4 w-4 text-amber-400" />
          <span>{t.themeSection}</span>
        </div>

        <div className="grid grid-cols-2 gap-3 text-xs">
          <button
            onClick={() => onThemeChange('dark')}
            className={`flex items-center justify-between rounded-2xl border p-3.5 font-bold transition ${
              theme === 'dark'
                ? 'border-amber-400 bg-amber-400/10 text-amber-400'
                : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:text-white'
            }`}
          >
            <div className="flex items-center gap-2">
              <Moon className="h-4 w-4" />
              <span>{t.themeDark}</span>
            </div>
            {theme === 'dark' && <CheckCircle2 className="h-4 w-4 text-amber-400" />}
          </button>

          <button
            onClick={() => onThemeChange('light')}
            className={`flex items-center justify-between rounded-2xl border p-3.5 font-bold transition ${
              theme === 'light'
                ? 'border-amber-400 bg-amber-400/10 text-amber-400'
                : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:text-white'
            }`}
          >
            <div className="flex items-center gap-2">
              <Sun className="h-4 w-4" />
              <span>{t.themeLight}</span>
            </div>
            {theme === 'light' && <CheckCircle2 className="h-4 w-4 text-amber-400" />}
          </button>
        </div>
      </div>

      {/* Supabase Database Settings */}
      <div className="rounded-3xl border border-neutral-800 bg-neutral-900/80 p-5 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-bold text-neutral-200">
            <Database className="h-4 w-4 text-amber-400" />
            <span>{t.supabaseSection}</span>
          </div>
          <button
            onClick={onOpenSupabaseModal}
            className="text-xs font-bold text-amber-400 hover:underline"
          >
            {language === 'ar' ? 'فحص وإدخال المفتاح' : 'Inspect & Key'}
          </button>
        </div>

        <div className="space-y-2 rounded-2xl bg-neutral-950 p-3.5 border border-neutral-800 text-xs">
          <div className="flex justify-between items-center text-neutral-400">
            <span>Project ID:</span>
            <span className="font-mono text-white font-semibold">{SUPABASE_PROJECT_ID}</span>
          </div>
          <div className="flex justify-between items-center text-neutral-400">
            <span>Project URL:</span>
            <span className="font-mono text-neutral-300 truncate max-w-[220px]">{SUPABASE_URL}</span>
          </div>
          <div className="flex justify-between items-center text-neutral-400">
            <span>Storage Bucket:</span>
            <span className="font-mono text-emerald-400">digital-product-files</span>
          </div>
        </div>
      </div>

      {/* Android Hub Card Shortcut */}
      <div className="rounded-3xl border border-amber-400/30 bg-gradient-to-r from-neutral-900 via-neutral-950 to-neutral-900 p-5">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-400 text-neutral-950 font-black">
              <Smartphone className="h-6 w-6" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-white">{t.apkCenterTitle}</h3>
              <p className="text-[11px] text-neutral-400">com.remo.almal • Free APK Building Guide</p>
            </div>
          </div>
          <button
            onClick={() => setScreen('apk_export')}
            className="rounded-xl bg-amber-400 px-3.5 py-2 text-xs font-bold text-neutral-950 hover:bg-amber-300"
          >
            {language === 'ar' ? 'فتح المركز' : 'Open Hub'}
          </button>
        </div>
      </div>

      {/* Legal & Policies Navigation */}
      <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-neutral-400 pt-2">
        <button
          onClick={() => setScreen('privacy_policy')}
          className="hover:text-amber-400 transition"
        >
          {t.privacyTitle}
        </button>
        <span>•</span>
        <button
          onClick={() => setScreen('terms_of_service')}
          className="hover:text-amber-400 transition"
        >
          {t.termsTitle}
        </button>
        <span>•</span>
        <button
          onClick={() => setScreen('help_support')}
          className="hover:text-amber-400 transition"
        >
          {t.helpTitle}
        </button>
      </div>

      <div className="text-center text-[11px] text-neutral-600 font-mono">
        Remo Al-Mal v1.0.0 • All Rights Reserved © 2026
      </div>
    </div>
  );
};
