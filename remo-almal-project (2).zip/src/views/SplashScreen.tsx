import React, { useEffect, useState } from 'react';
import { ShieldCheck, ArrowRight, ArrowLeft } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../lib/i18n';

interface SplashScreenProps {
  language: Language;
  onFinish: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ language, onFinish }) => {
  const t = translations[language];
  const [progress, setProgress] = useState(15);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          return 100;
        }
        return prev + 25;
      });
    }, 450);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-between bg-neutral-950 p-6 text-center select-none overflow-hidden">
      {/* Background glow effects */}
      <div className="absolute -top-32 left-1/2 -translate-x-1/2 h-96 w-96 rounded-full bg-amber-500/10 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 left-1/2 -translate-x-1/2 h-96 w-96 rounded-full bg-amber-400/5 blur-3xl pointer-events-none" />

      {/* Top subtle badge */}
      <div className="mt-8 flex items-center gap-1.5 rounded-full border border-amber-400/20 bg-neutral-900/60 px-3.5 py-1 text-xs text-amber-400">
        <ShieldCheck className="h-3.5 w-3.5" />
        <span className="font-semibold tracking-wider uppercase text-[11px]">
          Android & Cloud Native Verified
        </span>
      </div>

      {/* Center Brand Identity */}
      <div className="flex flex-col items-center max-w-sm">
        {/* Animated Brand Emblem */}
        <div className="relative mb-6 flex h-28 w-28 items-center justify-center rounded-3xl bg-gradient-to-br from-neutral-900 to-black p-1 shadow-2xl ring-2 ring-amber-400/40">
          <div className="absolute inset-0 rounded-3xl bg-amber-400/10 blur-xl animate-pulse" />
          <svg viewBox="0 0 512 512" className="relative h-20 w-20">
            <path
              d="M205 165 H275 C310 165 330 185 330 215 C330 240 315 258 290 263 L340 345 H295 L252 275 H245 V345 H205 V165 Z M245 200 V240 H272 C288 240 295 232 295 220 C295 208 288 200 272 200 H245 Z"
              fill="#FACC15"
            />
            <polygon points="345,125 352,140 367,147 352,154 345,169 338,154 323,147 338,140" fill="#EAB308" />
          </svg>
        </div>

        <h1 className="text-3xl font-black tracking-tight text-white sm:text-4xl">
          Remo Al-Mal
        </h1>
        <p className="mt-1 text-lg font-bold text-amber-400">
          {t.appName}
        </p>
        <p className="mt-2 text-xs text-neutral-400 leading-relaxed max-w-xs">
          {t.appSubtitle}
        </p>

        {/* Progress bar */}
        <div className="mt-8 w-64">
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-neutral-800">
            <div
              className="h-full bg-gradient-to-r from-amber-500 to-amber-300 transition-all duration-300 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="mt-2 text-[11px] font-medium text-neutral-400">
            {t.splashLoading}
          </p>
        </div>
      </div>

      {/* Bottom Action Button */}
      <div className="w-full max-w-xs pb-4">
        <button
          onClick={onFinish}
          className="group w-full flex items-center justify-center gap-2 rounded-2xl bg-amber-400 py-3.5 text-sm font-extrabold text-neutral-950 shadow-lg shadow-amber-400/20 hover:bg-amber-300 transition active:scale-95"
        >
          <span>{t.splashStart}</span>
          {language === 'ar' ? (
            <ArrowLeft className="h-4 w-4 transition group-hover:-translate-x-1" />
          ) : (
            <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
          )}
        </button>
        <p className="mt-2 text-[10px] text-neutral-400">
          v1.0.0 • com.remo.almal
        </p>
      </div>
    </div>
  );
};
