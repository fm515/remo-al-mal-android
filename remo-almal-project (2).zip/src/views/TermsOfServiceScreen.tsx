import React from 'react';
import { FileText, DollarSign, ShieldAlert, ArrowLeft, ArrowRight, CheckCircle2 } from 'lucide-react';
import { Language, Screen } from '../types';
import { translations } from '../lib/i18n';

interface TermsOfServiceScreenProps {
  language: Language;
  setScreen: (screen: Screen) => void;
}

export const TermsOfServiceScreen: React.FC<TermsOfServiceScreenProps> = ({
  language,
  setScreen,
}) => {
  const t = translations[language];

  return (
    <div className="mx-auto max-w-xl space-y-6 pb-24">
      <div className="flex items-center justify-between">
        <button
          onClick={() => setScreen('settings')}
          className="flex items-center gap-2 rounded-xl border border-neutral-800 bg-neutral-900 px-3 py-1.5 text-xs font-semibold text-neutral-300 hover:text-white"
        >
          {language === 'ar' ? <ArrowRight className="h-4 w-4" /> : <ArrowLeft className="h-4 w-4" />}
          <span>{language === 'ar' ? 'الرجوع للإعدادات' : 'Back to Settings'}</span>
        </button>

        <span className="text-[11px] font-mono text-neutral-500">
          Remo Agreement v1.2
        </span>
      </div>

      <div className="rounded-3xl border border-neutral-800 bg-neutral-900/80 p-6 sm:p-8 space-y-5 shadow-2xl">
        <div className="flex items-center gap-3 border-b border-neutral-800 pb-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-400/10 text-amber-400">
            <FileText className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-base font-bold text-white sm:text-lg">{t.termsTitle}</h1>
            <p className="text-xs text-neutral-400">Remo Al-Mal Digital Marketplace Agreement</p>
          </div>
        </div>

        <div className="space-y-4 text-xs text-neutral-300 leading-relaxed">
          <section>
            <h3 className="font-bold text-white text-sm mb-1.5 flex items-center gap-2">
              <DollarSign className="h-4 w-4 text-amber-400" />
              <span>1. عمولة المنصة الرسمية (10%)</span>
            </h3>
            <p>
              تقتطع منصة Remo Al-Mal عمولة رسمية ثابتة قدرها 10% من قيمة كل طلب بيع رقمي ناجح يتم عبر المنصة. تُحسب وتُقتطع هذه النسبة آلياً على الخادم لضمان حماية المعاملات، وتغطية تكاليف التحقق والسيولة والاستضافة، ويُودع الـ 90% المتبقية في رصيد محفظة البائع فور تأكيد المعاملة.
            </p>
          </section>

          <section>
            <h3 className="font-bold text-white text-sm mb-1.5 flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-amber-400" />
              <span>2. التحقق من المدفوعات والتسليم الفوري</span>
            </h3>
            <p>
              لا يُعتبر أي طلب مدفوعاً أو مكتملاً بمجرد إرسال صورة أو رسالة من المستخدم. يتولى الخادم والمزوّد المعتمد فحص وتأكيد المعاملة بدقة (Cryptographic Check) قبل توليد رابط تنزيل الملف الخاص بالمشتري.
            </p>
          </section>

          <section>
            <h3 className="font-bold text-white text-sm mb-1.5 flex items-center gap-2">
              <ShieldAlert className="h-4 w-4 text-amber-400" />
              <span>3. حقوق الملكية الفكرية للبائعين</span>
            </h3>
            <p>
              يقر البائع بملكيته الكاملة أو حصوله على تراخيص إعادة البيع القانونية لجميع الأكواد البرمجية والتصاميم والكتب الرقمية المنشورة. يحق للمنصة تجميد الحسابات وسحب المنتجات التي تنتهك حقوق الملكية الفكرية دون إنذار مسبق.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
};
